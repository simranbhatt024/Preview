// Shared WhatsApp redirect helper for Elios Solar Energy enquiry forms.
// Builds a pre-filled WhatsApp message and redirects the user after the lead
// is saved locally + pushed to the CRM.

export const ELIOS_WHATSAPP_NUMBER = "919153933318"; // +91 91539 33318

export function buildWhatsAppUrl(message: string): string {
  return `https://wa.me/${ELIOS_WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}

export function redirectToWhatsApp(message: string, delayMs = 800) {
  const url = buildWhatsAppUrl(message);
  setTimeout(() => {
    window.location.href = url;
  }, delayMs);
}
