// Centralized asset constants
export const ASSETS = {
  logo: "https://vibe.filesafe.space/1792820769937918655/attachments/55b90217-92f2-46ad-af1e-9a750e0f9198.jpg",
  residentialHero:
    "https://vibe.filesafe.space/1792820769937918655/assets/176fee8d-679a-4bc7-842d-c24b2c667d29.png",
  commercialHero:
    "https://vibe.filesafe.space/1792820769937918655/assets/46dbcc50-bb8b-4dbc-a0b8-904c9dabcd2a.png",
  housingSocietyHero:
    "https://vibe.filesafe.space/1792820769937918655/assets/4c644fa6-a91f-4135-8bc5-55e7e960e282.png",
  offGridHero:
    "https://vibe.filesafe.space/1792820769937918655/assets/4227e2ac-7dce-47cd-919a-b0b8d04b4f97.png",
};

export const CONTACT_INFO = {
  phone: "+91 91539 33318",
  phoneTel: "tel:+919153933318",
  whatsappNumber: "+919153933318",
  whatsappUrl:
    "https://wa.me/919153933318?text=Hello%20Elios%20Solar%2C%20I%20would%20like%20to%20enquire%20about%20solar%20solutions%20for%20my%20property%20in%20Bihar.",
  hours: "Monday to Saturday, 9 AM to 7 PM IST",
  state: "Bihar, India",
  instagramUrl: "https://www.instagram.com/eliossolarenergy?psln=M3R4OW1ybWMyYWcy",
};
