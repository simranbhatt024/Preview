import React, { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export type Locale = "en" | "hi";

interface LocaleContextType {
  locale: Locale;
  setLocale: (loc: Locale) => void;
  t: (key: string) => string;
  isHi: boolean;
}

export const DICTIONARY: Record<Locale, Record<string, string>> = {
  en: {
    // Nav
    home: "Home",
    solarSolutions: "Solar Solutions",
    residentialHomes: "Residential Homes",
    housingSociety: "Housing Society",
    commercialIndustrial: "Commercial & Industrial",
    offGridSolar: "Off-Grid Solar",
    solarCalculator: "Solar Calculator",
    becomePartner: "Become a Partner",
    referralProgram: "Referral Program",
    learnAndEarn: "Learn & Earn",
    solarBody: "Solar Body Program",
    productsServices: "Products & Services",
    brandLineup: "Brand Lineup",
    packages: "Annual Packages",
    newsBlogs: "News & Blogs",
    aboutUs: "About Us",
    joinUs: "Join Us",
    contactUs: "Contact Us",
    login: "Login",
    register: "Register",
    adminDashboard: "Admin Portal",
    getFreeQuotation: "Get Free Quotation",
    bookFreeConsultation: "Book Free Consultation",

    // Hero & Quotes
    openingQuote:
      "The sun sends your family a free power supply every morning. Let us help you receive it.",
    heroHeadline: "Cut your electricity bill. Power your future with solar.",
    heroSubhead:
      "Elios Solar Energy engineers, supplies and installs rooftop solar across Bihar, handling all government subsidy and low-EMI loan paperwork under one roof.",
    heroOffer: "Free rooftop inspection and custom savings projection for your home or business.",
    trustSubsidy: "Subsidy Support",
    trustLoan: "Easy Loan Facility",
    trustEpc: "One EPC Company",

    // CTAs & Buttons
    seeSolutions: "See Solar Solutions for Your Roof",
    requestQuote: "Request Quote",
    talkExpert: "Talk to a Solar Expert",
    startProject: "Start Your Solar Project",
    checkLoanOptions: "Check Loan Options",
    viewFullRange: "View Full Product Range",
    readStories: "Read More Customer Stories",
    joinCustomers: "Join Our Happy Solar Customers",
    seeWork: "See Our Work in Person",
    workWithTeam: "Work With a Trusted Solar Team",
    getExactQuote: "Get Exact Quote",
    choosePackage: "Choose Package",
    applyNow: "Apply Now",
    callNow: "Call Now",
    whatsappChat: "Chat on WhatsApp",
    sendMessage: "Send a Message",

    // Disclaimers
    subsidyDisclaimer:
      "Subsidy amounts depend on eligibility and current scheme rules. Figures are shown as up to amounts. Confirm on the official PM Surya Ghar portal at pmsuryaghar.gov.in before you apply.",
    loanDisclaimer: "Loan approval and the interest rate depend on the lending partner.",
    calculatorDisclaimer:
      "Results are estimates. Actual savings depend on your roof, usage and current tariff.",
    taxDisclaimer:
      "Tax benefits depend on each business's situation. Consult a chartered accountant.",

    // Floating
    floatingTitle:
      "Still have questions. Our solar experts are available Monday to Saturday, 9 AM to 7 PM.",
    floatingOffer: "Free consultation with no obligations. Book it right here.",
    expertAvailable: "Experts available now",
    expertLeaveMessage: "Leave a message for our solar team",

    // Currency & Units
    perYear: "per year",
    from: "From",
    upTo: "Up to",
    units: "Units",
    monthlyBill: "Monthly Electricity Bill",
    yearlySavings: "Estimated Yearly Savings",
  },
  hi: {
    // Nav
    home: "होम",
    solarSolutions: "सोलर समाधान",
    residentialHomes: "आवासीय घर",
    housingSociety: "हाउसिंग सोसाइटी",
    commercialIndustrial: "कमर्शियल एवं औद्योगिक",
    offGridSolar: "ऑफ-ग्रिड सोलर",
    solarCalculator: "सोलर कैलकुलेटर",
    becomePartner: "पार्टनर बनें",
    referralProgram: "रेफरल प्रोग्राम",
    learnAndEarn: "लर्न एंड अर्न",
    solarBody: "सोलर बॉडी प्रोग्राम",
    productsServices: "उत्पाद एवं सेवाएँ",
    brandLineup: "ब्रांड लाइनअप",
    packages: "वार्षिक पैकेज",
    newsBlogs: "समाचार एवं ब्लॉग",
    aboutUs: "हमारे बारे में",
    joinUs: "कैरियर",
    contactUs: "संपर्क करें",
    login: "लॉगिन",
    register: "पंजीकरण",
    adminDashboard: "एडमिन पोर्टल",
    getFreeQuotation: "मुफ़्त कोटेशन प्राप्त करें",
    bookFreeConsultation: "मुफ़्त परामर्श बुक करें",

    // Hero & Quotes
    openingQuote:
      "सूरज हर सुबह आपके परिवार को मुफ़्त बिजली का उपहार भेजता है। इसे अपनाने में हम आपकी मदद करते हैं।",
    heroHeadline: "बिजली का बिल कम करें। सोलर ऊर्जा से अपना भविष्य रोशन करें।",
    heroSubhead:
      "एलियोस सोलर एनर्जी पूरे बिहार में रूफटॉप सोलर की इंजीनियरिंग, आपूर्ति और इंस्टॉलेशन करती है, तथा सरकारी सब्सिडी और आसान ईएमआई लोन के सारे दस्तावेज़ खुद संभालती है।",
    heroOffer: "आपके घर या व्यवसाय के लिए मुफ़्त छत निरीक्षण और बचत का व्यक्तिगत आकलन।",
    trustSubsidy: "सब्सिडी सहायता",
    trustLoan: "आसान लोन सुविधा",
    trustEpc: "एक ही ईपीसी कंपनी",

    // CTAs & Buttons
    seeSolutions: "अपनी छत के लिए सोलर समाधान देखें",
    requestQuote: "कोटेशन मांगें",
    talkExpert: "सोलर विशेषज्ञ से बात करें",
    startProject: "अपना सोलर प्रोजेक्ट शुरू करें",
    checkLoanOptions: "लोन विकल्प देखें",
    viewFullRange: "सभी उत्पाद देखें",
    readStories: "ग्राहकों के अनुभव पढ़ें",
    joinCustomers: "हमारे संतुष्ट ग्राहकों से जुड़ें",
    seeWork: "हमारा काम प्रत्यक्ष देखें",
    workWithTeam: "भरोसेमंद सोलर टीम के साथ काम करें",
    getExactQuote: "सटीक कोटेशन प्राप्त करें",
    choosePackage: "पैकेज चुनें",
    applyNow: "आवेदन करें",
    callNow: "अभी कॉल करें",
    whatsappChat: "व्हाट्सएप पर बात करें",
    sendMessage: "संदेश भेजें",

    // Disclaimers
    subsidyDisclaimer:
      "सब्सिडी की राशि पात्रता और योजना के वर्तमान नियमों पर निर्भर करती है। आंकड़े 'अधिकतम' के रूप में दर्शाए गए हैं। आवेदन करने से पहले आधिकारिक पीएम सूर्य घर पोर्टल pmsuryaghar.gov.in पर पुष्टि करें।",
    loanDisclaimer: "लोन की स्वीकृति और ब्याज दर ऋणदाता साझेदार की शर्तों पर निर्भर करती है।",
    calculatorDisclaimer:
      "परिणाम अनुमानित हैं। वास्तविक बचत आपकी छत, उपयोग और वर्तमान टैरिफ पर निर्भर करती है।",
    taxDisclaimer:
      "कर लाभ प्रत्येक व्यवसाय की स्थिति पर निर्भर करते हैं। चार्टर्ड अकाउंटेंट से परामर्श लें।",

    // Floating
    floatingTitle:
      "कोई प्रश्न है? हमारे सोलर विशेषज्ञ सोमवार से शनिवार, सुबह 9 से शाम 7 बजे तक उपलब्ध हैं।",
    floatingOffer: "बिना किसी बाध्यता के मुफ़्त परामर्श। यहीं बुक करें।",
    expertAvailable: "विशेषज्ञ अभी उपलब्ध हैं",
    expertLeaveMessage: "हमारी सोलर टीम के लिए संदेश छोड़ें",

    // Currency & Units
    perYear: "प्रति वर्ष",
    from: "से",
    upTo: "अधिकतम",
    units: "यूनिट",
    monthlyBill: "मासिक बिजली बिल",
    yearlySavings: "अनुमानित वार्षिक बचत",
  },
};

const LocaleContext = createContext<LocaleContextType>({
  locale: "en",
  setLocale: () => {},
  t: (key: string) => key,
  isHi: false,
});

export function LocaleProvider({ children }: { children: ReactNode }) {
  const [locale, setLocaleState] = useState<Locale>("en");

  useEffect(() => {
    // 1. Check path prefix /hi
    const path = window.location.pathname;
    if (path.startsWith("/hi")) {
      setLocaleState("hi");
      return;
    }
    // 2. Cookie or localStorage fallback
    const saved = localStorage.getItem("elios_locale") as Locale | null;
    if (saved === "en" || saved === "hi") {
      setLocaleState(saved);
    }
  }, []);

  const setLocale = (newLoc: Locale) => {
    setLocaleState(newLoc);
    localStorage.setItem("elios_locale", newLoc);
    document.cookie = `elios_locale=${newLoc};path=/;max-age=31536000`;
  };

  const t = (key: string): string => {
    return DICTIONARY[locale]?.[key] || DICTIONARY.en?.[key] || key;
  };

  return (
    <LocaleContext.Provider value={{ locale, setLocale, t, isHi: locale === "hi" }}>
      {children}
    </LocaleContext.Provider>
  );
}

export function useLocale() {
  return useContext(LocaleContext);
}

// en-IN currency formatter helper
export function formatINR(amount: number): string {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(amount);
}
