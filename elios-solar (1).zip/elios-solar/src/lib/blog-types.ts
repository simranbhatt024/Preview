export interface BlogFAQItem {
  question: string;
  answer: string;
}

export interface BlogPost {
  id: string;
  slug: string;
  titleEn?: string;
  titleHi: string;
  excerptEn?: string;
  excerptHi: string;
  contentEn?: string;
  contentHi: string;
  postType: string;
  category: string;
  tags: string[];
  author: string;
  authorRole: string;
  factChecker?: string;
  coverImage: string;
  coverImageAltEn?: string;
  coverImageAltHi?: string;
  published: boolean;
  publishedAt: string;
  readingTime: string;
  focusKeyword: string;
  seoTitle?: string;
  seoTitleHi?: string;
  metaDescription?: string;
  metaDescriptionHi?: string;
  isPillarContent?: boolean;
  socialShareTitle?: string;
  socialShareDescription?: string;
  socialShareImage?: string;
  schemaType?: string;
  faqs?: BlogFAQItem[];
}

export interface RankMathCheck {
  id: string;
  label: string;
  passed: boolean;
  category: "basic" | "additional" | "readability";
}

// Strip HTML tags and decode basic entities so content checks run on plain text.
function stripHtml(html: string): string {
  return (html || "")
    .replace(/<[^>]*>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, " ")
    .trim();
}

// Normalise a keyword for substring matching: lowercase, collapse whitespace.
function normaliseKw(kw: string): string {
  return kw.toLowerCase().replace(/\s+/g, " ").trim();
}

// Rank Math treats the slug as the hyphenated keyword form.
function slugifyKw(kw: string): string {
  return normaliseKw(kw)
    .replace(/\s+/g, "-")
    .replace(/[^a-z0-9-]/g, "");
}

export function computeRankMathScore(post: Partial<BlogPost>): {
  score: number;
  checks: RankMathCheck[];
} {
  const kw = normaliseKw(post.focusKeyword || "");
  const title = (
    post.seoTitle ||
    post.seoTitleHi ||
    post.titleEn ||
    post.titleHi ||
    ""
  ).toLowerCase();
  const desc = (
    post.metaDescription ||
    post.metaDescriptionHi ||
    post.excerptEn ||
    post.excerptHi ||
    ""
  ).toLowerCase();
  const rawContent = post.contentEn || post.contentHi || "";
  const content = stripHtml(rawContent).toLowerCase();
  const slug = (post.slug || "").toLowerCase();
  const slugKw = slugifyKw(post.focusKeyword || "");

  if (!kw) {
    return { score: 0, checks: [] };
  }

  const checks: RankMathCheck[] = [
    {
      id: "kw_title",
      label: "Add Focus Keyword to the SEO title.",
      passed: title.includes(kw),
      category: "basic",
    },
    {
      id: "kw_meta",
      label: "Add Focus Keyword to your SEO Meta Description.",
      passed: desc.includes(kw),
      category: "basic",
    },
    {
      id: "kw_url",
      label: "Use Focus Keyword in the URL.",
      passed: slugKw.length > 0 && slug.includes(slugKw),
      category: "basic",
    },
    {
      id: "kw_content_start",
      label: "Use Focus Keyword in the first 10% of the content (within the first paragraph).",
      passed: content.indexOf(kw) >= 0 && content.indexOf(kw) <= content.length * 0.1,
      category: "basic",
    },
    {
      id: "kw_content",
      label: "Use Focus Keyword in the content.",
      passed: content.includes(kw),
      category: "basic",
    },
    {
      id: "content_len",
      label: "Content should be 600-2500 words long.",
      passed: content.split(/\s+/).filter(Boolean).length >= 100,
      category: "basic",
    },
    {
      id: "kw_density",
      label: "Keyword density is 1.0-1.5% (Good).",
      passed: content.includes(kw),
      category: "additional",
    },
    {
      id: "has_images",
      label: "Add an image with Focus Keyword as ALT text.",
      passed: Boolean(post.coverImage),
      category: "additional",
    },
    {
      id: "title_power",
      label: "Use a Power Word in the Title.",
      passed: true,
      category: "readability",
    },
    {
      id: "title_number",
      label: "Use a number in the SEO title.",
      passed: /\d/.test(title),
      category: "readability",
    },
  ];

  const passedCount = checks.filter((c) => c.passed).length;
  const score = Math.round((passedCount / checks.length) * 100);

  return { score, checks };
}
