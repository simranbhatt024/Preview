// CRM form-tracking helper for Elios Solar Energy.
// Wires every public enquiry form into the connected CRM (form_tracking integration).
// trackingId, locationId and projectId come from the connected integration — never invent them.

type StandardTrackingFieldKey = string;
type RegisteredCustomFieldId = string;
type TrackingCustomField = { value?: unknown; label: string };
type TrackingFileField = { file?: File; label: string };
type TrackingImageDataField = { dataUrl?: string; label: string };

export const CRM_TRACKING_ID = "tk_25fb0f38636c4fc5a0b8b872ed0d24b7";
export const CRM_LOCATION_ID = "uYsSwli1jkaYsCJbWemc";
export const CRM_PROJECT_ID = "1792820769937918655";

// Custom field IDs returned by register_custom_field (stable per project).
export const CRM_CUSTOM_FIELDS = {
  serviceNeeded: "5dh3IaMjxwpObBa8S3EB", // "Service Needed" (SINGLE_OPTIONS)
  leadSource: "YYlaa4AiQ3yEJNiDiJcA", // "Lead Source" (TEXT)
  estimatedReferrals: "pqrVOKPIRuqbxHSDJHbS", // "Estimated Referrals" (TEXT)
  college: "DOKewEhWPkOEmVJzyL09", // "College/Institution" (TEXT)
  investmentCapacity: "JTEsrviozmk3n9ijvbVK", // "Investment Capacity" (TEXT)
  targetDistrict: "3FUfrBd6w1q838jsubx4", // "Target District" (TEXT)
} as const;

const postTrackingEvent = (
  trackingPayload: Record<string, unknown> & {
    formData: Record<StandardTrackingFieldKey, unknown>;
    formLabels: Record<StandardTrackingFieldKey, string>;
  },
  options: {
    customFields?: Record<RegisteredCustomFieldId, TrackingCustomField>;
    fileFields?: Record<RegisteredCustomFieldId, TrackingFileField>;
    imageDataFields?: Record<RegisteredCustomFieldId, TrackingImageDataField>;
  } = {},
) => {
  const { customFields = {}, fileFields = {}, imageDataFields = {} } = options;
  const eventPayload = {
    ...trackingPayload,
    formData: { ...trackingPayload.formData },
    formLabels: { ...trackingPayload.formLabels },
  };
  const body = new FormData();

  for (const [key, field] of Object.entries(customFields)) {
    if (field.value === undefined) continue;
    eventPayload.formData[key] = field.value;
    eventPayload.formLabels[key] = field.label;
  }

  for (const [key, field] of Object.entries(imageDataFields)) {
    const dataUrl = field.dataUrl;
    if (!dataUrl) continue;
    if (!dataUrl.startsWith("data:image/")) {
      throw new Error("Image data field must be a data:image/* base64 string");
    }
    eventPayload.formData[key] = dataUrl;
    eventPayload.formLabels[key] = field.label;
  }

  for (const [key, field] of Object.entries(fileFields)) {
    const file = field.file;
    if (!file) continue;
    if (file.size > 50 * 1024 * 1024) {
      throw new Error("File must be 50 MB or smaller");
    }
    eventPayload.formData[key] = {
      filename: file.name,
      size: file.size,
      type: file.type || "application/octet-stream",
    };
    eventPayload.formLabels[key] = field.label;
    body.append(key, file, file.name);
  }

  for (const key of Object.keys(eventPayload.formData)) {
    eventPayload.formLabels[key] ||= key;
  }

  body.append("event", JSON.stringify(eventPayload));

  fetch("https://backend.leadconnectorhq.com/external-tracking/events", {
    method: "POST",
    headers: {
      version: "2021-07-28",
    },
    body,
  }).catch(() => {}); // Fire-and-forget — don't block form UX
};

// Reuse the published site's analytics session (set by /__vibe/analytics.js) so the
// submission joins the visit's page views; fall back to a fresh id when it is absent
// or unreadable (document.cookie throws in a sandboxed iframe).
const getTrackingSessionId = () => {
  try {
    const sid = document.cookie.match(/(?:^|;\s*)__vibe_sid=([0-9a-f-]{36})(?:;|$)/)?.[1];
    if (sid) return sid;
  } catch {}
  return crypto.randomUUID();
};

export interface LeadInput {
  formId: string;
  formName: string;
  fullName: string;
  phone: string;
  email?: string;
  city?: string;
  serviceNeeded?: string;
  source: string;
  message?: string;
  custom?: Record<RegisteredCustomFieldId, TrackingCustomField>;
}

// Save a lead locally (admin inbox) AND push it to the CRM as a contact.
export function submitLeadToCRM(lead: LeadInput) {
  // 1) Local persistence (admin leads inbox reads this).
  try {
    const existing = JSON.parse(localStorage.getItem("elios_leads") || "[]");
    existing.unshift({
      id: "lead_" + Date.now(),
      createdAt: new Date().toISOString(),
      fullName: lead.fullName,
      phone: lead.phone,
      email: lead.email || "",
      city: lead.city || "",
      serviceNeeded: lead.serviceNeeded || "",
      source: lead.source,
      message: lead.message || "",
    });
    localStorage.setItem("elios_leads", JSON.stringify(existing));
  } catch {}

  // 2) CRM push (non-blocking).
  try {
    const [firstName, ...rest] = lead.fullName.trim().split(/\s+/);
    const lastName = rest.length ? rest.join(" ") : lead.fullName.trim();

    const trackingPayload = {
      type: "external_form_submission",
      timestamp: Date.now(),
      formId: lead.formId,
      formData: {
        first_name: firstName,
        last_name: lastName,
        phone: lead.phone,
        email: lead.email || "",
        city: lead.city || "",
        calendar_notes: lead.message || "",
      },
      formLabels: {
        first_name: "First Name",
        last_name: "Last Name",
        phone: "Phone Number",
        email: "Email Address",
        city: "City",
        calendar_notes: "Message",
      },
      url: window.location.href,
      title: document.title,
      path: window.location.pathname,
      userAgent: navigator.userAgent,
      trackingId: CRM_TRACKING_ID,
      locationId: CRM_LOCATION_ID,
      projectId: CRM_PROJECT_ID,
      sessionId: getTrackingSessionId(),
      properties: {
        deviceType: /Mobile|Android|iPhone/i.test(navigator.userAgent) ? "mobile" : "desktop",
        source: "ai_studio",
        projectId: CRM_PROJECT_ID,
        formName: lead.formName,
      },
    };

    const customFields: Record<RegisteredCustomFieldId, TrackingCustomField> = {
      ...(lead.serviceNeeded
        ? {
            [CRM_CUSTOM_FIELDS.serviceNeeded]: {
              value: lead.serviceNeeded,
              label: "Service Needed",
            },
          }
        : {}),
      [CRM_CUSTOM_FIELDS.leadSource]: { value: lead.source, label: "Lead Source" },
      ...(lead.custom || {}),
    };

    postTrackingEvent(trackingPayload, { customFields });
  } catch {}
}
