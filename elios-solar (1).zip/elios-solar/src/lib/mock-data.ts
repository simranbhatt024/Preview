// State management and mockable store for Elios Solar
// Handles leads, contact requests, and admin editable settings

export interface Lead {
  id: string;
  createdAt: string;
  fullName: string;
  phone: string;
  email?: string;
  city: string;
  serviceNeeded: string;
  source: string;
  message?: string;
  extra?: Record<string, any>;
}

export interface ChatMessage {
  id: string;
  conversationId: string;
  direction: "inbound" | "outbound" | "system";
  body: string;
  senderName?: string;
  senderPhone?: string;
  createdAt: string;
}

export type { ProductSpec, ProductItem } from "./products-catalog";
export { INITIAL_PRODUCTS } from "./products-catalog";

export interface PackageItem {
  slug: string;
  tier: "silver" | "gold" | "platinum";
  nameEn: string;
  nameHi: string;
  originalPrice: number;
  offerPrice: number;
  isPopular?: boolean;
  featuresEn: string[];
  featuresHi: string[];
}

export interface BlogPost {
  id?: string;
  slug: string;
  titleEn: string;
  titleHi: string;
  excerptEn: string;
  excerptHi: string;
  contentEn: string;
  contentHi: string;
  category: string;
  author: string;
  authorRole?: string;
  publishedAt: string;
  readingTime: string;
  coverImage: string;
  focusKeyword?: string;
  seoTitle?: string;
  metaDescription?: string;
}

export interface FAQItem {
  slug: string;
  questionEn: string;
  questionHi: string;
  answerEn: string;
  answerHi: string;
  category: string;
}

// INITIAL_PRODUCTS is re-exported from ./products-catalog above.

export const INITIAL_PACKAGES: PackageItem[] = [
  {
    slug: "silver-annual-solar-care",
    tier: "silver",
    nameEn: "Silver Annual Solar Care",
    nameHi: "सिल्वर वार्षिक सोलर केयर",
    originalPrice: 2999,
    offerPrice: 1299,
    featuresEn: [
      "2 professional cleaning visits per year",
      "Annual plant performance & generation report",
      "Dedicated phone support (9 AM – 6 PM)",
      "Solar monitoring dashboard access",
    ],
    featuresHi: [
      "प्रति वर्ष 2 पेशेवर सफाई विज़िट",
      "वार्षिक प्लांट प्रदर्शन एवं उत्पादन रिपोर्ट",
      "समर्पित फोन सहायता (सुबह 9 - शाम 6)",
      "सोलर मॉनिटरिंग डैशबोर्ड एक्सेस",
    ],
  },
  {
    slug: "gold-priority-solar-care",
    tier: "gold",
    nameEn: "Gold Priority Solar Care",
    nameHi: "गोल्ड प्रायोरिटी सोलर केयर",
    originalPrice: 7999,
    offerPrice: 2399,
    isPopular: true,
    featuresEn: [
      "4 professional cleaning visits per year",
      "Quarterly performance report",
      "Priority WhatsApp & phone engineering support",
      "Real-time alerts & remote monitoring",
      "Minor parts replacement coverage",
    ],
    featuresHi: [
      "प्रति वर्ष 4 पेशेवर सफाई विज़िट",
      "त्रैमासिक प्रदर्शन रिपोर्ट",
      "प्राथमिकता व्हाट्सएप एवं फोन तकनीकी सहायता",
      "रीयल-टाइम अलर्ट एवं रिमोट मॉनिटरिंग",
      "छोटे पुर्जों का प्रतिस्थापन कवरेज",
    ],
  },
  {
    slug: "platinum-comprehensive-solar-care",
    tier: "platinum",
    nameEn: "Platinum Total EPC Care",
    nameHi: "प्लैटिनम संपूर्ण ईपीसी केयर",
    originalPrice: 11999,
    offerPrice: 5999,
    featuresEn: [
      "6 to 8 cleaning visits per year based on plant condition",
      "Monthly generation & degradation report",
      "Dedicated account manager",
      "Active remote plant monitoring & health tracking",
      "All parts replacement warranty coverage",
      "24/7 emergency dispatch or same-day inspection",
    ],
    featuresHi: [
      "प्लांट की स्थिति अनुसार प्रति वर्ष 6 से 8 सफाई विज़िट",
      "मासिक उत्पादन एवं रिपोर्ट",
      "समर्पित अकाउंट मैनेजर",
      "सक्रिय रिमोट प्लांट मॉनिटरिंग एवं स्वास्थ्य ट्रैकिंग",
      "सभी पुर्जों के प्रतिस्थापन की वारंटी",
      "24/7 आपातकालीन सेवा अथवा उसी दिन निरीक्षण",
    ],
  },
];

export const INITIAL_POSTS: BlogPost[] = [
  {
    slug: "how-rooftop-solar-installation-works",
    titleEn: "How a Rooftop Solar Installation Works, From Site Visit to Switch-On",
    titleHi: "रूफटॉप सोलर इंस्टॉलेशन कैसे काम करता है: साइट विज़िट से लेकर स्विच-ऑन तक",
    excerptEn:
      "Understanding the end-to-end EPC process ensures smooth engineering, timely structural setup, DISCOM bi-directional net metering, and hassle-free power generation.",
    excerptHi:
      "शुरुआती इंजीनियरिंग से लेकर डिस्कॉम बायो-डायरेक्शनल नेट मीटरिंग तक, रूफटॉप सोलर स्थापना की संपूर्ण चरणबद्ध प्रक्रिया समझें।",
    category: "Installation Tips",
    author: "Elios Solar Team",
    publishedAt: "2026-03-15",
    readingTime: "5 min read",
    coverImage:
      "https://vibe.filesafe.space/1792820769937918655/assets/176fee8d-679a-4bc7-842d-c24b2c667d29.png",
    contentEn: `
      <h2>1. Detailed Shadow & Structural Rooftop Assessment</h2>
      <p>Before any equipment arrives, certified solar engineers from Elios perform a shadow-free area calculation and roof load evaluation. We inspect the structural integrity of RCC roofs, sheet sheds, or terrace spaces across Bihar to determine exact tilt angle and azimuth for maximum solar irradiation.</p>
      <h2>2. Precision Engineering & Equipment Selection</h2>
      <p>Choosing Tier-1 ALMM-listed monocrystalline solar modules and robust grid-tied inverters tailored to local grid stability. Lightning arresters, copper earthing pits, and DC/AC distribution boxes with surge protection devices (SPDs) are designed for long-term safety.</p>
      <h2>3. Professional Mechanical & Electrical Mounting</h2>
      <p>Hot-dip galvanized mounting structures withstand high wind loads. Solar panels are clamped firmly without causing water seepage or damaging terrace waterproofing. Cables are neatly sleeved in UV-resistant conduits.</p>
      <h2>4. DISCOM Inspection & Net Metering Synchronization</h2>
      <p>Elios handles the complete documentation and filing with local DISCOMs across Bihar (such as NBPDCL and SBPDCL). Once the bi-directional net meter is energized, surplus solar units feed directly into the grid, running your meter backwards.</p>
    `,
    contentHi: `
      <h2>1. छाया-मुक्त क्षेत्र एवं छत की संरचनात्मक जांच</h2>
      <p>उपकरण लगाने से पहले, एलियोस के प्रमाणित इंजीनियर छत का लोड और छाया-मुक्त क्षेत्र मापते हैं। अधिकतम सूर्य की रोशनी पाने के लिए झुकाव कोण (टिल्ट एंगल) निर्धारित किया जाता है।</p>
      <h2>2. उच्च गुणवत्ता वाले उपकरणों का चयन</h2>
      <p>उच्च कोटि के सोलर पैनल और कुशल इन्वर्टर चुने जाते हैं। तड़ित चालक (लाइटनिंग अरेस्टर) और कॉपर अर्थिंग के साथ सुरक्षा के सभी मानक पूरे किए जाते हैं।</p>
      <h2>3. मजबूत संरचना और वायरिंग</h2>
      <p>हवा के दबाव को सहने वाले मजबूत गैल्वेनाइज्ड स्ट्रक्चर लगाए जाते हैं ताकि छत को कोई नुकसान न पहुंचे।</p>
      <h2>4. नेट मीटरिंग और ग्रिड सिंक्रोनाइज़ेशन</h2>
      <p>एलियोस स्थानीय बिजली वितरण कंपनी (NBPDCL / SBPDCL) के साथ नेट मीटरिंग की पूरी कागजी कार्रवाई संभालती है, जिससे अतिरिक्त बिजली ग्रिड में जाकर आपका बिल शून्य की ओर ले जाती है।</p>
    `,
  },
  {
    slug: "pm-surya-ghar-muft-bijli-yojana-bihar-homeowners",
    titleEn: "PM Surya Ghar Muft Bijli Yojana: What Homeowners Should Know",
    titleHi: "पीएम सूर्य घर मुफ्त बिजली योजना: बिहार के घर-मालिकों के लिए आवश्यक जानकारी",
    excerptEn:
      "Central government subsidy offers up to ₹78,000 for residential rooftop systems. Learn the step-by-step paperwork and timeline requirements.",
    excerptHi:
      "आवासीय रूफटॉप सोलर पर केंद्र सरकार द्वारा अधिकतम ₹78,000 तक की सब्सिडी। जानिए आवेदन प्रक्रिया और आवश्यक नियम।",
    category: "Subsidy & Finance",
    author: "Elios Solar Team",
    publishedAt: "2026-03-20",
    readingTime: "6 min read",
    coverImage:
      "https://vibe.filesafe.space/1792820769937918655/assets/46dbcc50-bb8b-4dbc-a0b8-904c9dabcd2a.png",
    contentEn: `
      <h2>Central Subsidy Structure Under PM Surya Ghar</h2>
      <p>The central initiative makes clean solar power affordable for residential homes:</p>
      <ul>
        <li><strong>1 kW System:</strong> ₹30,000 central subsidy</li>
        <li><strong>2 kW System:</strong> ₹60,000 central subsidy</li>
        <li><strong>3 kW to 10 kW Systems:</strong> Up to ₹78,000 central subsidy</li>
      </ul>
      <p><em>Disclaimer: Subsidy amounts depend on eligibility and current scheme rules. Figures are shown as up to amounts. Confirm on the official PM Surya Ghar portal at pmsuryaghar.gov.in before you apply.</em></p>
      <h2>Single-Point Documentation with Elios Solar</h2>
      <p>Applying on the National Portal requires DISCOM consumer account validation, technical feasibility approval, and post-installation commissioning inspection. Elios Solar Energy manages this entire submission so your DBT (Direct Benefit Transfer) subsidy arrives smoothly in your linked bank account.</p>
    `,
    contentHi: `
      <h2>पीएम सूर्य घर के तहत सब्सिडी संरचना</h2>
      <p>केंद्र सरकार की इस योजना से आवासीय घरों के लिए सोलर अपनाना अत्यंत किफायती हो गया है:</p>
      <ul>
        <li><strong>1 किलोवाट:</strong> ₹30,000 तक केंद्र सब्सिडी</li>
        <li><strong>2 किलोवाट:</strong> ₹60,000 तक केंद्र सब्सिडी</li>
        <li><strong>3 किलोवाट या अधिक:</strong> अधिकतम ₹78,000 तक केंद्र सब्सिडी</li>
      </ul>
      <p><em>अस्वीकरण: सब्सिडी की राशि पात्रता और योजना के वर्तमान नियमों पर निर्भर करती है। आंकड़े 'अधिकतम' के रूप में दर्शाए गए हैं। आधिकारिक पोर्टल pmsuryaghar.gov.in पर पुष्टि करें।</em></p>
      <h2>एलियोस के साथ आसान दस्तावेज़ीकरण</h2>
      <p>राष्ट्रीय पोर्टल पर आवेदन से लेकर तकनीकी स्वीकृति और कमीशनिंग तक, एलियोस सोलर आपके सारे कागजात संभालती है ताकि सब्सिडी सीधे आपके खाते में आए।</p>
    `,
  },
  {
    slug: "what-is-solar-epc-company-and-why-it-matters",
    titleEn: "What Is a Solar EPC Company and Why It Matters",
    titleHi: "सोलर ईपीसी (EPC) कंपनी क्या है और यह क्यों महत्वपूर्ण है",
    excerptEn:
      "Engineering, Procurement, and Construction under a single accountable partner ensures consistent warranties, certified installation, and long-term generation safety.",
    excerptHi:
      "इंजीनियरिंग, खरीद और निर्माण को एक ही जिम्मेदार कंपनी द्वारा संभालना दीर्घकालिक सुरक्षा और गारंटी सुनिश्चित करता है।",
    category: "Solar Basics",
    author: "Elios Solar Team",
    publishedAt: "2026-03-25",
    readingTime: "5 min read",
    coverImage:
      "https://vibe.filesafe.space/1792820769937918655/assets/4c644fa6-a91f-4135-8bc5-55e7e960e282.png",
    contentEn: `
      <h2>The Three Pillars of EPC</h2>
      <p><strong>1. Engineering:</strong> Custom 3D layout simulation, electrical single-line diagrams, load calculation, earthing design, and cable sizing according to Indian electrical standards.</p>
      <p><strong>2. Procurement:</strong> Sourcing high-efficiency modules, heavy galvanised structures, tier-1 inverters, and certified DC components with manufacturer-backed warranties.</p>
      <p><strong>3. Construction & Commissioning:</strong> Skilled technicians, safe anchor-bolting, waterproof roof sealing, rigorous testing, DISCOM net metering liaison, and final switch-on.</p>
      <h2>Why Avoid Fragmented Contractors</h2>
      <p>When you buy panels from one trader, structures from a local fabricator, and hire an electrician, finger-pointing occurs when faults happen. An EPC company like Elios takes 100% turnkey ownership from roof inspection to 25-year solar generation.</p>
    `,
    contentHi: `
      <h2>ईपीसी के तीन मुख्य स्तंभ</h2>
      <p><strong>1. इंजीनियरिंग:</strong> छत का 3D लेआउट, लोड गणना और भारतीय मानकों के अनुसार सुरक्षित डिजाइन।</p>
      <p><strong>2. प्रोक्योरमेंट (खरीद):</strong> उच्च दक्षता वाले प्रमाणित सोलर मॉड्यूल, भारी गैल्वेनाइज्ड स्ट्रक्चर और विश्वस्तरीय इन्वर्टर की सीधी आपूर्ति।</p>
      <p><strong>3. कंस्ट्रक्शन (निर्माण एवं परीक्षण):</strong> सुरक्षित इंस्टॉलेशन, मजबूत वाटरप्रूफिंग, परीक्षण और डिस्कॉम नेट मीटरिंग चालू कराना।</p>
      <h2>एक ही कंपनी के साथ काम करने का लाभ</h2>
      <p>अलग-अलग वेंडरों से सामान खरीदने पर समस्या होने पर कोई जिम्मेदारी नहीं लेता। एलियोस जैसी संपूर्ण ईपीसी कंपनी 100% जिम्मेदारी निभाती है।</p>
    `,
  },
];

export const INITIAL_FAQS: FAQItem[] = [
  {
    slug: "how-much-can-rooftop-solar-reduce-my-electricity-bill",
    questionEn: "How much can rooftop solar reduce my electricity bill?",
    questionHi: "रूफटॉप सोलर से मेरा बिजली बिल कितना कम हो सकता है?",
    category: "General",
    answerEn:
      "Rooftop solar can reduce your monthly grid power expense by up to 80% to 90% depending on your sanctioned electrical load, available shadow-free roof area, and your household or business consumption patterns. With net metering, excess solar electricity exported to the DISCOM offsets your evening and night usage. You can use our interactive Solar Calculator to view an instant estimate based on your monthly bill.",
    answerHi:
      "रूफटॉप सोलर आपके मासिक बिजली बिल को 80% से 90% तक कम कर सकता है, जो आपकी छत के क्षेत्रफल और खपत पर निर्भर करता है। नेट मीटरिंग के माध्यम से दिन में बनी अतिरिक्त बिजली ग्रिड को दी जाती है और रात की खपत से समायोजित होती है। सटीक आकलन के लिए हमारे सोलर कैलकुलेटर का उपयोग करें।",
  },
  {
    slug: "is-there-government-subsidy-for-housing-societies",
    questionEn: "Is there any government subsidy for housing societies?",
    questionHi: "क्या हाउसिंग सोसायटियों के लिए सरकारी सब्सिडी उपलब्ध है?",
    category: "Housing Society",
    answerEn:
      "Under the current PM Surya Ghar scheme guidelines, central direct financial subsidy is specifically designated for individual residential homes. There is currently no central subsidy available for housing society common-area meters. However, powering society common lifts, pump sets, water treatment, and corridor lighting through rooftop solar significantly reduces common maintenance charges and provides rapid payback through operational savings.",
    answerHi:
      "वर्तमान पीएम सूर्य घर योजना के तहत केंद्रीय सब्सिडी केवल व्यक्तिगत आवासीय घरों के लिए उपलब्ध है। हाउसिंग सोसायटियों के कॉमन-एरिया मीटरों के लिए वर्तमान में कोई केंद्रीय सब्सिडी नहीं है। फिर भी, लिफ्ट, पानी की मोटर और कॉरिडोर लाइट को सोलर पर चलाने से मासिक मेंटेनेंस खर्च में भारी बचत होती है।",
  },
  {
    slug: "what-is-a-solar-epc-company-and-why-choose-one",
    questionEn: "What is a solar EPC company and why should I choose one?",
    questionHi: "सोलर ईपीसी कंपनी क्या है और इसे क्यों चुनना चाहिए?",
    category: "EPC",
    answerEn:
      "An EPC (Engineering, Procurement, and Construction) company provides complete turnkey solutions: site feasibility survey, system design, procuring tier-1 equipment, structural installation, electrical wiring, DISCOM net-metering approvals, and post-installation monitoring. Elios Solar Energy handles the entire cycle end-to-end, so you have a single accountable partner with unified warranties and ongoing service support.",
    answerHi:
      "ईपीसी कंपनी छत के निरीक्षण, सिस्टम डिजाइन, उच्च गुणवत्ता वाले उपकरण, सुरक्षित इंस्टॉलेशन, डिस्कॉम नेट-मीटरिंग और इंस्टॉलेशन के बाद सेवा की पूरी जिम्मेदारी एक ही छत के नीचे संभालती है। एलियोस सोलर के साथ आपको अलग-अलग ठेकेदारों के चक्कर नहीं काटने पड़ते।",
  },
];

export const BIHAR_CITIES = [
  {
    slug: "patna",
    nameEn: "Patna",
    nameHi: "पटना",
    addressEn: "Bailey Road / Kankarbagh, Patna, Bihar",
    addressHi: "बेली रोड / कंकड़बाग, पटना, बिहार",
    phone: "+91 91539 33318",
    lat: 25.5941,
    lng: 85.1376,
    bookingMode: "both",
  },
  {
    slug: "gaya",
    nameEn: "Gaya",
    nameHi: "गया",
    addressEn: "Civil Lines, Gaya, Bihar",
    addressHi: "सिविल लाइंस, गया, बिहार",
    phone: "+91 91539 33318",
    lat: 24.7914,
    lng: 85.0002,
    bookingMode: "both",
  },
  {
    slug: "muzaffarpur",
    nameEn: "Muzaffarpur",
    nameHi: "मुज़फ़्फ़रपुर",
    addressEn: "Club Road, Muzaffarpur, Bihar",
    addressHi: "क्लब रोड, मुज़फ़्फ़रपुर, बिहार",
    phone: "+91 91539 33318",
    lat: 26.1209,
    lng: 85.3647,
    bookingMode: "both",
  },
  {
    slug: "bhagalpur",
    nameEn: "Bhagalpur",
    nameHi: "भागलपुर",
    addressEn: "Station Road, Bhagalpur, Bihar",
    addressHi: "स्टेशन रोड, भागलपुर, बिहार",
    phone: "+91 91539 33318",
    lat: 25.2425,
    lng: 86.9842,
    bookingMode: "both",
  },
  {
    slug: "darbhanga",
    nameEn: "Darbhanga",
    nameHi: "दरभंगा",
    addressEn: "Laheriasarai, Darbhanga, Bihar",
    addressHi: "लहेरियासराय, दरभंगा, बिहार",
    phone: "+91 91539 33318",
    lat: 26.1542,
    lng: 85.8918,
    bookingMode: "both",
  },
  {
    slug: "purnia",
    nameEn: "Purnia",
    nameHi: "पूर्णिया",
    addressEn: "Bhatta Bazar, Purnia, Bihar",
    addressHi: "भट्ठा बाज़ार, पूर्णिया, बिहार",
    phone: "+91 91539 33318",
    lat: 25.7771,
    lng: 87.4753,
    bookingMode: "both",
  },
];
