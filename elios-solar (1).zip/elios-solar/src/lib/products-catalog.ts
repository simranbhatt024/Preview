// Dedicated Products Catalog for Elios Solar Energy
// Replicating Waaree-grade product classifications: PV Modules, Inverters & All-in-One Solar Kits

export interface ProductSpec {
  label: string;
  value: string;
}

export interface ProductItem {
  id: string;
  slug: string;
  nameEn: string;
  nameHi: string;
  category: "pv_modules" | "inverters" | "solar_kits";
  subcategory: string;
  taglineEn: string;
  taglineHi: string;
  descriptionEn: string;
  descriptionHi: string;
  featuresEn: string[];
  featuresHi: string[];
  specs: ProductSpec[];
  applicationsEn: string;
  applicationsHi: string;
  sku: string;
  price?: number;
  image: string;
}

export const INITIAL_PRODUCTS: ProductItem[] = [
  // ==========================================
  // === 1. PV MODULES ===
  // ==========================================
  {
    id: "pv-hjt",
    slug: "hjt-module",
    nameEn: "HJT Heterojunction Solar Module",
    nameHi: "एचजेटी हेट्रोजंक्शन सोलर मॉड्यूल",
    category: "pv_modules",
    subcategory: "HJT Technology",
    taglineEn: "Experience higher efficiency and durability with our HJT modules.",
    taglineHi: "एचजेटी मॉड्यूल के साथ उच्च दक्षता और स्थायित्व का अनुभव करें।",
    descriptionEn:
      "High reliability and enhanced crack tolerance with best-in-class thermal coefficients. Engineered to sustain heavy snow & wind loads (5400 Pa & 2400 Pa) with superior weak-light performance for maximum energy yields in Bihar.",
    descriptionHi:
      "उच्च विश्वसनीयता, क्रैक सहनशीलता और श्रेणी में सर्वश्रेष्ठ थर्मल गुणांक। भारी बर्फ और हवा के दबाव को झेलने तथा कम धूप में भी उत्कृष्ट प्रदर्शन के लिए निर्मित।",
    featuresEn: [
      "High reliability and enhanced crack tolerance",
      "Best-in-class thermal coefficients for hot summer climates",
      "Sustains heavy snow & wind loads (5400 Pa & 2400 Pa)",
      "Superior weak-light and morning/evening irradiation performance",
    ],
    featuresHi: [
      "उच्च विश्वसनीयता और उन्नत क्रैक सहनशीलता",
      "गर्मी के मौसम हेतु सर्वश्रेष्ठ थर्मल गुणांक",
      "भारी दबाव (5400 Pa एवं 2400 Pa) सहने में सक्षम",
      "कम धूप और सुबह-शाम का बेहतर प्रदर्शन",
    ],
    specs: [
      { label: "Power Output", value: "700W to 730W" },
      { label: "Module Efficiency", value: "Up to 23.5%" },
      { label: "Warranty", value: "30-Year Performance" },
      { label: "Cell Type", value: "Bifacial Heterojunction (HJT)" },
    ],
    applicationsEn:
      "Residential rooftops, commercial establishments, and heavy industrial facilities.",
    applicationsHi: "आवासीय छतें, व्यावसायिक परिसर एवं भारी औद्योगिक इकाइयाँ।",
    sku: "ELIOS-HJT-700W",
    image:
      "https://vibe.filesafe.space/1792820769937918655/assets/edd7fdc6-f99c-4e66-82ca-4b30f178e6ab.jpg",
  },
  {
    id: "pv-ntype",
    slug: "n-type-topcon-module",
    nameEn: "N-Type TOPCon Bifacial Solar Module",
    nameHi: "एन-टाइप टॉपकॉन बायोफेशियल सोलर मॉड्यूल",
    category: "pv_modules",
    subcategory: "TOPCon Technology",
    taglineEn: "Reduce recombination losses and accelerate your clean energy transition.",
    taglineHi: "ऊर्जा हानि को कम करें और अपनी हरित ऊर्जा यात्रा को गति दें।",
    descriptionEn:
      "Next-generation tunnel oxide passivated contact (TOPCon) technology with higher bifaciality, zero light-induced degradation (LID), and superior temperature coefficient.",
    descriptionHi:
      "सुरक्षित एन-टाइप टॉपकॉन तकनीक, जो शून्य एलआईडी और उच्च बायोफेशियल लाभ के साथ अधिकतम बिजली बनाती है।",
    featuresEn: [
      "Advanced TOPCon cell architecture with zero LID",
      "High bifacial gain generating up to 25% extra from the rear side",
      "Excellent low-irradiance output on cloudy days",
      "Certified for rigorous salt-mist and ammonia corrosion resistance",
    ],
    featuresHi: [
      "उन्नत टॉपकॉन आर्किटेक्चर (शून्य एलआईडी)",
      "पीछे की सतह से 25% तक अतिरिक्त उत्पादन",
      "बादल छाए रहने पर भी निरंतर कार्य",
      "जंग और धूल प्रतिरोधी कोटिंग",
    ],
    specs: [
      { label: "Power Output", value: "565W to 715W" },
      { label: "Module Efficiency", value: "Up to 23.02%" },
      { label: "Frame", value: "35 mm Anodized Aluminum" },
      { label: "Warranty", value: "30-Year Performance" },
    ],
    applicationsEn:
      "Ideal for residential rooftops, housing society common meters, and industrial sheds.",
    applicationsHi: "आवासीय घर, हाउसिंग सोसायटियाँ और औद्योगिक शेड के लिए आदर्श।",
    sku: "ELIOS-TOPCON-570W",
    image:
      "https://vibe.filesafe.space/1792820769937918655/assets/61398e63-fe9a-41ea-a026-7077734d8acb.jpg",
  },
  {
    id: "pv-perc",
    slug: "mono-perc-half-cut-module",
    nameEn: "Mono PERC Half-Cut Solar Module",
    nameHi: "मोनो पर्क हाफ-कट सोलर मॉड्यूल",
    category: "pv_modules",
    subcategory: "Mono PERC",
    taglineEn: "Experience higher energy yields and minimal long-term degradation.",
    taglineHi: "उच्च ऊर्जा उत्पादन और न्यूनतम दीर्घकालिक गिरावट का अनुभव करें।",
    descriptionEn:
      "Reliable monocrystalline PERC half-cut cell technology minimizing internal resistance losses and delivering consistent power in high-temperature environments across Bihar.",
    descriptionHi:
      "विश्वसनीय मोनोक्रिस्टलाइन पर्क हाफ-कट तकनीक जो आंतरिक प्रतिरोध को घटाकर उच्च तापमान में भी निरंतर बिजली देती है।",
    featuresEn: [
      "High-grade silicon wafers ensuring verified ALMM/MNRE compliance",
      "Half-cut design mitigates hot-spot risks and shade impact",
      "Anti-reflective HTAR front glass maximizing light intake",
      "Robust mechanical load rating up to 5400 Pa",
    ],
    featuresHi: [
      "एमएनआरई / एएलएमएम अनुमोदित उच्च गुणवत्ता सिलिकॉन वेफ़र",
      "हाफ-कट डिज़ाइन से छाया का प्रभाव न्यूनतम",
      "एंटी-रिफ्लेक्टिव फ्रंट ग्लास",
      "मजबूत 5400 Pa मैकेनिकल लोड क्षमता",
    ],
    specs: [
      { label: "Power Output", value: "540W to 590W" },
      { label: "Module Efficiency", value: "21.2% (+/- 1%)" },
      { label: "Cells", value: "144 / 156 Half-Cut Cells" },
      { label: "Warranty", value: "12-Year Product / 30-Year Output" },
    ],
    applicationsEn:
      "Standard PM Surya Ghar residential installations and commercial net-metered rooftops.",
    applicationsHi: "पीएम सूर्य घर आवासीय योजना और व्यावसायिक रूफटॉप नेट मीटरिंग।",
    sku: "ELIOS-PERC-550W",
    image:
      "https://vibe.filesafe.space/1792820769937918655/assets/ae382df5-b0e6-4cc1-b0dd-d7f7d5b7cfec.jpg",
  },
  {
    id: "pv-flexible",
    slug: "lightweight-flexible-solar-module",
    nameEn: "Light-Weight Flexible Solar Module",
    nameHi: "अल्ट्रा-लाइटवेट फ्लेक्सिबल सोलर मॉड्यूल",
    category: "pv_modules",
    subcategory: "Specialized Modules",
    taglineEn: "Power up unconventional spaces with ultra-light, bendable solar innovation.",
    taglineHi: "अनोखी छतों और घुमावदार सतहों को मोड़ने योग्य सोलर से ऊर्जावान बनाएं।",
    descriptionEn:
      "Ultra-thin bendable solar panels designed for curved surfaces, tensile membranes, low-load bearing rooftops, transport, and specialized architectural applications.",
    descriptionHi:
      "अल्ट्रा-थिन बेंड होने वाले सोलर पैनल, जो घुमावदार छतों, टिन शेड और कम भार सहने वाली छतों के लिए डिज़ाइन किए गए हैं।",
    featuresEn: [
      "70% lighter than conventional glass solar panels",
      "Bends seamlessly to match curved or tensile roofs without cracking",
      "Rapid peel-and-bond or mechanical mounting without penetrating roofs",
      "Ideal for warehouses, portacabins, and low-load industrial roofs",
    ],
    featuresHi: [
      "पारंपरिक ग्लास पैनलों से 70% हल्का",
      "घुमावदार छतों पर बिना टूटे आसानी से मुड़ता है",
      "छत में छेद किए बिना आसान स्थापना",
      "गोदामों और कम भार वाली छतों के लिए उपयुक्त",
    ],
    specs: [
      { label: "Module Efficiency", value: "Up to 18.13%" },
      { label: "Thickness", value: "< 3.5 mm" },
      { label: "Weight Reduction", value: "70% lighter" },
      { label: "Roof Strength Req.", value: "8 kg/m²" },
    ],
    applicationsEn:
      "Tensile membrane structures, curved metal sheets, transport, and low-load warehouses.",
    applicationsHi: "घुमावदार धातु की छतें, पोर्टाकेबिन और कम लोड वाले गोदाम।",
    sku: "ELIOS-FLEX-350W",
    image:
      "https://vibe.filesafe.space/1792820769937918655/assets/186d4345-a8a7-4649-a35c-dc987aee4a2f.jpg",
  },

  // ==========================================
  // === 2. INVERTERS (Waaree-grade Lineup) ===
  // ==========================================
  {
    id: "inv-single-phase",
    slug: "single-phase-on-grid-inverter",
    nameEn: "Single Phase On-Grid Solar Inverter",
    nameHi: "सिंगल-फेज ऑन-ग्रिड सोलर इन्वर्टर",
    category: "inverters",
    subcategory: "Single Phase On Grid Inverter",
    taglineEn: "Reliable power conversion engineered for everyday homes.",
    taglineHi: "आवासीय घरों के लिए विश्वसनीय और कुशल बिजली रूपांतरण।",
    descriptionEn:
      "Reliable power supply, even in adverse weather conditions. Built to withstand tough environmental conditions, ensuring durability. Enhance safety and control with the built-in DC switch, giving you complete peace of mind. Ideal for powering homes of all sizes across Bihar, providing clean energy and reducing electricity costs.",
    descriptionHi:
      "कठिन मौसम में भी निरंतर विश्वसनीय बिजली आपूर्ति। इन-बिल्ट डीसी स्विच, वाई-फाई मॉनिटरिंग और मजबूत वाटरप्रूफ हाउसिंग। बिहार के सभी आकारों के घरों के लिए आदर्श।",
    featuresEn: [
      "Reliable power supply, even in adverse weather conditions",
      "Built to withstand tough environmental conditions, ensuring durability",
      "Enhance safety and control with the built-in DC switch",
      "Ideal for powering homes of all sizes, reducing electricity costs",
      "Built-in Wi-Fi and mobile app real-time generation tracking",
    ],
    featuresHi: [
      "प्रतिकूल मौसम में भी विश्वसनीय बिजली आपूर्ति",
      "मजबूत पर्यावरण-रोधी निर्माण दीर्घायु हेतु",
      "इन-बिल्ट डीसी स्विच से पूर्ण सुरक्षा और नियंत्रण",
      "सभी आकारों के घरों के लिए उपयुक्त",
      "वाई-फाई एवं मोबाइल ऐप से लाइव ट्रैकिंग",
    ],
    specs: [
      { label: "Capacity Range", value: "1 kW to 6 kW" },
      { label: "Max Efficiency", value: "97.8%" },
      { label: "Weight", value: "24.00 kg" },
      { label: "Protection", value: "IP65 Weatherproof" },
      { label: "SKU", value: "ELIOS-W3-5K" },
      { label: "Warranty", value: "8 to 10 Years Assured" },
    ],
    applicationsEn:
      "Designed for single-phase electrical systems, this inverter ensures balanced power distribution across your property. Ideal for homes, small clinics, and shops under PM Surya Ghar.",
    applicationsHi:
      "घरेलू कनेक्शन, पीएम सूर्य घर रूफटॉप योजना और 1 से 6 किलोवाट घरेलू व छोटी दुकानों के लिए।",
    sku: "ELIOS-W3-5K",
    image:
      "https://vibe.filesafe.space/1792820769937918655/assets/0ca35cf8-df92-4808-97bc-77fd8dd400e3.png",
  },
  {
    id: "inv-three-phase-commercial",
    slug: "three-phase-on-grid-inverter-30-75kw",
    nameEn: "Three-Phase On-Grid Inverter — 30 to 75 kW",
    nameHi: "थ्री-फेज ऑन-ग्रिड इन्वर्टर — 30 से 75 किलोवाट",
    category: "inverters",
    subcategory: "Three-Phase On-Grid Inverter",
    taglineEn: "High energy efficiency for schools, hospitals, and commercial complexes.",
    taglineHi: "अस्पतालों, स्कूलों और व्यावसायिक भवनों के लिए उच्च ऊर्जा दक्षता।",
    descriptionEn:
      "High energy efficiency makes it ideal for larger spaces. Dependable performance even in adverse weather conditions. Seamless integration owing to easy setup. User-friendly operation due to intuitive controls. Features 3 to 6 MPPT channels accommodating complex rooftops.",
    descriptionHi:
      "बड़ी जगहों के लिए उच्च ऊर्जा दक्षता। खराब मौसम में भी भरोसेमंद प्रदर्शन। आसान सेटअप और सहज नियंत्रण। 3 से 6 एमपीपीटी इनपुट के साथ।",
    featuresEn: [
      "High energy efficiency makes it ideal for larger commercial spaces",
      "Dependable performance even in adverse weather conditions",
      "Seamless integration owing to easy setup and rapid commissioning",
      "User-friendly operation due to intuitive controls and LCD display",
      "Equipped with 3 to 6 MPPTs for multi-angle rooftop tracking",
    ],
    featuresHi: [
      "बड़े व्यावसायिक परिसरों के लिए उच्च ऊर्जा दक्षता",
      "प्रतिकूल मौसम में भी भरोसेमंद प्रदर्शन",
      "आसान सेटअप और त्वरित इंस्टॉलेशन",
      "उपयोगकर्ता-अनुकूल नियंत्रण और एलसीडी डिस्प्ले",
      "विभिन्न कोणों की छतों हेतु 3 से 6 एमपीपीटी",
    ],
    specs: [
      { label: "Capacity Range", value: "30 kW to 75 kW" },
      { label: "Max Efficiency", value: "98.7%" },
      { label: "Weight", value: "41 to 50 kg" },
      { label: "Protection", value: "IP65 Weatherproof" },
      { label: "MPPT Channels", value: "3 to 6 MPPTs" },
      { label: "Warranty", value: "8 Years Assured" },
    ],
    applicationsEn:
      "Ideal for large-scale commercial installations, private hospitals, colleges, cold storages, and large housing societies.",
    applicationsHi: "व्यावसायिक परिसर, निजी अस्पताल, कॉलेज, कोल्ड स्टोरेज और हाउसिंग सोसायटियाँ।",
    sku: "ELIOS-3P-30-75K",
    image:
      "https://vibe.filesafe.space/1792820769937918655/assets/a989c731-c4f4-4f0c-b9b6-43b75bec8220.png",
  },
  {
    id: "inv-three-phase-industrial",
    slug: "three-phase-on-grid-inverter-75-136kw",
    nameEn: "Three-Phase On-Grid Inverter — 75 to 136 kW",
    nameHi: "थ्री-फेज ऑन-ग्रिड इन्वर्टर — 75 से 136 किलोवाट",
    category: "inverters",
    subcategory: "Three-Phase On-Grid Inverter",
    taglineEn: "Heavy-duty power plant performance for rice mills, factories, and warehouses.",
    taglineHi: "राइस मिलों, कारखानों और वेयरहाउसों के लिए भारी-भरकम प्लांट प्रदर्शन।",
    descriptionEn:
      "High energy efficiency makes it ideal for larger spaces. Dependable performance even in adverse weather conditions. Seamless integration owing to easy setup. Industrial string inverter engineered for grueling continuous factory loads with 9/2 to 10/2 MPPTs and 90 kg robust chassis.",
    descriptionHi:
      "औद्योगिक स्तर का स्ट्रिंग इन्वर्टर जो 9/2 से 10/2 एमपीपीटी और 90 किग्रा के मजबूत निर्माण के साथ निरंतर कारखाने के लोड को संभालता है।",
    featuresEn: [
      "High energy efficiency makes it ideal for heavy industrial setups",
      "Dependable performance even in adverse weather conditions",
      "Seamless integration owing to easy setup and SCADA compatibility",
      "9/2 to 10/2 MPPT configuration ensuring zero string mismatch",
      "Full 100 kW+ continuous output at high ambient temperatures",
    ],
    featuresHi: [
      "भारी उद्योगों के लिए सर्वोत्तम ऊर्जा दक्षता",
      "प्रतिकूल तापमान और धूल में भी निरंतर कार्य",
      "स्काडा (SCADA) कनेक्टिविटी और आसान प्रबंधन",
      "9/2 से 10/2 एमपीपीटी विन्यास",
      "उच्च परिवेश तापमान पर भी पूर्ण उत्पादन",
    ],
    specs: [
      { label: "Capacity Range", value: "75 kW to 136 kW" },
      { label: "Max Efficiency", value: "98.6%" },
      { label: "Weight", value: "90 kg" },
      { label: "Protection", value: "IP66 Heavy-Duty" },
      { label: "MPPTs", value: "9/2 to 10/2 MPPTs" },
      { label: "Warranty", value: "8 Years Assured" },
    ],
    applicationsEn:
      "Ideal for utility-scale project installation, flour and rice mills, fabrication yards, and large manufacturing factories.",
    applicationsHi: "यूटिलिटी प्रोजेक्ट, फ्लोर एवं राइस मिलें, वेयरहाउस और बड़े कारखाने।",
    sku: "ELIOS-3P-75-136K",
    image:
      "https://vibe.filesafe.space/1792820769937918655/assets/f9514f3b-1838-44fa-b61b-86e961031e1f.png",
  },
  {
    id: "inv-utility-scale-350kw",
    slug: "three-phase-utility-inverter-350kw",
    nameEn: "Three-Phase On-Grid Inverter — 350 kW",
    nameHi: "थ्री-फेज ऑन-ग्रिड इन्वर्टर — 350 किलोवाट",
    category: "inverters",
    subcategory: "Utility & Megawatt Scale Inverter",
    taglineEn: "Peak output for MW-scale solar parks and massive enterprise campuses.",
    taglineHi: "मेगावाट-स्केल सोलर पार्कों और बड़े औद्योगिक पार्कों के लिए सर्वोच्च उत्पादन।",
    descriptionEn:
      "Massive 350 kW string inverter with up to 150% DC/AC ratio for higher energy yield, 6 MPPTs for optimized solar performance, 30 PV string inputs for flexible system design, and 300 kW output at 50°C for reliable performance.",
    descriptionHi:
      "350 किलोवाट का विशाल स्ट्रिंग इन्वर्टर: 150% डीसी/एसी अनुपात, 6 एमपीपीटी, 30 पीवी स्ट्रिंग इनपुट और 50°C पर 300 किलोवाट का निरंतर उत्पादन।",
    featuresEn: [
      "Up to 150% DC/AC ratio for higher energy yield",
      "6 MPPTs for optimized solar performance",
      "30 PV string inputs for flexible system design",
      "300 kW output at 50°C for reliable performance in hot summers",
      "Industry-leading 99.0% maximum efficiency rating",
    ],
    featuresHi: [
      "उच्च ऊर्जा उत्पादन हेतु 150% डीसी/एसी अनुपात",
      "सर्वोत्तम सोलर प्रदर्शन हेतु 6 एमपीपीटी",
      "लचीले सिस्टम डिज़ाइन हेतु 30 पीवी स्ट्रिंग इनपुट",
      "50°C तापमान में 300 किलोवाट का विश्वसनीय उत्पादन",
      "99.0% उद्योग-अग्रणी अधिकतम रूपांतरण दक्षता",
    ],
    specs: [
      { label: "Power Output", value: "350 kW" },
      { label: "Max Efficiency", value: "99.0%" },
      { label: "Weight", value: "117 kg" },
      { label: "Protection", value: "IP66" },
      { label: "Max Output Current", value: "252.6 A" },
      { label: "Warranty", value: "8 Years Assured" },
    ],
    applicationsEn:
      "Ideal for utility-scale solar projects, canal-top solar, ground-mounted MW solar farms, and large commercial installations.",
    applicationsHi: "यूटिलिटी-स्केल ग्राउंड माउंट सोलर पार्क, कैनाल-टॉप और विशाल औद्योगिक परिसर।",
    sku: "ELIOS-3P-350KW",
    image:
      "https://vibe.filesafe.space/1792820769937918655/assets/9c3727e5-085d-4d03-b0ca-069a6df68e08.png",
  },
  {
    id: "inv-hybrid-storage",
    slug: "smart-hybrid-storage-inverter-5k-10k",
    nameEn: "Smart Hybrid Storage Inverter — 5 kW to 10 kW",
    nameHi: "स्मार्ट हाइब्रिड स्टोरेज इन्वर्टर — 5 से 10 किलोवाट",
    category: "inverters",
    subcategory: "Hybrid & Battery Storage Inverter",
    taglineEn: "Seamless solar + battery backup with microsecond UPS switching.",
    taglineHi: "माइक्रोसेकंड यूपीएस स्विचिंग के साथ सोलर एवं बैटरी बैकअप।",
    descriptionEn:
      "Intelligent hybrid inverter with dual MPPTs and bi-directional battery charger compatible with high-voltage LiFePO4 batteries. Automatically transitions to battery backup in less than 10 milliseconds during grid power cuts in Bihar.",
    descriptionHi:
      "इंटेलिजेंट हाइब्रिड इन्वर्टर जो हाई-वोल्टेज लिथियम बैटरी के साथ मिलकर बिजली कटौती के दौरान 10 मिलीसेकंड में निर्बाध बैकअप शुरू करता है।",
    featuresEn: [
      "Ultra-fast <10ms UPS grade transfer time for zero appliance reset",
      "Compatible with advanced LiFePO4 lithium storage battery banks",
      "Peak shaving and smart time-of-use (TOU) energy cost optimization",
      "IP65 outdoor rating with dual MPPT high voltage solar inputs",
      "Integrated mobile app for battery charge & solar monitoring",
    ],
    featuresHi: [
      "10ms से कम में यूपीएस ट्रांसफर (कंप्यूटर या उपकरण बंद नहीं होंगे)",
      "उन्नत LiFePO4 लिथियम बैटरी के साथ पूर्ण संगत",
      "स्मार्ट बिजली प्रबंधन और बिल में अधिकतम बचत",
      "आईपी-65 वाटरप्रूफ और डस्टप्रूफ हाउसिंग",
      "मोबाइल ऐप से बैटरी एवं सोलर लाइव मॉनिटरिंग",
    ],
    specs: [
      { label: "Capacity Range", value: "5 kW to 10 kW" },
      { label: "Max Efficiency", value: "98.2%" },
      { label: "Battery Chemistry", value: "LiFePO4 Compatible" },
      { label: "Protection", value: "IP65 Weatherproof" },
      { label: "Transfer Time", value: "< 10 ms (UPS Class)" },
      { label: "Warranty", value: "10 Years Assured" },
    ],
    applicationsEn:
      "Luxury residences, hospitals, diagnostic centers, remote branches, and villas needing uninterrupted 24/7 power.",
    applicationsHi: "24/7 बिजली की आवश्यकता वाले घर, अस्पताल, डायग्नोस्टिक सेंटर और विला।",
    sku: "ELIOS-HYBRID-5-10K",
    image:
      "https://vibe.filesafe.space/1792820769937918655/assets/8ace460e-e467-4fcc-b354-ae0c5f27eb74.png",
  },

  // ==========================================
  // === 3. ALL-IN-ONE SOLAR KITS ===
  // ==========================================
  {
    id: "kit-3-2kw",
    slug: "radiance-3-2kw-on-grid-bifacial-kit",
    nameEn: "Elios 3.2 kW On-Grid Single Phase Bifacial Solar Kit",
    nameHi: "एलियोस 3.2 किलोवाट ऑन-ग्रिड सिंगल फेज बायोफेशियल सोलर किट",
    category: "solar_kits",
    subcategory: "All-in-One Solar Kits",
    taglineEn:
      "Turnkey all-in-one residential solar bundle with PM Surya Ghar subsidy eligibility.",
    taglineHi: "पीएम सूर्य घर योजना हेतु पात्र संपूर्ण आवासीय ऑल-इन-वन सोलर किट।",
    descriptionEn:
      "Complete all-in-one residential solar kit bundling 6 × 560 Wp N-type bifacial DCR modules, 3 kVA single-phase on-grid inverter, DCDB, ACDB, surge protection devices, and cabling.",
    descriptionHi:
      "संपूर्ण ऑल-इन-वन आवासीय सोलर किट: 6 एन-टाइप बायोफेशियल डीसीआर मॉड्यूल, 3 केवीए सिंगल फेज इन्वर्टर, डीसीडीबी, एसीडीबी और अर्थिंग किट।",
    featuresEn: [
      "12-year product warranty with a 30-year linear output guarantee",
      "Dedicated 8-year manufacturer inverter warranty",
      "DCR compliant and eligible for central subsidy up to ₹78,000 under PM Surya Ghar",
      "All balance of system components (DCDB, ACDB, SPD, MCBs) pre-bundled",
    ],
    featuresHi: [
      "12 वर्ष की उत्पाद वारंटी और 30 वर्ष की परफॉर्मेंस गारंटी",
      "इन्वर्टर पर 8 वर्ष की सुनिश्चित वारंटी",
      "डीसीआर प्रमाणित (पीएम सूर्य घर योजना सब्सिडी के पात्र)",
      "सभी सुरक्षा बॉक्स (DCDB, ACDB, SPD) शामिल",
    ],
    specs: [
      { label: "Modules", value: "6 × 560 Wp N-Type Bifacial DCR" },
      { label: "Inverter", value: "3 kVA Single Phase On-Grid" },
      { label: "Protection", value: "DCDB + ACDB + SPD + MCBs" },
      { label: "Weight", value: "Approx. 300 kg" },
    ],
    applicationsEn: "Homes with monthly electricity bills between ₹2,000 and ₹4,000 in Bihar.",
    applicationsHi: "बिहार के वे घर जिनका मासिक बिजली बिल ₹2,000 से ₹4,000 है।",
    sku: "ELIOS-KIT-3.2KW-DCR",
    image:
      "https://vibe.filesafe.space/1792820769937918655/assets/ff251352-caa0-4eb2-bf5e-efd843a89aee.jpg",
  },
  {
    id: "kit-5kw",
    slug: "radiance-5kw-on-grid-bifacial-kit",
    nameEn: "Elios 5.0 kW to 5.5 kW On-Grid Bifacial N-Type Solar Kit",
    nameHi: "एलियोस 5.0 से 5.5 किलोवाट ऑन-ग्रिड बायोफेशियल सोलर किट",
    category: "solar_kits",
    subcategory: "All-in-One Solar Kits",
    taglineEn: "Heavy-duty household & small business kit for running multiple ACs and motors.",
    taglineHi: "एसी, मोटर और घरेलू उपकरणों को चलाने हेतु शक्तिशाली 5 किलोवाट किट।",
    descriptionEn:
      "High-output 5 kW kit with 9 × 570 Wp N-type bifacial panels, 5 kVA on-grid inverter, pre-wired protection boxes, and balance-of-system hardware for high-consumption homes and shops.",
    descriptionHi:
      "9 उच्च-दक्षता 570W बायोफेशियल पैनल, 5 kVA इन्वर्टर और संपूर्ण वायरिंग बॉक्स के साथ उच्च खपत वाले घरों और दुकानों के लिए उपयुक्त।",
    featuresEn: [
      "Generates 20 to 25 units per sunny day, running 2 ACs with ease",
      "12-year product warranty & 30-year performance coverage",
      "Inverter backed with an 8-year assured warranty plan",
      "Full PM Surya Ghar maximum central subsidy (₹78,000) eligibility",
    ],
    featuresHi: [
      "प्रतिदिन 20 से 25 यूनिट बिजली, 2 एसी चलाने में सक्षम",
      "12 वर्ष उत्पाद और 30 वर्ष परफॉर्मेंस वारंटी",
      "इन्वर्टर पर 8 वर्ष की सुनिश्चित वारंटी",
      "₹78,000 तक अधिकतम सरकारी सब्सिडी की पूरी पात्रता",
    ],
    specs: [
      { label: "Modules", value: "9 × 570 Wp N-Type Bifacial" },
      { label: "Inverter", value: "5 kVA Single-Phase On-Grid" },
      { label: "Protection", value: "DCDB + ACDB + SPD + MCBs" },
      { label: "Weight", value: "Approx. 420 kg" },
    ],
    applicationsEn: "Larger residences, 2–3 floor villas, shops, clinics, and offices in Bihar.",
    applicationsHi: "बड़े घर, दो-तीन मंजिला मकान, दुकानें, क्लिनिक और व्यावसायिक प्रतिष्ठान।",
    sku: "ELIOS-KIT-5KW-DCR",
    image:
      "https://vibe.filesafe.space/1792820769937918655/assets/8b3f0aca-a7ec-412f-ae93-6daaf9024a45.png",
  },
];
