import React from "react";
import { useLocale } from "../../lib/locale-context";
import {
  ArrowRight,
  CheckCircle2,
  ShieldCheck,
  BadgeIndianRupee,
  Handshake,
  Wrench,
  Gauge,
} from "lucide-react";
import { LeafDecor } from "./LeafDecor";

interface EpcSectionProps {
  onOpenQuote: (service?: string) => void;
}

export function EpcSection({ onOpenQuote }: EpcSectionProps) {
  const { t, isHi } = useLocale();

  const benefits = isHi
    ? [
        {
          icon: Handshake,
          title: "एक जवाबदेही, एक ही टीम",
          body: "डिज़ाइन से लेकर इंस्टॉलेशन और कमीशनिंग तक — पूरे प्रोजेक्ट की ज़िम्मेदारी एक ही कंपनी की। कोई आपस में दोष नहीं, कोई बीच में ठेकेदार नहीं।",
          image:
            "https://vibe.filesafe.space/1792820769937918655/assets/458c84e4-8d93-42a6-a370-03e7805a40eb.png",
          imageAlt: "एक ही टीम छत पर सोलर प्रोजेक्ट की समीक्षा करते हुए",
        },
        {
          icon: BadgeIndianRupee,
          title: "सीधी खरीद, सबसे अच्छी कीमत",
          body: "हम मॉड्यूल, इन्वर्टर और माउंटिंग सीधे निर्माता से खरीदते हैं। कोई बिचौलिया नहीं, इसलिए आपको टियर-1 गुणवत्ता सबसे कीमत पर मिलती है।",
          image:
            "https://vibe.filesafe.space/1792820769937918655/assets/83e3cc9c-93d5-445c-b00e-b3157316abcc.png",
          imageAlt: "गोदाम में टियर-1 सोलर मॉड्यूल की सीधी खरीद",
        },
        {
          icon: ShieldCheck,
          title: "गुणवत्ता की गारंटी",
          body: "हर घटक ALMM-सूचीबद्ध और प्रमाणित होता है। संरचनात्मक लोड, अर्दिंग और नेट-मीटरिंग सब भारतीय मानकों के अनुसार — एक ही टीम से।",
          image:
            "https://vibe.filesafe.space/1792820769937918655/assets/54180d77-19df-4c61-b772-f79b13653b86.png",
          imageAlt: "प्रमाणित सोलर मॉड्यूल की गुणवत्ता जांच",
        },
        {
          icon: Wrench,
          title: "बाद में भी साथ",
          body: "इंस्टॉलेशन के बाद सेवा, निगरानी और वारंटी भी एलियोस के पास। एक कॉल पर वही टीम जो आपका सिस्टम लगाया है।",
          image:
            "https://vibe.filesafe.space/1792820769937918655/assets/88b7650a-2795-44c4-9628-d161e0f06494.png",
          imageAlt: "रूफटॉप सोलर सिस्टम की रियल-टाइम निगरानी",
        },
      ]
    : [
        {
          icon: Handshake,
          title: "One Accountable Partner",
          body: "From design to installation and commissioning, one company owns the whole project. No finger-pointing between contractors, no gaps in responsibility.",
          image:
            "https://vibe.filesafe.space/1792820769937918655/assets/458c84e4-8d93-42a6-a370-03e7805a40eb.png",
          imageAlt: "One unified team reviewing a rooftop solar project on-site",
        },
        {
          icon: BadgeIndianRupee,
          title: "Direct Procurement, Best Price",
          body: "We buy modules, inverters and mounting frames directly from manufacturers. No middleman markup, so you get Tier-1 quality at the sharpest price.",
          image:
            "https://vibe.filesafe.space/1792820769937918655/assets/83e3cc9c-93d5-445c-b00e-b3157316abcc.png",
          imageAlt: "Tier-1 solar modules being directly procured at a manufacturer warehouse",
        },
        {
          icon: ShieldCheck,
          title: "Quality You Can Verify",
          body: "Every component is ALMM-listed and certified. Structural load, earthing and net-metering all meet Indian standards — delivered by the same team.",
          image:
            "https://vibe.filesafe.space/1792820769937918655/assets/54180d77-19df-4c61-b772-f79b13653b86.png",
          imageAlt: "Quality inspection of a certified solar module with BIS and IEC labels",
        },
        {
          icon: Wrench,
          title: "Service That Continues",
          body: "After-sales support, monitoring and warranty stay with Elios. One call reaches the same engineers who installed your system.",
          image:
            "https://vibe.filesafe.space/1792820769937918655/assets/88b7650a-2795-44c4-9628-d161e0f06494.png",
          imageAlt: "Solar technician monitoring a rooftop system on a real-time dashboard",
        },
      ];

  return (
    <section className="relative py-16 sm:py-24 bg-navy-premium border-b border-border/40 overflow-hidden">
      <LeafDecor variant="dark" density="low" />
      <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="text-xs font-bold uppercase tracking-wider text-primary-light">
            {isHi ? "संपूर्ण ईपीसी समाधान" : "Turnkey EPC Model"}
          </span>
          <h2 className="mt-2 font-display text-3xl sm:text-4xl font-extrabold text-cream-surface">
            {isHi
              ? "ईपीसी क्या है और यह आपको सबसे बेहतरीन सोलर नतीजा कैसे देता है"
              : "What is Solar EPC & How It Gets You the Best Solar Outcome"}
          </h2>
          <p className="mt-4 text-base text-cream-surface/70 leading-relaxed">
            {isHi
              ? "ईपीसी का मतलब है इंजीनियरिंग, प्रोक्योरमेंट और कंस्ट्रक्शन — तीनों चरण एक ही कंपनी से। इसका मतलब है एक जवाबदेही, सीधी खरीद, और शुरू से आख़िर तक गुणवत्ता — जिससे आपको सबसे बेहतरीन सोलर नतीजा मिलता है।"
              : "EPC stands for Engineering, Procurement and Construction — all three stages handled by one company. That means one accountable partner, direct purchasing, and quality controlled from start to finish, which is exactly what delivers the best solar outcome for your roof."}
          </p>
        </div>

        {/* Three-stage EPC visual */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative">
          {[
            {
              badge: "E",
              badgeBg: "bg-primary text-primary-foreground",
              titleEn: "1. Engineering",
              titleHi: "इंजीनियरिंग (Engineering)",
              descEn:
                "Precision 3D shadow simulation, structural terrace load testing, electrical single-line diagram (SLD), and earthing design.",
              descHi:
                "छत का विस्तृत 3D शैडो विश्लेषण, संरचनात्मक लोड परीक्षण, टिल्ट कोण निर्धारण, और भारतीय विद्युत मानकों के अनुरूप सर्किट डिजाइन।",
              tagEn: "Custom Layout Planning",
              tagHi: "सटीक लेआउट प्लानिंग",
              tagColor: "text-primary-light",
              image:
                "https://vibe.filesafe.space/1792820769937918655/assets/5dd97c85-b3f0-4167-9961-d08f673a43ec.png",
              imageAlt: isHi
                ? "सोलर इंजीनियर छत पर 3D डिज़ाइन की समीक्षा करते हुए"
                : "Solar engineers reviewing 3D design plans at a rooftop site",
            },
            {
              badge: "P",
              badgeBg: "bg-accent-sky text-foreground",
              titleEn: "2. Procurement",
              titleHi: "प्रोक्योरमेंट (Procurement)",
              descEn:
                "Direct procurement of ALMM-listed Tier-1 mono PERC modules, high-efficiency inverters, hot-dip galvanized mounting frames, and certified DC switchgear.",
              descHi:
                "केवल ALMM-सूचीबद्ध टियर-1 मोनो पर्क सोलर मॉड्यूल, उच्च दक्षता वाले इन्वर्टर, भारी गैल्वेनाइज्ड स्ट्रक्चर और प्रमाणित कॉपर तारों की सीधी आपूर्ति।",
              tagEn: "Tier-1 Certified Hardware",
              tagHi: "गुणवत्ता प्रमाणित उपकरण",
              tagColor: "text-accent-sky",
              image:
                "https://vibe.filesafe.space/1792820769937918655/assets/08b6576e-560b-476b-975e-21922cba47dd.png",
              imageAlt: isHi
                ? "गोदाम में टियर-1 सोलर मॉड्यूल की गुणवत्ता जांच"
                : "Tier-1 solar modules being quality-checked in a warehouse",
            },
            {
              badge: "C",
              badgeBg: "bg-accent-gold text-foreground",
              titleEn: "3. Construction",
              titleHi: "कंस्ट्रक्शन (Construction)",
              descEn:
                "Waterproof structural bolting, lightning arrester earthing pits, state DISCOM bi-directional net-metering commissioning, and final switch-on.",
              descHi:
                "प्रमाणित तकनीशियनों द्वारा वाटरप्रूफ इंस्टॉलेशन, तड़ित चालक सुरक्षा, डिस्कॉम नेट-मीटरिंग अप्रूवल और अंतिम परीक्षण स्विच-ऑन।",
              tagEn: "Turnkey Commissioning",
              tagHi: "संपूर्ण कमीशनिंग व टेस्टिंग",
              tagColor: "text-accent-gold",
              image:
                "https://vibe.filesafe.space/1792820769937918655/assets/40ce83c9-48e5-4acd-86f9-b88cd30a089b.png",
              imageAlt: isHi
                ? "तकनीशियन छत पर सोलर पैनल इंस्टॉल करते हुए"
                : "Technicians installing rooftop solar panels on a roof",
            },
          ].map((stage) => (
            <div
              key={stage.badge}
              className="rounded-3xl border border-white/10 bg-white/5 backdrop-blur-md shadow-lg overflow-hidden flex flex-col group relative"
            >
              <div className="relative aspect-[4/3] border-b border-white/10">
                <div className="absolute inset-0 overflow-hidden">
                  <img
                    src={stage.image}
                    alt={stage.imageAlt}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-navy-premium/80 via-navy-premium/20 to-transparent pointer-events-none" />
                <div
                  className={`absolute -bottom-6 left-6 h-12 w-12 rounded-2xl ${stage.badgeBg} flex items-center justify-center font-display text-xl font-bold shadow-lg ring-4 ring-navy-premium z-10`}
                >
                  {stage.badge}
                </div>
              </div>
              <div className="p-8 pt-10 flex-1 flex flex-col">
                <h3 className="font-display text-2xl font-bold text-cream-surface mb-3">
                  {isHi ? stage.titleHi : stage.titleEn}
                </h3>
                <p className="text-sm text-cream-surface/70 leading-relaxed">
                  {isHi ? stage.descHi : stage.descEn}
                </p>
                <div
                  className={`mt-6 pt-4 border-t border-white/10 text-xs font-semibold ${stage.tagColor}`}
                >
                  {isHi ? stage.tagHi : stage.tagEn}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* How EPC gets the best outcome */}
        <div className="mt-14 rounded-3xl border border-white/10 bg-white/5 backdrop-blur-md p-6 sm:p-10">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <span className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-primary-light">
              <Gauge className="h-4 w-4" />
              {isHi ? "एक ही टीम का फ़ायदा" : "Why One Team Wins You More"}
            </span>
            <h3 className="mt-3 font-display text-2xl sm:text-3xl font-bold text-cream-surface">
              {isHi
                ? "ईपीसी मॉडल आपको सबसे बेहतरीन सोलर नतीजा कैसे देता है"
                : "How the EPC Model Gets You the Best Solar Outcome"}
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {benefits.map((b) => {
              const Icon = b.icon;
              return (
                <div
                  key={b.title}
                  className="group rounded-2xl border border-white/10 bg-white/5 overflow-hidden flex flex-col transition-all duration-300 hover:shadow-xl hover:-translate-y-1"
                >
                  <div className="relative aspect-[4/3] overflow-hidden">
                    <img
                      src={b.image}
                      alt={b.imageAlt}
                      loading="lazy"
                      className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-navy-premium/80 via-navy-premium/20 to-transparent pointer-events-none" />
                    <div className="absolute top-3 left-3 h-10 w-10 rounded-xl bg-primary/90 text-primary-foreground flex items-center justify-center shadow-lg ring-2 ring-white/20">
                      <Icon className="h-5 w-5" />
                    </div>
                  </div>
                  <div className="p-6 flex-1 flex flex-col">
                    <h4 className="font-display text-base font-bold text-cream-surface mb-2">
                      {b.title}
                    </h4>
                    <p className="text-sm text-cream-surface/70 leading-relaxed">{b.body}</p>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3 text-center">
            <CheckCircle2 className="h-5 w-5 text-success shrink-0" />
            <p className="text-sm text-cream-surface/70 max-w-xl">
              {isHi
                ? "एक ही कंपनी पूरे प्रोजेक्ट की ज़िम्मेदारी लेती है — इसलिए आपको सबसे बेहतरीन गुणवत्ता, सबसे अच्छी कीमत और बाद में भी भरोसेमंद सेवा मिलती है।"
                : "One company owns the whole project — so you get the best quality, the sharpest price, and reliable service long after switch-on."}
            </p>
          </div>
        </div>

        <div className="mt-12 text-center">
          <button
            onClick={() => onOpenQuote("EPC Project Consultation")}
            className="inline-flex items-center gap-2 rounded-xl bg-primary px-8 py-3.5 text-sm font-bold text-primary-foreground shadow-lg shadow-primary/20 hover:bg-primary-hover active:scale-95"
          >
            <span>{t("startProject")}</span>
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      </div>
    </section>
  );
}
