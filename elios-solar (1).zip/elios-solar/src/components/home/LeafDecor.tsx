import React from "react";
import { useReducedMotion } from "framer-motion";

/**
 * Decorative greenery accents — floating leaves + soft green glows.
 * Reinforces the clean-energy / sustainability theme.
 * Purely presentational; pointer-events disabled; respects reduced motion.
 */
interface LeafDecorProps {
  variant?: "light" | "dark";
  density?: "low" | "medium";
}

export function LeafDecor({ variant = "light", density = "medium" }: LeafDecorProps) {
  const reduceMotion = useReducedMotion();
  const isDark = variant === "dark";

  const leafColor = isDark ? "#4ade80" : "#16a34a";
  const leafColor2 = isDark ? "#86efac" : "#22c55e";

  const count = density === "low" ? 4 : 7;

  const leaves = Array.from({ length: count }).map((_, i) => {
    const top = [12, 28, 45, 62, 78, 8, 70][i % 7];
    const left = [6, 88, 22, 72, 14, 92, 48][i % 7];
    const size = 18 + ((i * 7) % 16);
    const rot = (i % 2 === 0 ? 1 : -1) * (15 + ((i * 13) % 30));
    const dur = 6 + (i % 4);
    const delay = (i % 5) * 0.7;
    return { top, left, size, rot, dur, delay, i };
  });

  return (
    <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden z-0">
      {/* Soft green glow orbs */}
      <div
        className="absolute bg-leaf-glow rounded-full"
        style={{ top: "8%", left: "4%", width: "240px", height: "240px" }}
      />
      <div
        className="absolute bg-leaf-glow-warm rounded-full"
        style={{ bottom: "10%", right: "6%", width: "200px", height: "200px" }}
      />

      {/* Floating leaves */}
      {leaves.map((l) => (
        <div
          key={l.i}
          className={reduceMotion ? "" : "leaf-float"}
          style={
            {
              position: "absolute",
              top: `${l.top}%`,
              left: `${l.left}%`,
              width: `${l.size}px`,
              height: `${l.size}px`,
              opacity: isDark ? 0.5 : 0.4,
              "--leaf-rot": `${l.rot}deg`,
              animationDuration: `${l.dur}s`,
              animationDelay: `${l.delay}s`,
            } as React.CSSProperties
          }
        >
          <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
            <path
              d="M16 2C8 6 4 14 6 22c4 6 14 6 18 0 2-8-2-16-8-20Z"
              fill={l.i % 2 === 0 ? leafColor : leafColor2}
              opacity="0.85"
            />
            <path
              d="M16 4C12 10 12 18 16 26"
              stroke={isDark ? "#bbf7d0" : "#15803d"}
              strokeWidth="1"
              strokeLinecap="round"
              opacity="0.6"
            />
          </svg>
        </div>
      ))}
    </div>
  );
}
