import React, { useRef } from "react";
import {
  motion,
  useScroll,
  useTransform,
  useMotionValue,
  useSpring,
  useReducedMotion,
} from "framer-motion";
import { useLocale } from "../../lib/locale-context";
import { ASSETS, CONTACT_INFO } from "../../lib/constants";
import {
  Sun,
  CheckCircle,
  Phone,
  ArrowRight,
  Zap,
  TrendingDown,
  Clock,
  ShieldCheck,
  Sparkles,
} from "lucide-react";

interface HeroSectionProps {
  onOpenQuote: (service?: string) => void;
}

export function HeroSection({ onOpenQuote }: HeroSectionProps) {
  const { t, isHi } = useLocale();
  const containerRef = useRef<HTMLDivElement>(null);
  const reduceMotion = useReducedMotion();

  // Mouse parallax for 3D scene
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);
  const sceneRotateX = useSpring(useTransform(mouseY, [-0.5, 0.5], [12, -12]), {
    stiffness: 120,
    damping: 22,
  });
  const sceneRotateY = useSpring(useTransform(mouseX, [-0.5, 0.5], [-16, 16]), {
    stiffness: 120,
    damping: 22,
  });
  const sunX = useSpring(useTransform(mouseX, [-0.5, 0.5], [12, -12]), {
    stiffness: 80,
    damping: 20,
  });
  const sunY = useSpring(useTransform(mouseY, [-0.5, 0.5], [8, -8]), {
    stiffness: 80,
    damping: 20,
  });

  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end start"],
  });
  const heroY = useTransform(scrollYProgress, [0, 1], [0, 100]);
  const heroOpacity = useTransform(scrollYProgress, [0, 0.8], [1, 0.15]);
  const sceneScale = useTransform(scrollYProgress, [0, 1], [1, 1.12]);

  const handleMouseMove = (e: React.MouseEvent) => {
    if (reduceMotion) return;
    const rect = e.currentTarget.getBoundingClientRect();
    mouseX.set((e.clientX - rect.left) / rect.width - 0.5);
    mouseY.set((e.clientY - rect.top) / rect.height - 0.5);
  };

  // 24 animated sunrays
  const rays = Array.from({ length: 24 }).map((_, i) => {
    const angle = (i * 360) / 24;
    return { id: i, angle, length: i % 2 === 0 ? 380 : 280, opacity: i % 2 === 0 ? 0.4 : 0.22 };
  });

  return (
    <section
      ref={containerRef}
      onMouseMove={handleMouseMove}
      className="relative pt-10 pb-20 sm:pt-14 sm:pb-28 overflow-hidden bg-gradient-to-b from-[#0B2036] via-[#0E2843] to-[#0B2036] text-white border-b border-white/10"
    >
      {/* Ambient background glow orbs */}
      <motion.div
        aria-hidden
        className="pointer-events-none absolute -top-32 left-1/2 -translate-x-1/2 h-[650px] w-[650px] rounded-full blur-[120px]"
        style={{
          background:
            "radial-gradient(circle, rgba(218, 148, 64, 0.32) 0%, rgba(14, 40, 67, 0) 70%)",
        }}
        animate={reduceMotion ? {} : { scale: [1, 1.15, 1], opacity: [0.6, 0.9, 0.6] }}
        transition={{ duration: 7, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div
        aria-hidden
        className="pointer-events-none absolute top-40 -left-20 h-96 w-96 rounded-full blur-[100px]"
        style={{
          background: "radial-gradient(circle, rgba(96, 165, 250, 0.18) 0%, transparent 70%)",
        }}
        animate={reduceMotion ? {} : { scale: [1.1, 1, 1.1], opacity: [0.4, 0.7, 0.4] }}
        transition={{ duration: 9, repeat: Infinity, ease: "easeInOut", delay: 1 }}
      />
      <motion.div
        aria-hidden
        className="pointer-events-none absolute top-1/2 -right-24 h-96 w-96 rounded-full blur-[100px]"
        style={{
          background: "radial-gradient(circle, rgba(218, 148, 64, 0.22) 0%, transparent 70%)",
        }}
        animate={reduceMotion ? {} : { scale: [1, 1.2, 1], opacity: [0.35, 0.65, 0.35] }}
        transition={{ duration: 10, repeat: Infinity, ease: "easeInOut", delay: 2 }}
      />

      {/* High-tech grid overlay */}
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.06]"
        style={{
          backgroundImage:
            "linear-gradient(to right, #ffffff 1px, transparent 1px), linear-gradient(to bottom, #ffffff 1px, transparent 1px)",
          backgroundSize: "48px 48px",
        }}
      />

      {/*
        Responsive layout:
        - Mobile (flex-col): Beacon → H1 → 3D scene → rest content
        - Desktop (grid-12): Beacon full-width on top (row 1),
          H1 left (row 2), 3D scene right (rows 2-3),
          rest content left (row 3) — side by side, unchanged
      */}
      <motion.div
        style={{ y: reduceMotion ? 0 : heroY, opacity: reduceMotion ? 1 : heroOpacity }}
        className="relative mx-auto max-w-7xl px-4 sm:px-6 z-10 flex flex-col lg:grid lg:grid-cols-12 lg:gap-x-12 lg:items-start"
      >
        {/* === H1: order-1 on mobile, row-start-2 left on desktop === */}
        <div className="lg:col-start-1 lg:col-span-7 lg:row-start-2 order-2 lg:order-none flex flex-col items-center lg:items-start text-center lg:text-left lg:pt-2">
          <motion.h1
            className="font-display text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-[1.14] max-w-3xl"
            initial={{ opacity: 0, y: 25 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: "easeOut" }}
          >
            {isHi ? (
              <>
                <span className="block">बिजली का बिल कम करें।</span>
                <span className="block text-transparent bg-clip-text bg-gradient-to-r from-primary via-[#E8A348] to-[#FDE047]">
                  सोलर ऊर्जा से भविष्य रोशन करें।
                </span>
              </>
            ) : (
              <>
                <span className="block">Power Your Home &amp; Business</span>
                <span className="block text-transparent bg-clip-text bg-gradient-to-r from-primary via-[#E8A348] to-[#FDE047]">
                  with Solar Today.
                </span>
              </>
            )}
          </motion.h1>
        </div>

        {/* === 3D FLOATING SOLAR SCENE: order-2 on mobile, right col rows 2-3 on desktop === */}
        <div className="lg:col-start-8 lg:col-span-5 lg:row-start-2 lg:row-span-2 order-3 lg:order-none relative w-full h-[460px] sm:h-[560px] lg:h-[660px] mt-6 lg:mt-0 flex items-center justify-center">
          <motion.div
            className="absolute inset-0 flex items-center justify-center"
            style={{
              perspective: 1200,
              transformStyle: "preserve-3d",
            }}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.35, duration: 0.8 }}
          >
            {/* 3D rotating solar scene */}
            <motion.div
              className="relative"
              style={{
                rotateX: reduceMotion ? 0 : sceneRotateX,
                rotateY: reduceMotion ? 0 : sceneRotateY,
                scale: reduceMotion ? 1 : sceneScale,
                transformStyle: "preserve-3d",
              }}
            >
              {/* Glowing animated sun orb */}
              <motion.div
                className="absolute -top-24 -right-8 z-20"
                style={{
                  x: reduceMotion ? 0 : sunX,
                  y: reduceMotion ? 0 : sunY,
                  transformStyle: "preserve-3d",
                }}
              >
                <motion.div
                  className="relative h-32 w-32 sm:h-40 sm:w-40 rounded-full"
                  style={{
                    background:
                      "radial-gradient(circle at 35% 35%, #FDE047 0%, #E8A348 40%, #DA9440 75%, #C97F26 100%)",
                    boxShadow:
                      "0 0 60px 12px rgba(232,163,72,0.55), 0 0 120px 30px rgba(218,148,64,0.3)",
                  }}
                  animate={reduceMotion ? {} : { scale: [1, 1.06, 1], rotate: [0, 8, 0] }}
                  transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
                >
                  {/* Sun rays around the orb */}
                  <motion.svg
                    viewBox="0 0 200 200"
                    className="absolute inset-0 w-full h-full pointer-events-none"
                    animate={reduceMotion ? {} : { rotate: 360 }}
                    transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
                  >
                    <g
                      transform="translate(100, 100)"
                      stroke="#E8A348"
                      strokeWidth="3"
                      strokeLinecap="round"
                    >
                      {Array.from({ length: 12 }).map((_, i) => {
                        const a = (i * 360) / 12;
                        const rad = (a * Math.PI) / 180;
                        return (
                          <line
                            key={i}
                            x1={Math.cos(rad) * 52}
                            y1={Math.sin(rad) * 52}
                            x2={Math.cos(rad) * 66}
                            y2={Math.sin(rad) * 66}
                            opacity="0.7"
                          />
                        );
                      })}
                    </g>
                  </motion.svg>
                </motion.div>
              </motion.div>

              {/* 3D Rooftop panel array — perspective tilted platform */}
              <div
                className="relative"
                style={{
                  transform: "rotateX(52deg) rotateZ(-12deg)",
                  transformStyle: "preserve-3d",
                }}
              >
                {/* Rooftop base slab */}
                <div
                  className="relative w-[380px] sm:w-[460px] h-[260px] sm:h-[320px] rounded-2xl"
                  style={{
                    background: "linear-gradient(135deg, #162B47 0%, #0F2238 100%)",
                    boxShadow:
                      "0 30px 60px -20px rgba(0,0,0,0.7), inset 0 1px 0 rgba(255,255,255,0.08)",
                    transform: "translateZ(0px)",
                  }}
                >
                  {/* Solar panel grid — 3 columns x 2 rows */}
                  <div className="absolute inset-3 grid grid-cols-3 grid-rows-2 gap-2">
                    {Array.from({ length: 6 }).map((_, i) => (
                      <motion.div
                        key={i}
                        className="rounded-lg overflow-hidden relative"
                        style={{
                          background:
                            "linear-gradient(135deg, #1E3A5F 0%, #2A4A6E 50%, #1E3A5F 100%)",
                          border: "1px solid rgba(96,165,250,0.25)",
                          boxShadow: "inset 0 0 8px rgba(96,165,250,0.15)",
                        }}
                        animate={
                          reduceMotion
                            ? {}
                            : {
                                boxShadow: [
                                  "inset 0 0 8px rgba(96,165,250,0.15)",
                                  "inset 0 0 16px rgba(232,163,72,0.4)",
                                  "inset 0 0 8px rgba(96,165,250,0.15)",
                                ],
                              }
                        }
                        transition={{
                          duration: 4,
                          repeat: Infinity,
                          delay: i * 0.4,
                          ease: "easeInOut",
                        }}
                      >
                        {/* Panel cell grid lines */}
                        <div
                          className="absolute inset-0 opacity-40"
                          style={{
                            backgroundImage:
                              "linear-gradient(to right, rgba(255,255,255,0.12) 1px, transparent 1px), linear-gradient(to bottom, rgba(255,255,255,0.12) 1px, transparent 1px)",
                            backgroundSize: "10px 10px",
                          }}
                        />
                        {/* Sunlight reflection sweep */}
                        <motion.div
                          className="absolute inset-0"
                          style={{
                            background:
                              "linear-gradient(110deg, transparent 30%, rgba(253,224,71,0.35) 50%, transparent 70%)",
                          }}
                          animate={reduceMotion ? {} : { x: ["-120%", "120%"] }}
                          transition={{
                            duration: 5,
                            repeat: Infinity,
                            delay: i * 0.6,
                            ease: "easeInOut",
                          }}
                        />
                      </motion.div>
                    ))}
                  </div>
                </div>

                {/* Support structure legs with depth */}
                <div
                  className="absolute -bottom-3 left-6 w-2 h-10 rounded-b-sm"
                  style={{
                    background: "linear-gradient(180deg, #1E3A5F, #0B2036)",
                    transform: "translateZ(-30px) rotateX(-52deg)",
                    transformOrigin: "top",
                  }}
                />
                <div
                  className="absolute -bottom-3 right-6 w-2 h-10 rounded-b-sm"
                  style={{
                    background: "linear-gradient(180deg, #1E3A5F, #0B2036)",
                    transform: "translateZ(-30px) rotateX(-52deg)",
                    transformOrigin: "top",
                  }}
                />
              </div>

              {/* Floating energy particles */}
              {!reduceMotion &&
                Array.from({ length: 6 }).map((_, i) => (
                  <motion.div
                    key={`p-${i}`}
                    className="absolute h-1.5 w-1.5 rounded-full bg-[#E8A348]"
                    style={{
                      left: `${20 + i * 12}%`,
                      top: `${30 + (i % 3) * 18}%`,
                      boxShadow: "0 0 8px rgba(232,163,72,0.8)",
                    }}
                    animate={{
                      y: [0, -30, 0],
                      opacity: [0, 1, 0],
                    }}
                    transition={{
                      duration: 3 + i * 0.5,
                      repeat: Infinity,
                      delay: i * 0.4,
                      ease: "easeInOut",
                    }}
                  />
                ))}
            </motion.div>
          </motion.div>

          {/* Floating Live Stat 1: Bill Reduction */}
          <motion.div
            className="absolute z-40 top-2 -left-2 sm:top-6 sm:-left-4 rounded-2xl bg-[#0B2036]/95 border border-white/20 shadow-2xl p-3 sm:p-3.5 backdrop-blur-xl"
            animate={reduceMotion ? {} : { y: [0, -10, 0] }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
          >
            <div className="flex items-center gap-2.5">
              <div className="h-9 w-9 rounded-xl bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center">
                <TrendingDown className="h-5 w-5 text-emerald-400" />
              </div>
              <div>
                <p className="text-[10px] text-slate-300 font-semibold uppercase">
                  {isHi ? "बिल में कमी" : "Bill Reduction"}
                </p>
                <p className="text-sm font-display font-bold text-emerald-400">
                  {isHi ? "90% तक" : "Up to 90%"}
                </p>
              </div>
            </div>
          </motion.div>

          {/* Floating Live Stat 2: PM Surya Ghar Subsidy */}
          <motion.div
            className="absolute z-40 bottom-4 -right-2 sm:bottom-8 sm:-right-4 rounded-2xl bg-[#0B2036]/95 border border-primary/40 shadow-2xl p-3 sm:p-3.5 backdrop-blur-xl"
            animate={reduceMotion ? {} : { y: [0, 10, 0] }}
            transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 0.5 }}
          >
            <div className="flex items-center gap-2.5">
              <div className="h-9 w-9 rounded-xl bg-primary/20 border border-primary/40 flex items-center justify-center">
                <Zap className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-[10px] text-slate-300 font-semibold uppercase">
                  {isHi ? "केंद्रीय सब्सिडी" : "Govt Subsidy"}
                </p>
                <p className="text-sm font-display font-bold text-primary">
                  {isHi ? "₹78,000 तक" : "Up to ₹78,000"}
                </p>
              </div>
            </div>
          </motion.div>

          {/* Floating Live Stat 3: Warranty badge */}
          <motion.div
            className="absolute z-40 top-1/2 -translate-y-1/2 -right-3 sm:right-2 rounded-xl bg-[#0B2036]/95 border border-accent-sky/30 shadow-xl px-3 py-2 backdrop-blur-xl"
            animate={reduceMotion ? {} : { y: [0, -8, 0] }}
            transition={{ duration: 4.5, repeat: Infinity, ease: "easeInOut", delay: 1 }}
          >
            <div className="flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-accent-sky" />
              <span className="text-[11px] font-bold text-white">
                {isHi ? "25 वर्ष वारंटी" : "25 Yr Warranty"}
              </span>
            </div>
          </motion.div>

          {/* Sparkle accents */}
          <motion.div
            className="absolute top-4 right-12 z-30"
            animate={reduceMotion ? {} : { opacity: [0, 1, 0], scale: [0.8, 1.2, 0.8] }}
            transition={{ duration: 2.5, repeat: Infinity, delay: 0.5 }}
          >
            <Sparkles className="h-4 w-4 text-[#FDE047]" />
          </motion.div>
          <motion.div
            className="absolute bottom-16 left-8 z-30"
            animate={reduceMotion ? {} : { opacity: [0, 1, 0], scale: [0.8, 1.2, 0.8] }}
            transition={{ duration: 3, repeat: Infinity, delay: 1.2 }}
          >
            <Sparkles className="h-3 w-3 text-primary" />
          </motion.div>
        </div>

        {/* === BEACON: order-3 on mobile, full-width row 1 on desktop === */}
        <div className="lg:col-span-12 lg:row-start-1 order-1 lg:order-none flex flex-col items-center justify-center w-full mb-6 lg:mb-12">
          <div className="relative w-80 h-44 sm:w-96 sm:h-52 flex items-center justify-center">
            <motion.div
              className="absolute h-40 w-40 sm:h-48 sm:w-48 rounded-full border border-primary/30"
              animate={reduceMotion ? {} : { scale: [1, 1.35, 1], opacity: [0.6, 0.1, 0.6] }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            />
            <motion.div
              className="absolute h-56 w-56 sm:h-64 sm:w-64 rounded-full border border-primary/20"
              animate={reduceMotion ? {} : { scale: [1, 1.25, 1], opacity: [0.4, 0.05, 0.4] }}
              transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 0.8 }}
            />

            <motion.svg
              viewBox="0 0 400 400"
              className="absolute inset-0 w-full h-full pointer-events-none overflow-visible"
              animate={reduceMotion ? {} : { rotate: 360 }}
              transition={{ duration: 70, repeat: Infinity, ease: "linear" }}
            >
              <defs>
                <linearGradient id="rayGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#DA9440" stopOpacity="0.85" />
                  <stop offset="50%" stopColor="#E8A348" stopOpacity="0.4" />
                  <stop offset="100%" stopColor="#DA9440" stopOpacity="0" />
                </linearGradient>
              </defs>
              <g transform="translate(200, 200)">
                {rays.map((ray) => {
                  const rad = (ray.angle * Math.PI) / 180;
                  const x1 = Math.cos(rad) * 48;
                  const y1 = Math.sin(rad) * 48;
                  const x2 = Math.cos(rad) * ray.length;
                  const y2 = Math.sin(rad) * ray.length;
                  return (
                    <line
                      key={ray.id}
                      x1={x1}
                      y1={y1}
                      x2={x2}
                      y2={y2}
                      stroke="url(#rayGrad)"
                      strokeWidth={ray.id % 4 === 0 ? "2.5" : "1.2"}
                      strokeLinecap="round"
                      opacity={ray.opacity}
                    />
                  );
                })}
              </g>
            </motion.svg>

            <motion.div
              className="relative z-20 flex flex-col items-center justify-center rounded-2xl bg-[#F9F6EF] p-3 sm:p-3.5 shadow-[0_0_50px_rgba(218,148,64,0.55)] border-2 border-primary/40"
              whileHover={reduceMotion ? {} : { scale: 1.08 }}
              animate={
                reduceMotion
                  ? {}
                  : {
                      boxShadow: [
                        "0 0 30px rgba(218, 148, 64, 0.4)",
                        "0 0 65px rgba(218, 148, 64, 0.75)",
                        "0 0 30px rgba(218, 148, 64, 0.4)",
                      ],
                    }
              }
              transition={{ duration: 3.5, repeat: Infinity, ease: "easeInOut" }}
            >
              <img
                src={ASSETS.logo}
                alt="Elios Solar Energy Official Sun Mark"
                className="h-12 w-12 sm:h-14 sm:w-14 object-contain rounded-xl"
              />
            </motion.div>
          </div>

          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mt-2"
          >
            <span className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1 text-xs font-semibold text-primary tracking-wide">
              <Sun className="h-3.5 w-3.5 text-primary animate-spin-slow" />
              <span>
                {isHi
                  ? "स्वच्छ ऊर्जा • आत्मनिर्भर बिहार • आधिकारिक ईपीसी पार्टनर"
                  : "Clean Energy • Bihar Rooftop Solar EPC"}
              </span>
            </span>
          </motion.div>
        </div>

        {/* === REST CONTENT: order-4 on mobile, row-start-3 left on desktop === */}
        <div className="lg:col-start-1 lg:col-span-7 lg:row-start-3 order-4 lg:order-none flex flex-col items-center lg:items-start text-center lg:text-left">
          <motion.p
            className="mt-5 text-base sm:text-lg text-slate-300 leading-relaxed max-w-2xl"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.25, duration: 0.6 }}
          >
            {isHi
              ? "अपनी छत का मुफ़्त निरीक्षण बुक करें। एलियोस सोलर एनर्जी पूरे बिहार में उच्च-दक्षता वाले सोलर सिस्टम की इंजीनियरिंग, सरकारी सब्सिडी (₹78,000 तक) और आसान ईएमआई लोन के समस्त दस्तावेज़ एक ही छत के नीचे संभालती है।"
              : "Book your free rooftop assessment. Our technical solar engineers handle custom system design, DISCOM net metering, low-EMI bank financing, and central PM Surya Ghar subsidy paperwork end-to-end across Bihar."}
          </motion.p>

          {/* Quick trust indicators */}
          <motion.div
            className="mt-6 flex flex-wrap justify-center lg:justify-start gap-3 sm:gap-4 text-xs sm:text-sm font-semibold text-slate-200"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.45, duration: 0.5 }}
          >
            <div className="flex items-center gap-1.5 rounded-lg bg-white/5 border border-white/10 px-3 py-1.5 backdrop-blur-sm">
              <CheckCircle className="h-4 w-4 text-emerald-400" />
              <span>{t("trustSubsidy")}</span>
            </div>
            <div className="flex items-center gap-1.5 rounded-lg bg-white/5 border border-white/10 px-3 py-1.5 backdrop-blur-sm">
              <CheckCircle className="h-4 w-4 text-emerald-400" />
              <span>{t("trustLoan")}</span>
            </div>
            <div className="flex items-center gap-1.5 rounded-lg bg-white/5 border border-white/10 px-3 py-1.5 backdrop-blur-sm">
              <CheckCircle className="h-4 w-4 text-emerald-400" />
              <span>{t("trustEpc")}</span>
            </div>
          </motion.div>

          {/* Primary & Secondary Action Buttons */}
          <motion.div
            className="mt-8 flex flex-col sm:flex-row gap-3.5 w-full sm:w-auto items-stretch sm:items-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.5 }}
          >
            <motion.button
              onClick={() => onOpenQuote("Residential Homes")}
              whileHover={
                reduceMotion ? {} : { scale: 1.03, boxShadow: "0 10px 30px rgba(218,148,64,0.4)" }
              }
              whileTap={{ scale: 0.97 }}
              className="inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-primary via-[#E8A348] to-[#DA9440] px-7 py-3.5 text-sm font-extrabold text-[#0B2036] shadow-lg shadow-primary/30 transition-all hover:brightness-105"
            >
              <Sun className="h-4 w-4 text-[#0B2036]" />
              <span>{t("getFreeQuotation")}</span>
              <ArrowRight className="h-4 w-4 text-[#0B2036]" />
            </motion.button>

            <motion.a
              href={CONTACT_INFO.phoneTel}
              whileHover={reduceMotion ? {} : { scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              className="inline-flex items-center justify-center gap-2.5 rounded-xl border border-white/20 bg-white/10 px-6 py-3.5 text-sm font-bold text-white backdrop-blur-md transition-all hover:bg-white/15 hover:border-white/35"
            >
              <Phone className="h-4 w-4 text-primary" />
              <span>{CONTACT_INFO.phone}</span>
            </motion.a>
          </motion.div>

          {/* Hours note badge */}
          <motion.div
            className="mt-4 flex items-center gap-2 text-xs text-slate-400 lg:justify-start justify-center"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8 }}
          >
            <Clock className="h-3.5 w-3.5 text-primary shrink-0" />
            <span>
              {isHi
                ? "हमारे सोलर विशेषज्ञ सोमवार से शनिवार, सुबह 9 से शाम 7 बजे तक उपलब्ध हैं।"
                : "Our solar experts are available Monday to Saturday, 9 AM to 7 PM."}
            </span>
          </motion.div>
        </div>
      </motion.div>
    </section>
  );
}
