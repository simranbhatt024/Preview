import React from "react";
import { useLocale } from "../../lib/locale-context";
import { ArrowRight } from "lucide-react";
import { LeafDecor } from "./LeafDecor";

interface OfferingsSectionProps {
  onOpenQuote: (service?: string) => void;
}

export function OfferingsSection({ onOpenQuote }: OfferingsSectionProps) {
  const { t, isHi } = useLocale();

  const offerings = [
    {
      image:
        "https://vibe.filesafe.space/1792820769937918655/assets/6f45f4f4-798c-480e-9529-5db3b1c1eb16.png",
      imageAlt: isHi
        ? "सरकारी सब्सिडी अनुमोदन दस्तावेज़ की समीक्षा"
        : "Government solar subsidy approval documents being reviewed",
      title: isHi ? "सब्सिडी सहायता (Subsidy Support)" : "Subsidy Support for Eligible Homes",
      desc: isHi
        ? "पीएम सूर्य घर पोर्टल पर संपूर्ण आवेदन एवं दस्तावेज तैयार करने में सहायता।"
        : "Direct guidance and liaison for national PM Surya Ghar subsidy disbursement.",
      service: "Subsidy Support Consultation",
    },
    {
      image:
        "https://vibe.filesafe.space/1792820769937918655/assets/eff14979-bb3d-454b-8607-20f52e7d0281.png",
      imageAlt: isHi
        ? "बैंक अधिकारी के साथ सोलर लोन वित्त पोषण"
        : "Solar loan financing with a bank officer",
      title: isHi ? "आसान लोन सुविधा (Loan Facility)" : "Low-Interest Solar Loan Facility",
      desc: isHi
        ? "सहयोगी बैंकों के साथ आसान ईएमआई और न्यूनतम कागजी कार्रवाई।"
        : "Easy installment plans with partner banks covering up to 80% of project cost.",
      service: "Solar Loan Consultation",
    },
    {
      image:
        "https://vibe.filesafe.space/1792820769937918655/assets/63244359-21dd-4ea8-aa0d-e142a9393a4a.png",
      imageAlt: isHi
        ? "छत पर सोलर लेआउट डिज़ाइन परामर्श"
        : "Solar layout design consultation on a rooftop",
      title: isHi ? "रूफटॉप प्रोजेक्ट मार्गदर्शन (Guidance)" : "Rooftop Solar Project Guidance",
      desc: isHi
        ? "स्थानिक छाया, लोड आवश्यकता और डिस्कॉम नियमों पर विशेषज्ञ सलाह।"
        : "Clear engineering advice on shadow, load sanctioning, and terrace utilization.",
      service: "Rooftop Project Guidance",
    },
    {
      image:
        "https://vibe.filesafe.space/1792820769937918655/assets/8282bc41-8018-46ab-a348-4dd25c91302d.png",
      imageAlt: isHi
        ? "द्विदिशात्मक स्मार्ट नेट मीटर"
        : "Bi-directional smart net meter installation",
      title: isHi ? "डिस्कॉम नेट मीटरिंग (Net Metering)" : "Bi-Directional Net Metering Sync",
      desc: isHi
        ? "NBPDCL / SBPDCL के साथ समन्वय कर ग्रिड से सोलर को जोड़ने का काम।"
        : "Seamless liaison with local DISCOMs for solar grid connection and meter testing.",
      service: "Net Metering Consultation",
    },
    {
      image:
        "https://vibe.filesafe.space/1792820769937918655/assets/d9d065cc-d148-4707-bba5-8ab4ae98dd61.png",
      imageAlt: isHi
        ? "रूफटॉप सोलर पैनल की सफाई और रखरखाव"
        : "Rooftop solar panel cleaning and maintenance",
      title: isHi ? "वार्षिक रख-रखाव पैकेज (Care Packages)" : "Annual Maintenance & Cleaning",
      desc: isHi
        ? "नियमित सफाई, त्रैमासिक रिपोर्ट और प्लांट स्वास्थ्य मॉनिटरिंग।"
        : "Scheduled panel cleaning, degradation checks, and monitoring support.",
      service: "Maintenance Package Consultation",
    },
    {
      image:
        "https://vibe.filesafe.space/1792820769937918655/assets/45e07bc3-95e9-42a3-8428-67f5a36dba5a.png",
      imageAlt: isHi
        ? "पूर्ण टर्नकी रूफटॉप सोलर इंस्टॉलेशन"
        : "Complete turnkey rooftop solar installation",
      title: isHi ? "व्यापक सोलर समाधान (Comprehensive EPC)" : "Comprehensive Turnkey EPC",
      desc: isHi
        ? "डिजाइन से स्विच-ऑन तक 100% जिम्मेदारी एक ही विश्वसनीय कंपनी के पास।"
        : "Single-point ownership ensuring unified warranties and reliable clean generation.",
      service: "Comprehensive Solar Consultation",
    },
  ];

  return (
    <section className="relative py-16 sm:py-24 bg-card/40 border-b border-border/40 overflow-hidden">
      <LeafDecor variant="light" density="medium" />
      <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs font-bold uppercase tracking-wider text-primary">
            {isHi ? "हमारी प्रतिबद्धता" : "What We Deliver"}
          </span>
          <h2 className="mt-2 font-display text-3xl sm:text-4xl font-extrabold text-foreground">
            {isHi ? "एलियोस की संपूर्ण सोलर सेवाएं" : "Complete Solar Project Offerings"}
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {offerings.map((item) => (
            <div
              key={item.title}
              className="group rounded-2xl bg-card border border-border overflow-hidden flex flex-col transition-all duration-300 hover:shadow-xl hover:-translate-y-1 hover:border-primary/40"
            >
              <div className="relative aspect-[4/3] overflow-hidden">
                <img
                  src={item.image}
                  alt={item.imageAlt}
                  loading="lazy"
                  className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-navy-premium/70 via-navy-premium/10 to-transparent pointer-events-none" />
              </div>
              <div className="p-6 flex-1 flex flex-col">
                <h4 className="font-display text-lg font-bold text-foreground">{item.title}</h4>
                <p className="mt-2 text-sm text-muted-foreground leading-relaxed flex-1">
                  {item.desc}
                </p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-10 text-center">
          <button
            onClick={() => onOpenQuote("Comprehensive Solar Consultation")}
            className="inline-flex items-center gap-2 rounded-xl bg-secondary px-6 py-3.5 text-sm font-bold text-secondary-foreground shadow-sm hover:bg-secondary/90 active:scale-95 transition-all"
          >
            <span>{t("talkExpert")}</span>
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      </div>
    </section>
  );
}
