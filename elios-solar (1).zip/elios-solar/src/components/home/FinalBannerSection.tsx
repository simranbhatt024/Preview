import React from "react";
import { motion, useReducedMotion } from "framer-motion";
import { useLocale } from "../../lib/locale-context";
import { ASSETS, CONTACT_INFO } from "../../lib/constants";
import { Sun, Phone, Clock, ArrowRight } from "lucide-react";

interface FinalBannerSectionProps {
  onOpenQuote: (service?: string) => void;
}

export function FinalBannerSection({ onOpenQuote }: FinalBannerSectionProps) {
  const { t, isHi } = useLocale();
  const reduceMotion = useReducedMotion();

  return (
    <section className="relative py-20 bg-secondary text-secondary-foreground bg-sun-rays-dark overflow-hidden">
      {/* Animated rotating sun rays motif */}
      <motion.div
        aria-hidden
        className="pointer-events-none absolute -top-32 left-1/2 -translate-x-1/2 opacity-20"
        animate={reduceMotion ? {} : { rotate: 360 }}
        transition={{ duration: 60, repeat: Infinity, ease: "linear" }}
      >
        <svg width="500" height="500" viewBox="0 0 500 500">
          {[...Array(18)].map((_, i) => {
            const angle = i * 20 * (Math.PI / 180);
            return (
              <line
                key={i}
                x1={250 + Math.cos(angle) * 120}
                y1={250 + Math.sin(angle) * 120}
                x2={250 + Math.cos(angle) * 240}
                y2={250 + Math.sin(angle) * 240}
                stroke="#DA9440"
                strokeWidth="2"
                strokeLinecap="round"
              />
            );
          })}
        </svg>
      </motion.div>

      {/* Floating orbs */}
      <motion.div
        aria-hidden
        className="pointer-events-none absolute top-10 right-10 h-40 w-40 rounded-full blur-3xl"
        style={{
          background: "radial-gradient(circle, oklch(0.766 0.133 71 / 0.3), transparent 70%)",
        }}
        animate={reduceMotion ? {} : { scale: [1, 1.3, 1], opacity: [0.4, 0.7, 0.4] }}
        transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div
        aria-hidden
        className="pointer-events-none absolute bottom-10 left-10 h-48 w-48 rounded-full blur-3xl bg-sky-orb"
        animate={reduceMotion ? {} : { scale: [1.1, 1.3, 1.1], opacity: [0.3, 0.6, 0.3] }}
        transition={{ duration: 8, repeat: Infinity, ease: "easeInOut", delay: 1 }}
      />

      <div className="mx-auto max-w-5xl px-4 sm:px-6 text-center relative z-10">
        <motion.div
          className="inline-flex items-center justify-center p-3 rounded-2xl bg-card text-foreground mb-6 shadow-xl"
          initial={{ opacity: 0, scale: 0.8 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, type: "spring" }}
          whileHover={reduceMotion ? {} : { rotate: [0, -5, 5, 0] }}
        >
          <img src={ASSETS.logo} alt="Elios Logo" className="h-12 w-12 object-contain" />
        </motion.div>

        <motion.h2
          className="font-display text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white leading-tight"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          {isHi
            ? "आज ही अपने घर अथवा व्यवसाय को सोलर से जोड़ें"
            : "Power Your Home & Business with Solar Today"}
        </motion.h2>

        <motion.p
          className="mt-4 text-base text-secondary-foreground/80 max-w-2xl mx-auto leading-relaxed"
          initial={{ opacity: 0, y: 15 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.15, duration: 0.6 }}
        >
          {isHi
            ? "मुफ़्त छत निरीक्षण और बचत का व्यक्तिगत आकलन प्राप्त करें। हमारे विशेषज्ञ आपकी सहायता के लिए तैयार हैं।"
            : "Book your free rooftop assessment. Our technical solar engineers handle design, subsidy filing, and net metering end-to-end."}
        </motion.p>

        <motion.div
          className="mt-8 flex flex-col sm:flex-row justify-center items-center gap-4"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3, duration: 0.6 }}
        >
          <motion.button
            onClick={() => onOpenQuote("Residential Homes")}
            whileHover={
              reduceMotion
                ? {}
                : { scale: 1.05, boxShadow: "0 20px 40px -10px oklch(0.721 0.129 68 / 0.5)" }
            }
            whileTap={{ scale: 0.95 }}
            className="inline-flex items-center justify-center gap-2 rounded-xl bg-primary px-8 py-4 text-base font-bold text-primary-foreground shadow-xl transition-all hover:bg-primary-hover"
          >
            <Sun className="h-5 w-5" />
            <span>{t("getFreeQuotation")}</span>
            <ArrowRight className="h-4 w-4" />
          </motion.button>

          <motion.a
            href={CONTACT_INFO.phoneTel}
            whileHover={reduceMotion ? {} : { scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="inline-flex items-center justify-center gap-2 rounded-xl border border-white/20 bg-white/10 px-8 py-4 text-base font-bold text-white backdrop-blur-sm transition-all hover:bg-white/20"
          >
            <Phone className="h-5 w-5 text-primary" />
            <span>{CONTACT_INFO.phone}</span>
          </motion.a>
        </motion.div>

        <motion.p
          className="mt-8 text-xs text-secondary-foreground/60 flex items-center justify-center gap-1.5"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5 }}
        >
          <motion.span
            animate={reduceMotion ? {} : { scale: [1, 1.2, 1] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            <Clock className="h-3.5 w-3.5 text-primary" />
          </motion.span>
          <span>
            {isHi
              ? "हमारे सोलर विशेषज्ञ सोमवार से शनिवार, सुबह 9 से शाम 7 बजे तक उपलब्ध हैं।"
              : "Our solar experts are available Monday to Saturday, 9 AM to 7 PM."}
          </span>
        </motion.p>
      </div>
    </section>
  );
}
