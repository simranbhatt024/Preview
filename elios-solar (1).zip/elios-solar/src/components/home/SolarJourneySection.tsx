import React, { useState } from "react";
import { motion, useReducedMotion, AnimatePresence } from "framer-motion";
import { useLocale } from "../../lib/locale-context";
import {
  ArrowRight,
  ClipboardCheck,
  PencilRuler,
  FileCheck2,
  PanelsTopLeft,
  Zap,
  Gauge,
  Rocket,
  Clock,
} from "lucide-react";
import { LeafDecor } from "./LeafDecor";

interface SolarJourneySectionProps {
  onOpenQuote: (service?: string) => void;
}

type Stage = {
  id: number;
  icon: React.ComponentType<{ className?: string }>;
  dayLabelEn: string;
  dayLabelHi: string;
  titleEn: string;
  titleHi: string;
  detailEn: string;
  detailHi: string;
  accent: string;
};

export function SolarJourneySection({ onOpenQuote }: SolarJourneySectionProps) {
  const { t, isHi } = useLocale();
  const reduceMotion = useReducedMotion();
  const [active, setActive] = useState(0);

  const stages: Stage[] = [
    {
      id: 0,
      icon: ClipboardCheck,
      dayLabelEn: "Day 1",
      dayLabelHi: "पहला दिन",
      titleEn: "Site Visit & Load Survey",
      titleHi: "साइट विज़िट और लोड सर्वे",
      detailEn:
        "Our solar engineer measures your terrace, checks shadow patterns across the day, reviews your last 12 months of electricity bills, and confirms the sanctioned load with your DISCOM.",
      detailHi:
        "हमारे सोलर इंजीनियर आपकी छत को नापते हैं, पूरे दिन की छाया की जाँच करते हैं, पिछले 12 महीनों के बिजली बिल देखते हैं, और डिस्कॉम से सैक्शन्ड लोड की पुष्टि करते हैं।",
      accent: "var(--color-accent-sky)",
    },
    {
      id: 1,
      icon: PencilRuler,
      dayLabelEn: "Day 2–3",
      dayLabelHi: "दूसरे–तीसरे दिन",
      titleEn: "Custom Design & Net-Metering File",
      titleHi: "कस्टम डिज़ाइन और नेट-मीटरिंग फाइल",
      detailEn:
        "We draft your single-line diagram, panel layout, and structural plan, then prepare and submit the net-metering application to your local DISCOM on your behalf.",
      detailHi:
        "हम आपका सिंगल-लाइन डायग्राम, पैनल लेआउट और स्ट्रक्चरल प्लान बनाते हैं, फिर आपकी ओर से डिस्कॉम में नेट-मीटरिंग आवेदन तैयार करके जमा करते हैं।",
      accent: "var(--color-accent-teal)",
    },
    {
      id: 2,
      icon: FileCheck2,
      dayLabelEn: "Day 4–6",
      dayLabelHi: "चौथे–छठे दिन",
      titleEn: "Subsidy Approval & Procurement",
      titleHi: "सब्सिडी अप्रूवल और आपूर्ति",
      detailEn:
        "We file your PM Surya Ghar subsidy application and simultaneously place the order for ALMM-listed Tier-1 modules, inverters, and galvanized mounting structures.",
      detailHi:
        "हम आपकी पीएम सूर्य घर सब्सिडी का आवेदन दाखिल करते हैं और साथ ही ALMM-सूचीबद्ध टियर-1 मॉड्यूल, इन्वर्टर और गैल्वेनाइज्ड माउंटिंग स्ट्रक्चर का ऑर्डर लगाते हैं।",
      accent: "var(--color-primary)",
    },
    {
      id: 3,
      icon: PanelsTopLeft,
      dayLabelEn: "Day 7–10",
      dayLabelHi: "सातवें–दसवें दिन",
      titleEn: "Rooftop Engineering & Mounting",
      titleHi: "रूफटॉप इंजीनियरिंग और माउंटिंग",
      detailEn:
        "Certified crews bolt the waterproof mounting structure, lay the modules, run the DC and AC cabling, install the inverter, and complete the earthing and lightning arrester pits.",
      detailHi:
        "प्रमाणित टीम वाटरप्रूफ माउंटिंग स्ट्रक्चर लगाती है, मॉड्यूल रखती है, DC और AC केबिलिंग करती है, इन्वर्टर इंस्टॉल करती है, और अर्दिंग व लाइटनिंग एरेस्टर पिट पूरे करती है।",
      accent: "var(--color-accent-gold)",
    },
    {
      id: 4,
      icon: Zap,
      dayLabelEn: "Day 11–12",
      dayLabelHi: "ग्यारहवें–बारहवें दिन",
      titleEn: "Testing, Commissioning & Switch-On",
      titleHi: "टेस्टिंग, कमीशनिंग और स्विच-ऑन",
      detailEn:
        "Final insulation and generation testing, DISCOM meter sealing, and the moment your rooftop starts generating clean power — handed over with a full performance report.",
      detailHi:
        "अंतिम इंसुलेशन और जनरेशन टेस्टिंग, डिस्कॉम मीटर सीलिंग, और वह क्षण जब आपकी छत स्वच्छ बिजली बनाना शुरू करती है — पूरी परफॉरमेंस रिपोर्ट के साथ सौंपा जाता है।",
      accent: "var(--color-success)",
    },
  ];

  const activeStage = stages[active] ?? stages[stages.length - 1]!;

  return (
    <section className="relative py-16 sm:py-24 border-b border-border/40 bg-solar-journey overflow-hidden">
      <LeafDecor variant="light" density="low" />
      <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6">
        {/* Heading */}
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-primary">
            <Rocket className="h-4 w-4" />
            {isHi ? "सोलर जर्नी" : "Your Solar Journey"}
          </span>
          <h2 className="mt-3 font-display text-3xl sm:text-4xl font-extrabold text-foreground">
            {isHi
              ? "एलियोस के साथ 12 दिन में सोलर पर स्विच-ऑन"
              : "From Site Visit to Switch-On in 12 Days"}
          </h2>
          <p className="mt-4 text-base text-muted-foreground leading-relaxed">
            {isHi
              ? "हर चरण एक ही टीम से — सर्वे से लेकर कमीशनिंग तक। कोई बिचौलिया नहीं, कोई देरी नहीं।"
              : "Every stage handled by one Elios team — from survey to commissioning. No middlemen, no delays."}
          </p>
        </div>

        {/* Turnaround comparison meter */}
        <div className="mb-14 rounded-3xl border border-border bg-card p-6 sm:p-8 shadow-sm">
          <div className="flex flex-col sm:flex-row items-center gap-6 sm:gap-10">
            <div className="flex items-center gap-3 shrink-0">
              <div className="h-12 w-12 rounded-2xl bg-primary/15 text-primary flex items-center justify-center">
                <Gauge className="h-6 w-6" />
              </div>
              <div>
                <p className="font-display text-2xl font-extrabold text-foreground">
                  {isHi ? "7–12 दिन" : "7–12 Days"}
                </p>
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                  {isHi ? "एलियोस टर्नअराउंड" : "Elios Turnaround"}
                </p>
              </div>
            </div>

            <div className="flex-1 w-full space-y-3">
              <SpeedBar
                label={isHi ? "एलियोस औसत" : "Elios Average"}
                value={12}
                max={60}
                color="var(--color-primary)"
                days={isHi ? "12 दिन" : "12 days"}
                reduceMotion={reduceMotion}
              />
              <SpeedBar
                label={isHi ? "उद्योग औसत" : "Industry Average"}
                value={45}
                max={60}
                color="var(--color-muted-foreground)"
                days={isHi ? "45+ दिन" : "45+ days"}
                reduceMotion={reduceMotion}
                dim
              />
            </div>
          </div>
        </div>

        {/* Interactive stage tracker */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-start">
          {/* Left: stage rail */}
          <div className="lg:col-span-7">
            <div className="relative">
              {/* Connecting animated line */}
              <div
                className="absolute left-6 top-6 bottom-6 w-0.5 bg-border hidden sm:block"
                aria-hidden
              />
              <motion.div
                className="absolute left-6 top-6 w-0.5 bg-primary hidden sm:block"
                aria-hidden
                initial={false}
                animate={{
                  height: `${((active + 1) / stages.length) * 100}%`,
                }}
                transition={{ duration: reduceMotion ? 0 : 0.5, ease: "easeOut" }}
                style={{ maxHeight: "calc(100% - 3rem)" }}
              />

              <div className="space-y-3">
                {stages.map((stage) => {
                  const Icon = stage.icon;
                  const isActive = stage.id === active;
                  const isDone = stage.id < active;
                  return (
                    <button
                      key={stage.id}
                      onClick={() => setActive(stage.id)}
                      className={`group relative flex w-full items-start gap-4 rounded-2xl border p-4 text-left transition-all ${
                        isActive
                          ? "border-primary/40 bg-primary/5 shadow-md"
                          : "border-border bg-card hover:border-primary/20 hover:bg-card/60"
                      }`}
                    >
                      <div
                        className={`relative z-10 flex h-12 w-12 shrink-0 items-center justify-center rounded-xl transition-all ${
                          isActive
                            ? "bg-primary text-primary-foreground shadow-lg shadow-primary/20"
                            : isDone
                              ? "bg-primary/15 text-primary"
                              : "bg-muted text-muted-foreground"
                        }`}
                      >
                        <Icon className="h-5 w-5" />
                      </div>
                      <div className="min-w-0 flex-1 pt-0.5">
                        <div className="flex flex-wrap items-center gap-2">
                          <span
                            className="rounded-full px-2.5 py-0.5 text-[11px] font-bold uppercase tracking-wide"
                            style={{
                              backgroundColor: `color-mix(in oklab, ${stage.accent} 14%, transparent)`,
                              color: stage.accent,
                            }}
                          >
                            {isHi ? stage.dayLabelHi : stage.dayLabelEn}
                          </span>
                        </div>
                        <h3
                          className={`mt-1.5 font-display text-base font-bold ${
                            isActive ? "text-foreground" : "text-foreground/80"
                          }`}
                        >
                          {isHi ? stage.titleHi : stage.titleEn}
                        </h3>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Right: active stage detail card */}
          <div className="lg:col-span-5 lg:sticky lg:top-24">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeStage.id}
                initial={reduceMotion ? { opacity: 0 } : { opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: reduceMotion ? 0 : -8 }}
                transition={{ duration: 0.3 }}
                className="overflow-hidden rounded-3xl border border-border bg-card shadow-lg"
              >
                <div className="h-2 w-full" style={{ backgroundColor: activeStage.accent }} />
                <div className="p-6 sm:p-8">
                  <div className="flex items-center gap-3 mb-5">
                    <div
                      className="flex h-14 w-14 items-center justify-center rounded-2xl"
                      style={{
                        backgroundColor: `color-mix(in oklab, ${activeStage.accent} 15%, transparent)`,
                        color: activeStage.accent,
                      }}
                    >
                      <activeStage.icon className="h-7 w-7" />
                    </div>
                    <div>
                      <p className="text-xs font-bold uppercase tracking-wide text-muted-foreground">
                        {isHi ? "चरण" : "Stage"} {activeStage.id + 1} / {stages.length}
                      </p>
                      <h3 className="font-display text-xl font-bold text-foreground">
                        {isHi ? activeStage.titleHi : activeStage.titleEn}
                      </h3>
                    </div>
                  </div>

                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {isHi ? activeStage.detailHi : activeStage.detailEn}
                  </p>

                  <div className="mt-6 flex items-center gap-2 rounded-xl bg-muted/60 p-3.5">
                    <Clock className="h-4 w-4 shrink-0 text-primary" />
                    <p className="text-xs font-semibold text-foreground">
                      {isHi
                        ? `समय: ${activeStage.dayLabelHi}`
                        : `Timeline: ${activeStage.dayLabelEn}`}
                    </p>
                  </div>

                  <button
                    onClick={() => onOpenQuote("Solar Journey Consultation")}
                    className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-primary px-6 py-3.5 text-sm font-bold text-primary-foreground shadow-sm transition-all hover:bg-primary-hover active:scale-[0.98]"
                  >
                    <span>{t("startProject")}</span>
                    <ArrowRight className="h-4 w-4" />
                  </button>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </div>
    </section>
  );
}

function SpeedBar({
  label,
  value,
  max,
  color,
  days,
  reduceMotion,
  dim,
}: {
  label: string;
  value: number;
  max: number;
  color: string;
  days: string;
  reduceMotion: boolean | null;
  dim?: boolean;
}) {
  return (
    <div>
      <div className="flex items-center justify-between mb-1.5">
        <span
          className={`text-sm font-semibold ${dim ? "text-muted-foreground" : "text-foreground"}`}
        >
          {label}
        </span>
        <span className={`text-xs font-bold ${dim ? "text-muted-foreground" : "text-primary"}`}>
          {days}
        </span>
      </div>
      <div className="h-2.5 w-full overflow-hidden rounded-full bg-muted">
        <motion.div
          className="h-full rounded-full"
          style={{ backgroundColor: color }}
          initial={reduceMotion ? false : { width: 0 }}
          whileInView={{ width: `${(value / max) * 100}%` }}
          viewport={{ once: true }}
          transition={{ duration: reduceMotion ? 0 : 1, ease: "easeOut" }}
        />
      </div>
    </div>
  );
}
