import React from "react";
import { useLocale } from "../../lib/locale-context";
import { CheckCircle, ArrowRight } from "lucide-react";
import { LeafDecor } from "./LeafDecor";

interface SolarLoanSectionProps {
  onOpenQuote: (service?: string) => void;
}

export function SolarLoanSection({ onOpenQuote }: SolarLoanSectionProps) {
  const { t, isHi } = useLocale();

  return (
    <section className="relative py-16 sm:py-24 bg-cream-premium border-b border-border/40 overflow-hidden">
      <LeafDecor variant="light" density="low" />
      <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-6">
            <span className="text-xs font-bold uppercase tracking-wider text-primary">
              {isHi ? "आसान लोन सुविधा" : "Zero Hassle Financing"}
            </span>
            <h2 className="mt-2 font-display text-3xl sm:text-4xl font-extrabold text-foreground">
              {isHi
                ? "किफायती ईएमआई • कागजी कार्रवाई एलियोस संभालती है"
                : "Affordable Solar EMI • We Handle All Paperwork"}
            </h2>
            <p className="mt-4 text-sm sm:text-base text-muted-foreground leading-relaxed">
              {isHi
                ? "सोलर पैनल लगाने के लिए एकमुश्त बड़ी पूंजी की आवश्यकता नहीं है। हमारे बैंकिंग पार्टनर्स के साथ कम ब्याज दरों पर आसान ईएमआई उपलब्ध है, और बैंक अनुमोदन से लेकर डिस्कॉम नेट-मीटरिंग तक के सारे कागजात एलियोस की टीम तैयार करती है।"
                : "Switch to clean solar with zero financial strain. Elios Solar coordinates complete documentation with leading lending partners, ensuring fast loan processing so your monthly power savings help offset the EMI."}
            </p>

            <div className="mt-6 space-y-3">
              <div className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-success shrink-0 mt-0.5" />
                <span className="text-sm font-semibold text-foreground">
                  {isHi
                    ? "न्यूनतम दस्तावेज और त्वरित स्वीकृति प्रक्रिया"
                    : "Minimal paperwork with swift partner bank approvals"}
                </span>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-success shrink-0 mt-0.5" />
                <span className="text-sm font-semibold text-foreground">
                  {isHi
                    ? "1 से 7 वर्ष तक की लचीली पुनर्भुगतान अवधि"
                    : "Flexible repayment tenures from 1 to 7 years"}
                </span>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-success shrink-0 mt-0.5" />
                <span className="text-sm font-semibold text-foreground">
                  {isHi
                    ? "बिजली बिल की बचत से ही ईएमआई का भुगतान संभव"
                    : "Monthly electricity bill savings help finance the loan"}
                </span>
              </div>
            </div>

            <p className="mt-6 text-xs text-muted-foreground italic">{t("loanDisclaimer")}</p>

            <div className="mt-8">
              <button
                onClick={() => onOpenQuote("Solar Loan Enquiry")}
                className="inline-flex items-center gap-2 rounded-xl bg-primary px-6 py-3.5 text-sm font-bold text-primary-foreground shadow-sm hover:bg-primary-hover active:scale-95"
              >
                <span>{t("checkLoanOptions")}</span>
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          </div>

          {/* Illustrative Loan Calculation Tile */}
          <div className="lg:col-span-6 rounded-3xl border border-border bg-gradient-to-br from-background to-accent-sky/5 p-8 shadow-sm">
            <h3 className="font-display text-xl font-bold text-foreground mb-4">
              {isHi
                ? "उदाहरण ईएमआई विश्लेषण (3 kW सिस्टम)"
                : "Illustrative EMI Breakdown (3 kW System)"}
            </h3>
            <div className="space-y-4 text-sm">
              <div className="flex justify-between border-b border-border pb-2">
                <span className="text-muted-foreground">
                  {isHi ? "अनुमानित परियोजना लागत:" : "Estimated System Cost:"}
                </span>
                <span className="font-bold text-foreground">₹1,80,000</span>
              </div>
              <div className="flex justify-between border-b border-border pb-2">
                <span className="text-muted-foreground">
                  {isHi ? "केंद्रीय सब्सिडी (अधिकतम):" : "Central Subsidy (Up to):"}
                </span>
                <span className="font-bold text-success">- ₹78,000</span>
              </div>
              <div className="flex justify-between border-b border-border pb-2">
                <span className="text-muted-foreground">
                  {isHi ? "निवल ऋण राशि (Net Loan):" : "Net Loan Required:"}
                </span>
                <span className="font-bold text-primary">₹1,02,000</span>
              </div>
              <div className="flex justify-between border-b border-border pb-2">
                <span className="text-muted-foreground">
                  {isHi ? "अनुमानित ईएमआई (5 वर्ष @ 9.0%):" : "Approx. EMI (5 yrs @ 9.0%):"}
                </span>
                <span className="font-display text-xl font-extrabold text-foreground">
                  ₹2,117 / {isHi ? "माह" : "mo"}
                </span>
              </div>
            </div>
            <div className="mt-6 rounded-xl bg-primary/10 p-3.5 text-xs font-medium text-foreground">
              {isHi
                ? "मासिक बिजली बिल में लगभग ₹2,800 की बचत से यह ईएमआई पूरी तरह संतुलित हो जाती है।"
                : "Your monthly electricity bill saving of ~₹2,800 comfortably covers this monthly installment."}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
