import React from "react";
import { Link } from "@tanstack/react-router";
import { motion, useReducedMotion } from "framer-motion";
import { useLocale } from "../../lib/locale-context";
import { Home, Building2, Factory, BatteryCharging, ChevronRight, ArrowRight } from "lucide-react";
import { LeafDecor } from "./LeafDecor";

interface ServicesShowcaseProps {
  onOpenQuote: (service?: string) => void;
}

export function ServicesShowcase({ onOpenQuote }: ServicesShowcaseProps) {
  const { t, isHi } = useLocale();
  const reduceMotion = useReducedMotion();

  const cards = [
    {
      icon: Home,
      title: t("residentialHomes"),
      descHi:
        "पीएम सूर्य घर योजना के तहत अधिकतम ₹78,000 सब्सिडी और आसान ईएमआई। बिजली बिल 90% तक कम करें।",
      descEn:
        "Central PM Surya Ghar subsidy up to ₹78,000 with low EMI bank financing. Zero hassle paperwork.",
      link: "/solar-solutions/residential-homes",
      service: "Residential Homes",
      image:
        "https://vibe.filesafe.space/1792820769937918655/assets/1d548657-d683-4b21-86ea-19337f117d5c.png",
      imageAlt: isHi
        ? "आवासीय घर पर रूफटॉप सोलर पैनल"
        : "Rooftop solar panels on a residential home",
      gradient: "from-primary/25 to-primary/5",
      iconBg: "bg-primary/15 text-primary",
    },
    {
      icon: Building2,
      title: t("housingSociety"),
      descHi:
        "अपार्टमेंट की लिफ्ट, पानी की मोटर और कॉरिडोर लाइटिंग को सोलर से चलाएं। मेंटेनेंस खर्च में भारी कटौती।",
      descEn:
        "Power elevators, water pumps, and shared lighting to drastically reduce residents' monthly maintenance fees.",
      link: "/solar-solutions/housing-society",
      service: "Housing Society",
      image:
        "https://vibe.filesafe.space/1792820769937918655/assets/9a7d5abd-9a4a-4f39-bc51-015f0d051514.png",
      imageAlt: isHi
        ? "हाउसिंग सोसाइटी पर रूफटॉप सोलर अरे"
        : "Rooftop solar array on a housing society building",
      gradient: "from-accent-sky/25 to-accent-sky/5",
      iconBg: "bg-accent-sky/15 text-accent-sky",
    },
    {
      icon: Factory,
      title: t("commercialIndustrial"),
      descHi:
        "चावल मिल, वेयरहाउस और फैक्ट्रियों के लिए उच्च आरओआई सोलर प्लांट। उत्पादन लागत में दीर्घकालिक बचत।",
      descEn:
        "Heavy load rooftop solar for rice mills, cold storages, and factories. Accelerated depreciation benefits.",
      link: "/solar-solutions/commercial-industrial",
      service: "Commercial & Industrial",
      image:
        "https://vibe.filesafe.space/1792820769937918655/assets/718a7169-2c00-40fb-afc7-612b4201055f.png",
      imageAlt: isHi
        ? "औद्योगिक छत पर व्यावसायिक सोलर पैनल"
        : "Commercial solar panels on an industrial rooftop",
      gradient: "from-accent-teal/25 to-accent-teal/5",
      iconBg: "bg-accent-teal/15 text-accent-teal",
    },
    {
      icon: BatteryCharging,
      title: t("offGridSolar"),
      descHi:
        "ग्रिड-रहित स्थानों और फार्महाउस के लिए हाइब्रिड इन्वर्टर और लिथियम बैटरी बैकअप। 24/7 निर्बाध बिजली।",
      descEn:
        "Zero-grid and remote sites powered with lithium battery banks and intelligent hybrid solar inverters.",
      link: "/solar-solutions/off-grid",
      service: "Off-Grid Solar",
      image:
        "https://vibe.filesafe.space/1792820769937918655/assets/c4a04055-e792-4fd6-b4d9-d4a607b76396.png",
      imageAlt: isHi
        ? "ग्रिड-रहित सोलर सेटअप और बैटरी बैंक"
        : "Off-grid solar setup with battery bank storage",
      gradient: "from-accent-gold/25 to-accent-gold/5",
      iconBg: "bg-accent-gold/15 text-accent-gold",
    },
  ];

  return (
    <section className="relative py-16 sm:py-24 bg-cream-premium border-b border-border/40 overflow-hidden">
      <LeafDecor variant="light" density="medium" />
      <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6">
        <motion.div
          className="text-center max-w-2xl mx-auto mb-14"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6 }}
        >
          <span className="text-xs font-bold uppercase tracking-wider text-primary">
            {isHi ? "हमारी सेवाएं" : "Turnkey EPC Services"}
          </span>
          <h2 className="mt-2 font-display text-3xl sm:text-4xl font-extrabold text-foreground">
            {isHi
              ? "प्रत्येक छत के लिए अनुकूलित सोलर समाधान"
              : "Tailored Clean Energy for Every Roof"}
          </h2>
          <p className="mt-3 text-sm text-muted-foreground">
            {isHi
              ? "इंजीनियरिंग से लेकर नेट मीटरिंग तक, तीव्र गति और उच्चतम मानकों के साथ इंस्टॉलेशन।"
              : "Engineered and commissioned rapidly with premium Tier-1 components across Bihar."}
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {cards.map((card, i) => (
            <motion.div
              key={i}
              className="group rounded-2xl border border-border bg-card flex flex-col justify-between shadow-sm hover:shadow-xl transition-all relative overflow-hidden"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-40px" }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              whileHover={reduceMotion ? {} : { y: -8 }}
            >
              {/* Gradient glow on hover */}
              <motion.div
                aria-hidden
                className={`absolute inset-0 bg-gradient-to-br ${card.gradient} opacity-0 group-hover:opacity-100 transition-opacity duration-500`}
              />
              {/* Content-matching image banner */}
              <div className="relative aspect-[4/3] overflow-hidden border-b border-border/60">
                <motion.img
                  src={card.image}
                  alt={card.imageAlt}
                  loading="lazy"
                  className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                  whileHover={reduceMotion ? {} : { scale: 1.05 }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-card/70 via-transparent to-transparent" />
                <motion.div
                  className={`absolute -bottom-5 left-5 h-12 w-12 rounded-xl flex items-center justify-center shadow-lg ring-4 ring-card ${card.iconBg}`}
                  whileHover={reduceMotion ? {} : { rotate: [0, -10, 10, 0], scale: 1.1 }}
                  transition={{ duration: 0.5 }}
                >
                  <card.icon className="h-6 w-6" />
                </motion.div>
              </div>
              <div className="relative p-6 pt-8 flex-1 flex flex-col">
                <h3 className="font-display text-xl font-bold text-foreground mb-2">
                  {card.title}
                </h3>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  {isHi ? card.descHi : card.descEn}
                </p>
              </div>
              <div className="relative px-6 pb-6 pt-4 border-t border-border/70 flex items-center justify-between gap-3">
                <Link
                  to={card.link}
                  className="inline-flex items-center gap-1.5 text-xs font-bold text-primary hover:text-primary-hover transition-colors group/link py-1.5"
                >
                  <span>{isHi ? "विवरण देखें" : "Explore"}</span>
                  <ChevronRight className="h-4 w-4 transition-transform group-hover/link:translate-x-1" />
                </Link>
                <motion.button
                  onClick={() => onOpenQuote(card.service)}
                  whileHover={reduceMotion ? {} : { scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                  className="rounded-lg bg-secondary px-3.5 py-2 text-xs font-semibold text-secondary-foreground shadow-sm hover:bg-secondary/90 transition-all flex items-center gap-1.5 shrink-0"
                >
                  <span>{t("requestQuote")}</span>
                  <ArrowRight className="h-3.5 w-3.5" />
                </motion.button>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          className="mt-12 text-center"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3 }}
        >
          <motion.button
            onClick={() => onOpenQuote("Residential Homes")}
            whileHover={reduceMotion ? {} : { scale: 1.04 }}
            whileTap={{ scale: 0.96 }}
            className="inline-flex items-center gap-2 rounded-xl bg-primary px-7 py-3.5 text-sm font-bold text-primary-foreground shadow-lg shadow-primary/20 transition-all hover:bg-primary-hover"
          >
            <span>{t("getFreeQuotation")}</span>
            <ArrowRight className="h-4 w-4" />
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
}
