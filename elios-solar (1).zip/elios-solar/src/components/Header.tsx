import React, { useState } from "react";
import { Link } from "@tanstack/react-router";
import { useLocale } from "../lib/locale-context";
import { ASSETS, CONTACT_INFO } from "../lib/constants";
import { ChevronDown, Menu, X, Phone, SunMedium, Globe2, ArrowRight } from "lucide-react";

interface HeaderProps {
  onOpenQuoteModal?: (service?: string) => void;
}

export function Header({ onOpenQuoteModal }: HeaderProps) {
  const { locale, setLocale, t, isHi } = useLocale();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [solutionsOpen, setSolutionsOpen] = useState(false);
  const [partnerOpen, setPartnerOpen] = useState(false);

  const toggleLocale = () => {
    setLocale(locale === "en" ? "hi" : "en");
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-border bg-background/95 backdrop-blur-md transition-all">
      {/* Top micro announcement bar */}
      <div className="bg-secondary px-4 py-1.5 text-xs text-secondary-foreground">
        <div className="mx-auto flex max-w-7xl items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="inline-block h-2 w-2 rounded-full bg-primary animate-pulse" />
            <span className="font-medium">
              {isHi
                ? "बिहार भर में रूफटॉप सोलर • सरकारी सब्सिडी एवं आसान लोन सुविधा उपलब्ध"
                : "Bihar's Trusted Solar EPC • PM Surya Ghar Subsidy & Easy EMI Available"}
            </span>
          </div>
          <div className="hidden sm:flex items-center gap-4 text-secondary-foreground/80">
            <a
              href={CONTACT_INFO.phoneTel}
              className="flex items-center gap-1.5 hover:text-primary transition-colors"
            >
              <Phone className="h-3.5 w-3.5 text-primary" />
              <span>{CONTACT_INFO.phone}</span>
            </a>
            <span className="text-secondary-foreground/40">|</span>
            <span>{isHi ? "सोमवार - शनिवार: 9 AM - 7 PM" : "Mon - Sat: 9 AM - 7 PM"}</span>
          </div>
        </div>
      </div>

      {/* Main navigation bar */}
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6">
        {/* Brand Logo */}
        <Link to="/" className="flex items-center gap-3 group">
          <div className="relative h-11 w-11 sm:h-12 sm:w-12 overflow-hidden rounded-lg border border-border/80 bg-white p-0.5 shadow-sm transition-transform group-hover:scale-105">
            <img
              src={ASSETS.logo}
              alt="Elios Solar Energy Logo"
              className="h-full w-full object-contain"
            />
          </div>
        </Link>

        {/* Desktop Nav Items */}
        <nav className="hidden lg:flex items-center gap-1 xl:gap-2 text-[14px] font-medium text-foreground">
          <Link
            to="/"
            className="rounded-md px-3 py-2 transition-colors hover:bg-muted hover:text-primary"
            activeProps={{ className: "text-primary font-semibold" }}
          >
            {t("home")}
          </Link>

          {/* Solutions Dropdown */}
          <div
            className="relative"
            onMouseEnter={() => setSolutionsOpen(true)}
            onMouseLeave={() => setSolutionsOpen(false)}
          >
            <button
              onClick={() => setSolutionsOpen(!solutionsOpen)}
              className="flex items-center gap-1 rounded-md px-3 py-2 transition-colors hover:bg-muted hover:text-primary"
            >
              <span>{t("solarSolutions")}</span>
              <ChevronDown className="h-4 w-4 opacity-70" />
            </button>

            {solutionsOpen && (
              <div className="absolute left-0 top-full w-64 rounded-xl border border-border bg-popover p-2 shadow-xl animate-in fade-in-50 zoom-in-95">
                <Link
                  to="/solar-solutions/residential-homes"
                  onClick={() => setSolutionsOpen(false)}
                  className="flex flex-col rounded-lg p-2.5 transition-colors hover:bg-muted"
                >
                  <span className="font-semibold text-foreground">{t("residentialHomes")}</span>
                  <span className="text-xs text-muted-foreground">
                    {isHi ? "सब्सिडी के साथ घरों के लिए" : "PM Surya Ghar subsidy up to ₹78,000"}
                  </span>
                </Link>
                <Link
                  to="/solar-solutions/housing-society"
                  onClick={() => setSolutionsOpen(false)}
                  className="flex flex-col rounded-lg p-2.5 transition-colors hover:bg-muted"
                >
                  <span className="font-semibold text-foreground">{t("housingSociety")}</span>
                  <span className="text-xs text-muted-foreground">
                    {isHi
                      ? "लिफ्ट एवं कॉमन एरिया बिजली बिल बचत"
                      : "Cut common maintenance & lift power costs"}
                  </span>
                </Link>
                <Link
                  to="/solar-solutions/commercial-industrial"
                  onClick={() => setSolutionsOpen(false)}
                  className="flex flex-col rounded-lg p-2.5 transition-colors hover:bg-muted"
                >
                  <span className="font-semibold text-foreground">{t("commercialIndustrial")}</span>
                  <span className="text-xs text-muted-foreground">
                    {isHi
                      ? "फैक्ट्री, गोदाम व चावल मिल हेतु"
                      : "High ROI rooftop plants for factories & mills"}
                  </span>
                </Link>
                <Link
                  to="/solar-solutions/off-grid"
                  onClick={() => setSolutionsOpen(false)}
                  className="flex flex-col rounded-lg p-2.5 transition-colors hover:bg-muted"
                >
                  <span className="font-semibold text-foreground">{t("offGridSolar")}</span>
                  <span className="text-xs text-muted-foreground">
                    {isHi
                      ? "बैटरी बैकअप एवं रिमोट साइट्स"
                      : "Battery storage for zero-grid locations"}
                  </span>
                </Link>
              </div>
            )}
          </div>

          {/* Become a Partner dropdown */}
          <div
            className="relative"
            onMouseEnter={() => setPartnerOpen(true)}
            onMouseLeave={() => setPartnerOpen(false)}
          >
            <button
              onClick={() => setPartnerOpen(!partnerOpen)}
              className="flex items-center gap-1 rounded-md px-3 py-2 transition-colors hover:bg-muted hover:text-primary"
            >
              <span>{t("becomePartner")}</span>
              <ChevronDown className="h-4 w-4 opacity-70" />
            </button>

            {partnerOpen && (
              <div className="absolute left-0 top-full w-56 rounded-xl border border-border bg-popover p-2 shadow-xl animate-in fade-in-50 zoom-in-95">
                <Link
                  to="/become-a-partner/referral-program"
                  onClick={() => setPartnerOpen(false)}
                  className="block rounded-lg p-2.5 transition-colors hover:bg-muted font-medium"
                >
                  {t("referralProgram")}
                </Link>
                <Link
                  to="/become-a-partner/learn-and-earn"
                  onClick={() => setPartnerOpen(false)}
                  className="block rounded-lg p-2.5 transition-colors hover:bg-muted font-medium"
                >
                  {t("learnAndEarn")}
                </Link>
                <Link
                  to="/become-a-partner/solar-body-program"
                  onClick={() => setPartnerOpen(false)}
                  className="block rounded-lg p-2.5 transition-colors hover:bg-muted font-medium"
                >
                  {t("solarBody")}
                </Link>
              </div>
            )}
          </div>

          <Link
            to="/products"
            className="rounded-md px-3 py-2 transition-colors hover:bg-muted hover:text-primary"
            activeProps={{ className: "text-primary font-semibold" }}
          >
            {t("productsServices")}
          </Link>

          <Link
            to="/news"
            className="rounded-md px-3 py-2 transition-colors hover:bg-muted hover:text-primary"
            activeProps={{ className: "text-primary font-semibold" }}
          >
            {t("newsBlogs")}
          </Link>

          <Link
            to="/about"
            className="rounded-md px-3 py-2 transition-colors hover:bg-muted hover:text-primary"
            activeProps={{ className: "text-primary font-semibold" }}
          >
            {t("aboutUs")}
          </Link>
        </nav>

        {/* Action controls & language toggle */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Language toggle EN | हिं */}
          <button
            onClick={toggleLocale}
            className="flex items-center gap-1.5 rounded-full border border-border bg-card px-2.5 py-1 text-xs font-semibold text-foreground transition-all hover:border-primary hover:text-primary focus:outline-none"
            title="Switch Language / भाषा बदलें"
          >
            <Globe2 className="h-3.5 w-3.5 text-primary" />
            <span>{locale === "en" ? "हिन्दी" : "English"}</span>
          </button>

          {/* Admin link badge */}
          <Link
            to="/admin"
            className="hidden sm:inline-flex rounded-md border border-border px-2.5 py-1 text-xs font-medium text-muted-foreground hover:bg-muted hover:text-foreground"
          >
            {t("adminDashboard")}
          </Link>

          {/* Primary CTA button */}
          <button
            onClick={() =>
              onOpenQuoteModal
                ? onOpenQuoteModal("Residential Homes")
                : window.location.assign("/contact")
            }
            className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-3.5 py-2 text-xs sm:text-sm font-semibold text-primary-foreground shadow-sm transition-all hover:bg-primary-hover active:scale-95"
          >
            <SunMedium className="h-4 w-4" />
            <span>{t("getFreeQuotation")}</span>
          </button>

          {/* Mobile hamburger button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="inline-flex lg:hidden rounded-lg p-2 text-foreground hover:bg-muted"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-border bg-background px-4 py-4 shadow-xl">
          <nav className="flex flex-col gap-2 font-medium">
            <Link
              to="/"
              onClick={() => setMobileMenuOpen(false)}
              className="rounded-lg px-3 py-2 text-foreground hover:bg-muted"
            >
              {t("home")}
            </Link>

            <div className="py-1">
              <div className="px-3 text-xs font-semibold uppercase text-muted-foreground">
                {t("solarSolutions")}
              </div>
              <div className="ml-2 mt-1 flex flex-col gap-1 border-l-2 border-primary/30 pl-2">
                <Link
                  to="/solar-solutions/residential-homes"
                  onClick={() => setMobileMenuOpen(false)}
                  className="rounded-lg px-3 py-1.5 text-sm hover:bg-muted"
                >
                  {t("residentialHomes")}
                </Link>
                <Link
                  to="/solar-solutions/housing-society"
                  onClick={() => setMobileMenuOpen(false)}
                  className="rounded-lg px-3 py-1.5 text-sm hover:bg-muted"
                >
                  {t("housingSociety")}
                </Link>
                <Link
                  to="/solar-solutions/commercial-industrial"
                  onClick={() => setMobileMenuOpen(false)}
                  className="rounded-lg px-3 py-1.5 text-sm hover:bg-muted"
                >
                  {t("commercialIndustrial")}
                </Link>
                <Link
                  to="/solar-solutions/off-grid"
                  onClick={() => setMobileMenuOpen(false)}
                  className="rounded-lg px-3 py-1.5 text-sm hover:bg-muted"
                >
                  {t("offGridSolar")}
                </Link>
              </div>
            </div>

            <div className="py-1">
              <div className="px-3 text-xs font-semibold uppercase text-muted-foreground">
                {t("becomePartner")}
              </div>
              <div className="ml-2 mt-1 flex flex-col gap-1 border-l-2 border-primary/30 pl-2">
                <Link
                  to="/become-a-partner/referral-program"
                  onClick={() => setMobileMenuOpen(false)}
                  className="rounded-lg px-3 py-1.5 text-sm hover:bg-muted"
                >
                  {t("referralProgram")}
                </Link>
                <Link
                  to="/become-a-partner/learn-and-earn"
                  onClick={() => setMobileMenuOpen(false)}
                  className="rounded-lg px-3 py-1.5 text-sm hover:bg-muted"
                >
                  {t("learnAndEarn")}
                </Link>
                <Link
                  to="/become-a-partner/solar-body-program"
                  onClick={() => setMobileMenuOpen(false)}
                  className="rounded-lg px-3 py-1.5 text-sm hover:bg-muted"
                >
                  {t("solarBody")}
                </Link>
              </div>
            </div>

            <Link
              to="/products"
              onClick={() => setMobileMenuOpen(false)}
              className="rounded-lg px-3 py-2 text-foreground hover:bg-muted"
            >
              {t("productsServices")}
            </Link>

            <Link
              to="/news"
              onClick={() => setMobileMenuOpen(false)}
              className="rounded-lg px-3 py-2 text-foreground hover:bg-muted"
            >
              {t("newsBlogs")}
            </Link>

            <Link
              to="/about"
              onClick={() => setMobileMenuOpen(false)}
              className="rounded-lg px-3 py-2 text-foreground hover:bg-muted"
            >
              {t("aboutUs")}
            </Link>

            <div className="mt-3 flex flex-col gap-2 pt-3 border-t border-border">
              <Link
                to="/admin"
                onClick={() => setMobileMenuOpen(false)}
                className="rounded-lg border border-border px-3 py-2 text-center text-sm font-medium"
              >
                {t("adminDashboard")}
              </Link>
              <a
                href={CONTACT_INFO.phoneTel}
                className="flex items-center justify-center gap-2 rounded-lg bg-secondary px-3 py-2 text-sm font-medium text-secondary-foreground"
              >
                <Phone className="h-4 w-4 text-primary" />
                <span>{CONTACT_INFO.phone}</span>
              </a>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}
