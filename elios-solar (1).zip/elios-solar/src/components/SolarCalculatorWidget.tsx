import React, { useState } from "react";
import { useLocale, formatINR } from "../lib/locale-context";
import { Calculator, ArrowRight, CheckCircle2, ShieldAlert } from "lucide-react";
import { submitLeadToCRM } from "../lib/crm-tracking";
import { redirectToWhatsApp } from "../lib/whatsapp";

interface SolarCalculatorWidgetProps {
  onGetExactQuote?: (calcData: any) => void;
}

export function SolarCalculatorWidget({ onGetExactQuote }: SolarCalculatorWidgetProps) {
  const { isHi, t } = useLocale();
  const [billType, setBillType] = useState<"monthly" | "yearly">("monthly");
  const [billAmount, setBillAmount] = useState<number>(3500);

  // Constants & assumptions
  const TARIFF = 7.0; // ₹7.00 per unit
  const GEN_PER_KW_DAY = 4.0; // 4 units per kW per day
  const COST_PER_KW = 60000; // ₹60,000 per kW indicative

  const monthlyBill = billType === "monthly" ? billAmount : billAmount / 12;
  const monthlyUnits = monthlyBill / TARIFF;

  // Calculate recommended kW: monthly units / (4 * 30), rounded up to 0.5 kW
  const rawKw = monthlyUnits / (GEN_PER_KW_DAY * 30);
  const recommendedKw = Math.max(1, Math.ceil(rawKw * 2) / 2);

  // Monthly and yearly savings
  const monthlySavings = Math.round(monthlyBill * 0.88);
  const yearlySavings = monthlySavings * 12;

  // Subsidy calculation (PM Surya Ghar rule)
  // Up to 2 kW: ₹30,000/kW. 3 kW+: capped at ₹78,000
  let centralSubsidy = 0;
  if (recommendedKw >= 1 && recommendedKw < 2) {
    centralSubsidy = 30000;
  } else if (recommendedKw >= 2 && recommendedKw < 3) {
    centralSubsidy = 60000;
  } else if (recommendedKw >= 3) {
    centralSubsidy = 78000;
  }

  const estimatedCost = recommendedKw * COST_PER_KW;
  const netCostAfterSubsidy = Math.max(0, estimatedCost - centralSubsidy);

  // Payback years
  const paybackBeforeSubsidy = (estimatedCost / yearlySavings).toFixed(1);
  const paybackAfterSubsidy = (netCostAfterSubsidy / yearlySavings).toFixed(1);

  const handleAction = () => {
    const calcData = {
      billAmount,
      billType,
      recommendedKw,
      monthlySavings,
      yearlySavings,
      centralSubsidy,
      netCostAfterSubsidy,
    };
    if (onGetExactQuote) {
      onGetExactQuote(calcData);
    } else {
      // Save calculator lead locally + push to CRM (non-blocking), then WhatsApp.
      submitLeadToCRM({
        formId: "elios-solar-calculator",
        formName: "Solar Calculator — Get Exact Quote",
        fullName: "Calculator Lead",
        phone: "",
        city: "",
        serviceNeeded: "Residential Homes",
        source: "calculator",
        message: `Bill: ₹${billAmount} (${billType}) | kW: ${recommendedKw} | Yearly savings: ₹${yearlySavings} | Subsidy: ₹${centralSubsidy}`,
      });
      const waText = `Hello Elios Solar Energy, I used your Solar Calculator:\n\n*Monthly Bill:* ₹${billAmount}\n*Recommended System:* ${recommendedKw} kW\n*Est. Yearly Savings:* ₹${yearlySavings}\n*Central Subsidy:* ₹${centralSubsidy}\n\nPlease share an exact quotation for my rooftop in Bihar.`;
      redirectToWhatsApp(waText);
    }
  };

  return (
    <div className="w-full rounded-3xl border border-border bg-card p-6 sm:p-8 shadow-sm">
      <div className="flex flex-col lg:flex-row gap-8 items-stretch">
        {/* Left Inputs */}
        <div className="w-full lg:w-1/2 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-bold uppercase tracking-wider text-primary">
                {isHi ? "तुरंत बचत का अनुमान" : "Instant Savings Estimation"}
              </span>
              <div className="flex rounded-lg border border-border bg-background p-1 text-xs">
                <button
                  type="button"
                  onClick={() => setBillType("monthly")}
                  className={`rounded-md px-3 py-1 font-semibold transition-all ${
                    billType === "monthly"
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground"
                  }`}
                >
                  {isHi ? "मासिक बिल" : "Monthly"}
                </button>
                <button
                  type="button"
                  onClick={() => setBillType("yearly")}
                  className={`rounded-md px-3 py-1 font-semibold transition-all ${
                    billType === "yearly"
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground"
                  }`}
                >
                  {isHi ? "वार्षिक बिल" : "Yearly"}
                </button>
              </div>
            </div>

            <label className="block text-sm font-semibold text-foreground mb-2">
              {billType === "monthly"
                ? isHi
                  ? "आपका औसत मासिक बिजली बिल:"
                  : "Your Average Monthly Electricity Bill:"
                : isHi
                  ? "आपका औसत वार्षिक बिजली बिल:"
                  : "Your Average Yearly Electricity Bill:"}
            </label>

            <div className="flex items-center gap-3 mb-4">
              <span className="font-display text-2xl font-bold text-foreground">
                {formatINR(billAmount)}
              </span>
            </div>

            <input
              type="range"
              min={billType === "monthly" ? 1000 : 12000}
              max={billType === "monthly" ? 30000 : 360000}
              step={billType === "monthly" ? 500 : 6000}
              value={billAmount}
              onChange={(e) => setBillAmount(Number(e.target.value))}
              className="w-full accent-primary h-2 bg-muted rounded-lg cursor-pointer"
            />
            <div className="flex justify-between text-[11px] text-muted-foreground mt-1">
              <span>{formatINR(billType === "monthly" ? 1000 : 12000)}</span>
              <span>{formatINR(billType === "monthly" ? 30000 : 360000)}</span>
            </div>
          </div>

          <div className="mt-6 rounded-2xl bg-secondary/5 border border-border/60 p-4">
            <div className="flex items-start gap-2.5 text-xs text-muted-foreground">
              <CheckCircle2 className="h-4 w-4 text-success shrink-0 mt-0.5" />
              <span>
                {isHi
                  ? `अनुमानित ग्रिड टैरिफ ₹${TARIFF.toFixed(2)}/यूनिट एवं बिहार धूप विकिरण के आधार पर गणना।`
                  : `Calculated at indicative grid tariff ₹${TARIFF.toFixed(2)}/kWh & average Bihar solar generation.`}
              </span>
            </div>
          </div>
        </div>

        {/* Right Output Projections */}
        <div className="w-full lg:w-1/2 flex flex-col justify-between rounded-2xl bg-background border border-border p-6 shadow-sm">
          <div>
            <h4 className="font-display text-lg font-bold text-foreground mb-4">
              {isHi ? "अनुशंसित सोलर सिस्टम एवं बचत" : "Recommended Rooftop System"}
            </h4>

            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="rounded-xl border border-border bg-card p-3.5">
                <span className="text-[11px] font-medium text-muted-foreground block">
                  {isHi ? "अनुशंसित प्लांट आकार" : "System Capacity"}
                </span>
                <span className="font-display text-2xl font-bold text-primary">
                  {recommendedKw} kW
                </span>
                <span className="text-[10px] text-muted-foreground block">
                  {isHi ? "लगभग छाया-मुक्त छत" : "approx 100 sq.ft / kW"}
                </span>
              </div>

              <div className="rounded-xl border border-border bg-card p-3.5">
                <span className="text-[11px] font-medium text-muted-foreground block">
                  {isHi ? "अनुमानित वार्षिक बचत" : "Estimated Yearly Savings"}
                </span>
                <span className="font-display text-2xl font-bold text-success">
                  {formatINR(yearlySavings)}
                </span>
                <span className="text-[10px] text-muted-foreground block">
                  {isHi ? "बिजली बिल में 88% तक कमी" : "up to 88% bill reduction"}
                </span>
              </div>
            </div>

            {/* Subsidy Highlight */}
            <div className="rounded-xl border border-primary/30 bg-primary/10 p-3.5 mb-4">
              <div className="flex justify-between items-center text-xs">
                <span className="font-semibold text-foreground">
                  {isHi
                    ? "पीएम सूर्य घर केंद्रीय सब्सिडी (अधिकतम):"
                    : "PM Surya Ghar Central Subsidy (Up to):"}
                </span>
                <span className="font-bold text-foreground text-sm">
                  {formatINR(centralSubsidy)}
                </span>
              </div>
            </div>

            {/* Payback period */}
            <div className="flex items-center justify-between text-xs text-muted-foreground border-t border-border pt-3 mb-4">
              <span>
                {isHi ? "सब्सिडी के बाद लागत वसूली (Payback):" : "Payback Period (After Subsidy):"}
              </span>
              <span className="font-bold text-foreground">
                {paybackAfterSubsidy} {isHi ? "वर्ष" : "years"}
              </span>
            </div>
          </div>

          <div>
            <p className="text-[11px] text-muted-foreground leading-normal mb-4">
              {t("calculatorDisclaimer")}
            </p>

            <button
              onClick={handleAction}
              className="w-full inline-flex items-center justify-center gap-2 rounded-xl bg-primary py-3 text-sm font-bold text-primary-foreground shadow-sm transition-all hover:bg-primary-hover active:scale-95"
            >
              <span>{t("getExactQuote")}</span>
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
