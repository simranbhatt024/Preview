import React, { useState, useEffect } from "react";
import { useLocale } from "../lib/locale-context";
import { CONTACT_INFO } from "../lib/constants";
import {
  Phone,
  MessageCircle,
  MessageSquare,
  Calendar,
  X,
  Clock,
  SunMedium,
  Send,
} from "lucide-react";

interface FloatingExpertButtonProps {
  onOpenConsultationModal?: () => void;
  onOpenLiveChat?: () => void;
}

export function FloatingExpertButton({
  onOpenConsultationModal,
  onOpenLiveChat,
}: FloatingExpertButtonProps) {
  const { t, isHi } = useLocale();
  const [panelOpen, setPanelOpen] = useState(false);
  const [isAvailableNow, setIsAvailableNow] = useState(true);

  // Compute IST availability: Monday to Saturday, 9 AM to 7 PM
  useEffect(() => {
    try {
      const now = new Date();
      // Format to Asia/Kolkata
      const options: Intl.DateTimeFormatOptions = {
        timeZone: "Asia/Kolkata",
        weekday: "short",
        hour: "numeric",
        hour12: false,
      };
      const formatter = new Intl.DateTimeFormat("en-US", options);
      const parts = formatter.formatToParts(now);
      const weekday = parts.find((p) => p.type === "weekday")?.value || "";
      const hour = parseInt(parts.find((p) => p.type === "hour")?.value || "12", 10);

      const isWeekday = weekday !== "Sun";
      const isWorkingHour = hour >= 9 && hour < 19;
      setIsAvailableNow(isWeekday && isWorkingHour);
    } catch {
      setIsAvailableNow(true);
    }
  }, []);

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end">
      {/* Popover action panel */}
      {panelOpen && (
        <div className="mb-3 w-80 max-w-[calc(100vw-2rem)] rounded-2xl border border-border bg-card p-5 shadow-2xl animate-in slide-in-from-bottom-5">
          <div className="flex items-start justify-between border-b border-border pb-3 mb-3">
            <div>
              <div className="flex items-center gap-2">
                <span
                  className={`h-2.5 w-2.5 rounded-full ${isAvailableNow ? "bg-success" : "bg-primary"} animate-pulse`}
                />
                <span className="text-xs font-bold text-foreground uppercase tracking-wider">
                  {isAvailableNow ? t("expertAvailable") : t("expertLeaveMessage")}
                </span>
              </div>
              <p className="mt-1 text-xs text-muted-foreground leading-normal">
                {t("floatingTitle")}
              </p>
            </div>
            <button
              onClick={() => setPanelOpen(false)}
              className="rounded-full p-1 text-muted-foreground hover:bg-muted hover:text-foreground"
              aria-label="Close expert panel"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          <p className="mb-4 text-xs font-medium text-foreground">{t("floatingOffer")}</p>

          <div className="flex flex-col gap-2">
            {/* 1. Call Now */}
            <a
              href={CONTACT_INFO.phoneTel}
              className="flex items-center gap-3 rounded-xl border border-border bg-background px-3.5 py-2.5 text-xs font-semibold text-foreground transition-colors hover:border-primary hover:text-primary"
            >
              <Phone className="h-4 w-4 text-primary" />
              <span>
                {t("callNow")}: {CONTACT_INFO.phone}
              </span>
            </a>

            {/* 2. Chat on WhatsApp */}
            <a
              href={CONTACT_INFO.whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-3 rounded-xl border border-border bg-background px-3.5 py-2.5 text-xs font-semibold text-foreground transition-colors hover:border-success hover:text-success"
            >
              <MessageCircle className="h-4 w-4 text-success" />
              <span>{t("whatsappChat")}</span>
            </a>

            {/* 3. Send a Message (In-site Chat) */}
            <button
              onClick={() => {
                setPanelOpen(false);
                if (onOpenLiveChat) onOpenLiveChat();
              }}
              className="flex items-center gap-3 rounded-xl border border-border bg-background px-3.5 py-2.5 text-xs font-semibold text-foreground transition-colors hover:border-primary hover:text-primary text-left"
            >
              <MessageSquare className="h-4 w-4 text-primary" />
              <span>{t("sendMessage")}</span>
            </button>

            {/* 4. Book Free Consultation */}
            <button
              onClick={() => {
                setPanelOpen(false);
                if (onOpenConsultationModal) {
                  onOpenConsultationModal();
                } else {
                  window.location.assign("/contact");
                }
              }}
              className="flex items-center justify-center gap-2 rounded-xl bg-primary px-3.5 py-2.5 text-xs font-bold text-primary-foreground shadow-sm transition-all hover:bg-primary-hover"
            >
              <Calendar className="h-4 w-4" />
              <span>{t("bookFreeConsultation")}</span>
            </button>
          </div>
        </div>
      )}

      {/* Main floating trigger button */}
      <button
        onClick={() => setPanelOpen(!panelOpen)}
        className="group relative flex h-14 w-14 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-xl transition-all hover:scale-105 active:scale-95 animate-pulse-ring"
        aria-label="Solar Expert Assistance"
      >
        <SunMedium className="h-7 w-7 transition-transform group-hover:rotate-45" />
        <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-secondary text-[9px] font-bold text-white">
          •
        </span>
      </button>
    </div>
  );
}
