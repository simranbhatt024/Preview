import React, { useState } from "react";
import { BlogPost, BlogFAQItem } from "../lib/blog-types";
import { Plus, Trash2, HelpCircle, ChevronDown, ChevronUp } from "lucide-react";

interface Props {
  faqs?: BlogFAQItem[];
  onChange: (faqs: BlogFAQItem[]) => void;
}

export function RankMathFAQEditor({ faqs = [], onChange }: Props) {
  const [openIdx, setOpenIdx] = useState<number | null>(0);

  const handleAdd = () => {
    const next: BlogFAQItem[] = [
      ...faqs,
      {
        question: "रूफटॉप सोलर से कितनी बिजली बचत होती है?",
        answer: "रूफटॉप सोलर लगाने से बिजली बिल 80% से 90% तक कम हो सकता है।",
      },
    ];
    onChange(next);
    setOpenIdx(next.length - 1);
  };

  const handleUpdate = (idx: number, field: "question" | "answer", val: string) => {
    const next = [...faqs];
    const current = next[idx] || { question: "", answer: "" };
    next[idx] = {
      question: field === "question" ? val : current.question,
      answer: field === "answer" ? val : current.answer,
    };
    onChange(next);
  };

  const handleDelete = (idx: number) => {
    const next = faqs.filter((_, i) => i !== idx);
    onChange(next);
  };

  return (
    <div className="border border-border rounded-xl overflow-hidden bg-background">
      <div className="bg-muted/40 p-3 flex items-center justify-between border-b border-border">
        <div className="flex items-center gap-2">
          <HelpCircle className="h-4 w-4 text-primary" />
          <span className="text-xs font-bold text-foreground">
            Rank Math FAQ Block (Schema Ready)
          </span>
        </div>
        <button
          type="button"
          onClick={handleAdd}
          className="flex items-center gap-1 px-2.5 py-1 bg-primary text-primary-foreground text-[11px] font-bold rounded-lg hover:bg-primary-hover shadow-sm"
        >
          <Plus className="h-3 w-3" />
          <span>+ Add New FAQ</span>
        </button>
      </div>

      <div className="p-3 space-y-3">
        {faqs.length === 0 ? (
          <div className="text-center py-4 text-xs text-muted-foreground border border-dashed border-border rounded-lg">
            कोई FAQ नहीं जोड़ा गया है। Rank Math FAQ Schema जोड़ने के लिए "+ Add New FAQ" पर क्लिक
            करें।
          </div>
        ) : (
          faqs.map((faq, idx) => {
            const isOpen = openIdx === idx;
            return (
              <div
                key={idx}
                className="border border-border/80 rounded-xl overflow-hidden bg-card text-xs shadow-sm"
              >
                <div
                  className="flex items-center justify-between p-3 bg-muted/20 cursor-pointer select-none"
                  onClick={() => setOpenIdx(isOpen ? null : idx)}
                >
                  <span className="font-bold text-foreground truncate max-w-[80%]">
                    #{idx + 1}: {faq.question || "प्रश्‍न दर्ज करें..."}
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDelete(idx);
                      }}
                      className="p-1 text-destructive hover:bg-destructive/10 rounded"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                    {isOpen ? (
                      <ChevronUp className="h-4 w-4 text-muted-foreground" />
                    ) : (
                      <ChevronDown className="h-4 w-4 text-muted-foreground" />
                    )}
                  </div>
                </div>

                {isOpen && (
                  <div className="p-3 space-y-3 border-t border-border/60">
                    <div>
                      <label className="block text-[11px] font-bold text-muted-foreground mb-1">
                        Question (प्रश्‍न):
                      </label>
                      <input
                        type="text"
                        value={faq.question}
                        onChange={(e) => handleUpdate(idx, "question", e.target.value)}
                        placeholder="जैसे: क्या पीएम सूर्य घर योजना में सब्सिडी मिलती है?"
                        className="w-full bg-background border border-border rounded-lg px-3 py-2 text-xs text-foreground focus:outline-none focus:border-primary"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-bold text-muted-foreground mb-1">
                        Answer (उत्तर):
                      </label>
                      <textarea
                        rows={2}
                        value={faq.answer}
                        onChange={(e) => handleUpdate(idx, "answer", e.target.value)}
                        placeholder="विस्तृत उत्तर दर्ज करें..."
                        className="w-full bg-background border border-border rounded-lg px-3 py-2 text-xs text-foreground focus:outline-none focus:border-primary"
                      />
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
