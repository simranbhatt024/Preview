import React, { useState } from "react";
import { Link } from "@tanstack/react-router";
import { useLocale } from "../lib/locale-context";
import { ASSETS, CONTACT_INFO } from "../lib/constants";
import { Phone, Mail, MapPin, Send, ArrowRight, ShieldCheck, Sun, Instagram } from "lucide-react";

export function Footer() {
  const { t, isHi, locale, setLocale } = useLocale();
  const [newsletterEmail, setNewsletterEmail] = useState("");
  const [newsletterSubmitted, setNewsletterSubmitted] = useState(false);

  const handleNewsletter = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail.trim()) return;
    setNewsletterSubmitted(true);
    setNewsletterEmail("");
  };

  return (
    <footer className="bg-secondary text-secondary-foreground pt-16 pb-12 border-t border-border/20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="grid grid-cols-1 gap-12 lg:grid-cols-12">
          {/* Column 1: Brand & Logo Tile */}
          <div className="lg:col-span-4 flex flex-col items-start">
            <div className="rounded-xl bg-card p-3 shadow-md mb-4 border border-border inline-block">
              <img
                src={ASSETS.logo}
                alt="Elios Solar Energy Official Logo"
                className="h-16 w-16 object-contain"
              />
            </div>
            <h3 className="font-display text-2xl font-bold tracking-tight text-white mb-2">
              ELIOS SOLAR ENERGY
            </h3>
            <p className="text-sm text-secondary-foreground/80 leading-relaxed mb-6 max-w-sm">
              {isHi
                ? "बिहार की अग्रणी सोलर ईपीसी कंपनी। आवासीय, हाउसिंग सोसाइटी, कमर्शियल एवं औद्योगिक रूफटॉप सोलर परियोजनाओं के लिए संपूर्ण इंजीनियरिंग, आपूर्ति, इंस्टॉलेशन, सब्सिडी और लोन सुविधा।"
                : "Bihar's premier solar EPC engineering, procurement and installation partner. Delivering turnkey rooftop clean power with end-to-end subsidy and loan assistance."}
            </p>

            <div className="flex flex-col gap-2 text-sm text-secondary-foreground/90">
              <a
                href={CONTACT_INFO.phoneTel}
                className="flex items-center gap-2 hover:text-primary transition-colors"
              >
                <Phone className="h-4 w-4 text-primary" />
                <span>{CONTACT_INFO.phone}</span>
              </a>
              <div className="flex items-center gap-2 text-secondary-foreground/70">
                <MapPin className="h-4 w-4 text-primary" />
                <span>{CONTACT_INFO.state}</span>
              </div>
            </div>

            <a
              href={CONTACT_INFO.instagramUrl}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Follow Elios Solar Energy on Instagram"
              className="mt-2 inline-flex h-10 w-10 items-center justify-center rounded-full border border-border/30 bg-card/40 text-secondary-foreground/90 transition-all hover:border-primary hover:bg-primary hover:text-primary-foreground"
            >
              <Instagram className="h-5 w-5" />
            </a>
          </div>

          {/* Column 2: Quick Links */}
          <div className="lg:col-span-2">
            <h4 className="font-display text-base font-semibold text-white uppercase tracking-wider mb-4">
              {isHi ? "सोलर समाधान" : "Solar Solutions"}
            </h4>
            <ul className="space-y-2.5 text-sm text-secondary-foreground/80">
              <li>
                <Link
                  to="/solar-solutions/residential-homes"
                  className="hover:text-primary transition-colors"
                >
                  {t("residentialHomes")}
                </Link>
              </li>
              <li>
                <Link
                  to="/solar-solutions/housing-society"
                  className="hover:text-primary transition-colors"
                >
                  {t("housingSociety")}
                </Link>
              </li>
              <li>
                <Link
                  to="/solar-solutions/commercial-industrial"
                  className="hover:text-primary transition-colors"
                >
                  {t("commercialIndustrial")}
                </Link>
              </li>
              <li>
                <Link
                  to="/solar-solutions/off-grid"
                  className="hover:text-primary transition-colors"
                >
                  {t("offGridSolar")}
                </Link>
              </li>
              <li>
                <Link to="/products" className="hover:text-primary transition-colors">
                  {t("packages")}
                </Link>
              </li>
            </ul>
          </div>

          {/* Column 3: Company & Programs */}
          <div className="lg:col-span-2">
            <h4 className="font-display text-base font-semibold text-white uppercase tracking-wider mb-4">
              {isHi ? "कंपनी एवं पार्टनर" : "Company & Partners"}
            </h4>
            <ul className="space-y-2.5 text-sm text-secondary-foreground/80">
              <li>
                <Link to="/about" className="hover:text-primary transition-colors">
                  {t("aboutUs")}
                </Link>
              </li>
              <li>
                <Link
                  to="/become-a-partner/referral-program"
                  className="hover:text-primary transition-colors"
                >
                  {t("referralProgram")}
                </Link>
              </li>
              <li>
                <Link
                  to="/become-a-partner/learn-and-earn"
                  className="hover:text-primary transition-colors"
                >
                  {t("learnAndEarn")}
                </Link>
              </li>
              <li>
                <Link
                  to="/become-a-partner/solar-body-program"
                  className="hover:text-primary transition-colors"
                >
                  {t("solarBody")}
                </Link>
              </li>
              <li>
                <Link to="/news" className="hover:text-primary transition-colors">
                  {t("newsBlogs")}
                </Link>
              </li>
              <li>
                <Link to="/testimonials" className="hover:text-primary transition-colors">
                  {isHi ? "ग्राहकों के विचार" : "Testimonials"}
                </Link>
              </li>
            </ul>
          </div>

          {/* Column 4: Newsletter & Tips */}
          <div className="lg:col-span-4">
            <div className="rounded-2xl border border-border/20 bg-card/10 p-6 backdrop-blur-sm">
              <h4 className="font-display text-lg font-bold text-white mb-2 flex items-center gap-2">
                <Sun className="h-5 w-5 text-primary" />
                <span>{isHi ? "सोलर टिप्स ईमेल से प्राप्त करें" : "Get Solar Tips by Email"}</span>
              </h4>
              <p className="text-xs text-secondary-foreground/75 leading-relaxed mb-4">
                {isHi
                  ? "सब्सिडी के नए नियम, बिजली बिल बचत के तरीके और सोलर रख-रखाव संबंधी उपयोगी जानकारी पाएं।"
                  : "Stay updated on PM Surya Ghar subsidies, DISCOM net metering updates, and seasonal solar generation maintenance tips."}
              </p>

              {newsletterSubmitted ? (
                <div className="rounded-lg bg-success/20 border border-success/40 p-3 text-xs text-success-foreground font-medium">
                  {isHi
                    ? "धन्यवाद! आपका ईमेल पंजीकृत हो गया है।"
                    : "Thank you! You are now subscribed to solar updates."}
                </div>
              ) : (
                <form onSubmit={handleNewsletter} className="flex flex-col sm:flex-row gap-2">
                  <input
                    type="email"
                    value={newsletterEmail}
                    onChange={(e) => setNewsletterEmail(e.target.value)}
                    placeholder={isHi ? "आपका ईमेल पता दर्ज करें" : "Enter your email address"}
                    required
                    className="flex-1 rounded-lg border border-border/30 bg-background/20 px-3.5 py-2.5 text-sm text-white placeholder:text-secondary-foreground/50 focus:border-primary focus:outline-none"
                  />
                  <button
                    type="submit"
                    className="inline-flex items-center justify-center gap-1.5 rounded-lg bg-primary px-4 py-2.5 text-xs font-semibold text-primary-foreground hover:bg-primary-hover transition-colors"
                  >
                    <span>{isHi ? "सब्सक्राइब करें" : "Subscribe"}</span>
                    <Send className="h-3.5 w-3.5" />
                  </button>
                </form>
              )}
            </div>

            {/* Language switch button in footer */}
            <div className="mt-6 flex items-center justify-between text-xs text-secondary-foreground/60 border-t border-border/10 pt-4">
              <span>{isHi ? "भाषा चुनें" : "Language preference"}:</span>
              <div className="flex gap-2">
                <button
                  onClick={() => setLocale("en")}
                  className={`px-2 py-1 rounded transition-colors ${locale === "en" ? "bg-primary text-primary-foreground font-semibold" : "hover:text-white"}`}
                >
                  English
                </button>
                <button
                  onClick={() => setLocale("hi")}
                  className={`px-2 py-1 rounded transition-colors ${locale === "hi" ? "bg-primary text-primary-foreground font-semibold" : "hover:text-white"}`}
                >
                  हिन्दी
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Legal Bar */}
        <div className="mt-12 pt-8 border-t border-border/15 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-secondary-foreground/60">
          <div>
            © {new Date().getFullYear()} Elios Solar Energy.{" "}
            {isHi ? "सर्वाधिकार सुरक्षित।" : "All rights reserved."}
          </div>
          <div className="flex items-center gap-6">
            <Link to="/privacy" className="hover:text-primary transition-colors">
              {isHi ? "गोपनीयता नीति" : "Privacy Policy"}
            </Link>
            <Link to="/terms" className="hover:text-primary transition-colors">
              {isHi ? "नियम व शर्तें" : "Terms & Conditions"}
            </Link>
            <Link to="/contact" className="hover:text-primary transition-colors">
              {t("contactUs")}
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
