import React, { useState, useRef } from "react";
import {
  motion,
  useMotionValue,
  useSpring,
  useTransform,
  useReducedMotion,
  AnimatePresence,
} from "framer-motion";
import { useLocale } from "../lib/locale-context";
import { Sun, Battery, Cpu, ShieldCheck } from "lucide-react";

type ElementKey = "panel" | "inverter" | "battery" | "structure";

export function InteractiveRooftop() {
  const { isHi } = useLocale();
  const reduceMotion = useReducedMotion();
  const [activeElement, setActiveElement] = useState<ElementKey>("panel");
  const svgRef = useRef<HTMLDivElement>(null);

  const mouseX = useMotionValue(0.5);
  const mouseY = useMotionValue(0.5);
  const rotateX = useSpring(useTransform(mouseY, [0, 1], [10, -10]), {
    stiffness: 150,
    damping: 20,
  });
  const rotateY = useSpring(useTransform(mouseX, [0, 1], [-14, 14]), {
    stiffness: 150,
    damping: 20,
  });

  const handleMouseMove = (e: React.MouseEvent) => {
    if (reduceMotion) return;
    const rect = e.currentTarget.getBoundingClientRect();
    mouseX.set((e.clientX - rect.left) / rect.width);
    mouseY.set((e.clientY - rect.top) / rect.height);
  };

  const explanations: Record<
    ElementKey,
    { titleEn: string; titleHi: string; descEn: string; descHi: string }
  > = {
    panel: {
      titleEn: "High-Efficiency Photovoltaic Solar Modules",
      titleHi: "उच्च दक्षता वाले फोटोवोल्टिक सोलर पैनल",
      descEn:
        "Captures natural sunlight and directly converts photons into clean Direct Current (DC) electricity all day.",
      descHi:
        "सूर्य के प्रकाश को अवशोषित कर पूरे दिन स्वच्छ डायरेक्ट करंट (DC) बिजली में परिवर्तित करते हैं।",
    },
    inverter: {
      titleEn: "Smart MPPT Grid-Tied Hybrid Inverter",
      titleHi: "स्मार्ट एमपीपीटी ग्रिड-टाइड हाइब्रिड इन्वर्टर",
      descEn:
        "Seamlessly converts DC solar power into usable AC home electricity and synchronizes with the DISCOM grid.",
      descHi:
        "सोलर DC पावर को घरेलू उपयोग योग्य AC बिजली में बदलता है और बिजली ग्रिड से तालमेल बिठाता है।",
    },
    battery: {
      titleEn: "High-Density Energy Storage Bank",
      titleHi: "ऊर्जा भंडारण बैटरी बैंक",
      descEn:
        "Stores surplus daytime solar power to run critical appliances uninterrupted during night hours and power cuts.",
      descHi:
        "दिन में बनी अतिरिक्त सौर ऊर्जा को रात में और बिजली कटौती के दौरान उपयोग के लिए सुरक्षित रखता है।",
    },
    structure: {
      titleEn: "Heavy Hot-Dip Galvanised Mounting System",
      titleHi: "मजबूत गैल्वेनाइज्ड माउंटिंग स्ट्रक्चर",
      descEn:
        "Engineered to withstand 150 km/h wind loads while protecting terrace waterproofing with zero roof leakage.",
      descHi:
        "150 किमी/घंटा तक की तेज आंधी को सहने में सक्षम और छत को बिना नुकसान पहुंचाए वाटरप्रूफ सीलिंग प्रदान करता है।",
    },
  };

  return (
    <div className="w-full rounded-3xl border border-white/50 bg-white/85 backdrop-blur-xl p-6 sm:p-8 shadow-[0_30px_80px_-30px_rgba(11,32,54,0.4)]">
      <div className="flex flex-col md:flex-row gap-10 items-center">
        {/* 3D Tilt Visual — premium golden-hour rooftop scene */}
        <div
          ref={svgRef}
          onMouseMove={handleMouseMove}
          className="w-full md:w-3/5 relative rounded-2xl p-4 sm:p-8 border border-white/60 bg-gradient-to-br from-amber-50 via-white/80 to-sky-50/80 shadow-inner overflow-hidden flex flex-col items-center justify-center"
        >
          {/* ambient glow blobs */}
          <div className="pointer-events-none absolute -top-10 -left-10 h-40 w-40 rounded-full bg-amber-300/30 blur-3xl" />
          <div className="pointer-events-none absolute -bottom-10 -right-10 h-44 w-44 rounded-full bg-sky-300/25 blur-3xl" />

          <motion.div
            className="relative w-full max-w-xl aspect-[4/3] flex items-center justify-center"
            style={{
              rotateX: reduceMotion ? 0 : rotateX,
              rotateY: reduceMotion ? 0 : rotateY,
              transformStyle: "preserve-3d",
              perspective: 900,
            }}
          >
            <svg viewBox="0 0 400 300" className="w-full h-full drop-shadow-2xl">
              <defs>
                {/* Sky gradient — golden hour */}
                <linearGradient id="skyGrad3" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#FDB874" stopOpacity="0.55" />
                  <stop offset="45%" stopColor="#FCE4B8" stopOpacity="0.3" />
                  <stop offset="100%" stopColor="#E8F1F8" stopOpacity="0.1" />
                </linearGradient>
                {/* Sun glow */}
                <radialGradient id="sunGlow3" cx="50%" cy="50%" r="50%">
                  <stop offset="0%" stopColor="#FFD27A" stopOpacity="0.9" />
                  <stop offset="60%" stopColor="#DA9440" stopOpacity="0.4" />
                  <stop offset="100%" stopColor="#DA9440" stopOpacity="0" />
                </radialGradient>
                {/* Panel gradient — deep blue with sheen */}
                <linearGradient id="panelGrad3" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#2563EB" />
                  <stop offset="50%" stopColor="#1E3A8A" />
                  <stop offset="100%" stopColor="#0B2036" />
                </linearGradient>
                <linearGradient id="panelSheen3" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#93C5FD" stopOpacity="0.5" />
                  <stop offset="50%" stopColor="#60A5FA" stopOpacity="0" />
                </linearGradient>
                {/* Roof gradient */}
                <linearGradient id="roofGrad3" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#F0E8D8" />
                  <stop offset="100%" stopColor="#D8CDB8" />
                </linearGradient>
                {/* Energy flow gradient */}
                <linearGradient id="energyFlow3" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#FFD27A" />
                  <stop offset="100%" stopColor="#22C55E" />
                </linearGradient>
              </defs>

              {/* Sky */}
              <rect x="0" y="0" width="400" height="300" fill="url(#skyGrad3)" rx="16" />

              {/* Distant hills */}
              <path
                d="M0 210 Q 80 188 160 200 T 320 196 T 400 206 V 300 H 0 Z"
                fill="#C9D9C8"
                opacity="0.5"
              />
              <path
                d="M0 224 Q 100 206 200 216 T 400 220 V 300 H 0 Z"
                fill="#B5C9B4"
                opacity="0.45"
              />

              {/* Animated sun with rotating rays + glow */}
              <motion.g
                style={{ transformOrigin: "78px 52px" }}
                animate={reduceMotion ? {} : { rotate: 360 }}
                transition={{ duration: 50, repeat: Infinity, ease: "linear" }}
              >
                {/* 9 curved rays */}
                {[...Array(9)].map((_, i) => {
                  const angle = i * 40 * (Math.PI / 180);
                  return (
                    <path
                      key={i}
                      d={`M ${78 + Math.cos(angle) * 30} ${52 + Math.sin(angle) * 30} Q ${78 + Math.cos(angle) * 38} ${52 + Math.sin(angle) * 38} ${78 + Math.cos(angle) * 46} ${52 + Math.sin(angle) * 46}`}
                      stroke="#DA9440"
                      strokeWidth="3.5"
                      strokeLinecap="round"
                      fill="none"
                    />
                  );
                })}
              </motion.g>
              <circle cx="78" cy="52" r="32" fill="url(#sunGlow3)" />
              <circle cx="78" cy="52" r="22" fill="#FFD27A" />
              <circle cx="78" cy="52" r="16" fill="#FFE9B0" />

              {/* Sunlight beams sweeping toward panels */}
              {!reduceMotion && (
                <>
                  <motion.path
                    d="M 78 52 L 150 130"
                    stroke="#FFD27A"
                    strokeWidth="5"
                    strokeLinecap="round"
                    strokeDasharray="8,6"
                    opacity="0.5"
                    animate={{ strokeDashoffset: [0, -28], opacity: [0.3, 0.7, 0.3] }}
                    transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
                  />
                  <motion.path
                    d="M 78 52 L 210 130"
                    stroke="#FFD27A"
                    strokeWidth="4"
                    strokeLinecap="round"
                    strokeDasharray="6,6"
                    opacity="0.4"
                    animate={{ strokeDashoffset: [0, -24], opacity: [0.2, 0.6, 0.2] }}
                    transition={{ duration: 3, repeat: Infinity, ease: "easeInOut", delay: 0.4 }}
                  />
                </>
              )}

              {/* Greenery — trees */}
              <g aria-hidden>
                {/* Left tree */}
                <rect x="44" y="232" width="7" height="26" fill="#6b4f2a" rx="1.5" />
                <motion.circle
                  cx="47"
                  cy="226"
                  r="18"
                  fill="#22c55e"
                  animate={reduceMotion ? {} : { scale: [1, 1.06, 1] }}
                  transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                />
                <circle cx="38" cy="232" r="10" fill="#16a34a" opacity="0.9" />
                <circle cx="56" cy="232" r="9" fill="#4ade80" opacity="0.9" />
                {/* Right tree */}
                <rect x="352" y="232" width="7" height="26" fill="#6b4f2a" rx="1.5" />
                <motion.circle
                  cx="355"
                  cy="226"
                  r="16"
                  fill="#22c55e"
                  animate={reduceMotion ? {} : { scale: [1, 1.06, 1] }}
                  transition={{ duration: 4.5, repeat: Infinity, ease: "easeInOut", delay: 0.6 }}
                />
                <circle cx="346" cy="232" r="9" fill="#16a34a" opacity="0.9" />
                <circle cx="364" cy="232" r="8" fill="#4ade80" opacity="0.9" />
                {/* Ground hedge */}
                <rect x="20" y="286" width="360" height="8" rx="4" fill="#16a34a" opacity="0.5" />
              </g>

              {/* House body */}
              <rect
                x="100"
                y="208"
                width="200"
                height="82"
                fill="#FAF8F5"
                stroke="#3A4457"
                strokeWidth="2.5"
                rx="2"
              />
              {/* Windows */}
              <rect
                x="116"
                y="222"
                width="26"
                height="22"
                fill="#BFE3F5"
                stroke="#3A4457"
                strokeWidth="1.5"
                rx="1"
              />
              <rect x="120" y="226" width="8" height="14" fill="#7BB8E0" opacity="0.6" />
              <rect
                x="258"
                y="222"
                width="26"
                height="22"
                fill="#BFE3F5"
                stroke="#3A4457"
                strokeWidth="1.5"
                rx="1"
              />
              <rect x="262" y="226" width="8" height="14" fill="#7BB8E0" opacity="0.6" />
              {/* Door */}
              <rect
                x="186"
                y="248"
                width="28"
                height="42"
                fill="#DA9440"
                stroke="#3A4457"
                strokeWidth="1.5"
                rx="1"
              />
              <circle cx="207" cy="270" r="2" fill="#3A4457" />

              {/* Roof slab */}
              <polygon
                points="92,208 308,208 296,196 104,196"
                fill="url(#roofGrad3)"
                stroke="#3A4457"
                strokeWidth="2"
              />

              {/* Solar Panel Array — perspective grid of 6 modules */}
              <motion.g
                className="cursor-pointer"
                onClick={() => setActiveElement("panel")}
                animate={activeElement === "panel" ? { scale: [1, 1.05, 1] } : {}}
                transition={{ duration: 0.5 }}
                style={{ transformOrigin: "200px 175px" }}
              >
                {/* Panel frame */}
                <polygon
                  points="120,150 280,150 260,196 140,196"
                  fill="url(#panelGrad3)"
                  stroke={activeElement === "panel" ? "#DA9440" : "#1E40AF"}
                  strokeWidth={activeElement === "panel" ? "3.5" : "2"}
                  strokeLinejoin="round"
                />
                {/* Sheen overlay */}
                <polygon
                  points="120,150 280,150 260,196 140,196"
                  fill="url(#panelSheen3)"
                  opacity="0.6"
                />
                {/* Grid lines — 3 cols x 2 rows */}
                <line
                  x1="160"
                  y1="150"
                  x2="153"
                  y2="196"
                  stroke="#60A5FA"
                  strokeWidth="1.2"
                  opacity="0.7"
                />
                <line
                  x1="200"
                  y1="150"
                  x2="200"
                  y2="196"
                  stroke="#60A5FA"
                  strokeWidth="1.2"
                  opacity="0.7"
                />
                <line
                  x1="240"
                  y1="150"
                  x2="247"
                  y2="196"
                  stroke="#60A5FA"
                  strokeWidth="1.2"
                  opacity="0.7"
                />
                <line
                  x1="120"
                  y1="173"
                  x2="280"
                  y2="173"
                  stroke="#60A5FA"
                  strokeWidth="1.2"
                  opacity="0.7"
                />
                {/* Moving sunlight sheen across panels */}
                {!reduceMotion && (
                  <motion.rect
                    x="120"
                    y="150"
                    width="40"
                    height="46"
                    fill="#FFD27A"
                    opacity="0.25"
                    animate={{ x: [120, 240] }}
                    transition={{
                      duration: 4,
                      repeat: Infinity,
                      ease: "easeInOut",
                      repeatType: "reverse",
                    }}
                  />
                )}
                {/* Active energy pulse */}
                {activeElement === "panel" && !reduceMotion && (
                  <motion.circle
                    cx="200"
                    cy="173"
                    r="4"
                    fill="#22C55E"
                    animate={{ r: [4, 22], opacity: [0.8, 0] }}
                    transition={{ duration: 1.6, repeat: Infinity, ease: "easeOut" }}
                  />
                )}
              </motion.g>

              {/* Panel supports */}
              <line
                x1="140"
                y1="196"
                x2="140"
                y2="206"
                stroke="#0B2036"
                strokeWidth="3"
                strokeLinecap="round"
              />
              <line
                x1="260"
                y1="196"
                x2="260"
                y2="206"
                stroke="#0B2036"
                strokeWidth="3"
                strokeLinecap="round"
              />

              {/* Energy flow line: panel → inverter (animated dashes) */}
              {!reduceMotion && (
                <motion.line
                  x1="200"
                  y1="196"
                  x2="200"
                  y2="232"
                  stroke="url(#energyFlow3)"
                  strokeWidth="3"
                  strokeDasharray="4,4"
                  animate={{ strokeDashoffset: [0, -16] }}
                  transition={{ duration: 0.8, repeat: Infinity, ease: "linear" }}
                />
              )}

              {/* Inverter */}
              <motion.g
                className="cursor-pointer"
                onClick={() => setActiveElement("inverter")}
                animate={activeElement === "inverter" ? { scale: [1, 1.12, 1] } : {}}
                transition={{ duration: 0.4 }}
                style={{ transformOrigin: "200px 248px" }}
              >
                <rect
                  x="184"
                  y="232"
                  width="32"
                  height="44"
                  rx="4"
                  fill={activeElement === "inverter" ? "#DA9440" : "#0B2036"}
                  stroke="#DA9440"
                  strokeWidth="2"
                />
                {/* Display screen */}
                <rect
                  x="190"
                  y="238"
                  width="20"
                  height="12"
                  rx="1.5"
                  fill="#0B2036"
                  opacity="0.8"
                />
                <motion.rect
                  x="193"
                  y="241"
                  width="14"
                  height="6"
                  rx="1"
                  fill="#22C55E"
                  animate={reduceMotion ? {} : { opacity: [1, 0.4, 1] }}
                  transition={{ duration: 1.5, repeat: Infinity }}
                />
                {/* Status LED */}
                <motion.circle
                  cx="200"
                  cy="266"
                  r="2.5"
                  fill="#22C55E"
                  animate={reduceMotion ? {} : { opacity: [1, 0.3, 1] }}
                  transition={{ duration: 1.2, repeat: Infinity }}
                />
              </motion.g>

              {/* Energy flow: inverter → house (animated) */}
              {!reduceMotion && (
                <motion.line
                  x1="200"
                  y1="276"
                  x2="200"
                  y2="290"
                  stroke="url(#energyFlow3)"
                  strokeWidth="3"
                  strokeDasharray="4,4"
                  animate={{ strokeDashoffset: [0, -16] }}
                  transition={{ duration: 0.8, repeat: Infinity, ease: "linear" }}
                />
              )}

              {/* Battery */}
              <motion.g
                className="cursor-pointer"
                onClick={() => setActiveElement("battery")}
                animate={activeElement === "battery" ? { scale: [1, 1.12, 1] } : {}}
                transition={{ duration: 0.4 }}
                style={{ transformOrigin: "318px 254px" }}
              >
                <rect
                  x="300"
                  y="236"
                  width="36"
                  height="40"
                  rx="5"
                  fill={activeElement === "battery" ? "#DA9440" : "#1F2937"}
                  stroke="#DA9440"
                  strokeWidth="2"
                />
                <rect x="312" y="232" width="12" height="5" rx="1.5" fill="#1F2937" />
                {/* Charge level bars */}
                <motion.rect
                  x="306"
                  y="244"
                  width="24"
                  height="6"
                  rx="1"
                  fill="#22C55E"
                  animate={reduceMotion ? {} : { width: [24, 14, 24] }}
                  transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                />
                <rect x="306" y="254" width="24" height="6" rx="1" fill="#22C55E" opacity="0.5" />
                <rect x="306" y="264" width="24" height="6" rx="1" fill="#22C55E" opacity="0.3" />
              </motion.g>

              {/* Flow: inverter → battery */}
              {!reduceMotion && (
                <motion.line
                  x1="216"
                  y1="254"
                  x2="300"
                  y2="254"
                  stroke="url(#energyFlow3)"
                  strokeWidth="2.5"
                  strokeDasharray="4,4"
                  animate={{ strokeDashoffset: [0, -16] }}
                  transition={{ duration: 0.9, repeat: Infinity, ease: "linear" }}
                />
              )}

              {/* Floating energy particles */}
              {!reduceMotion &&
                [...Array(5)].map((_, i) => (
                  <motion.circle
                    key={i}
                    r="2"
                    fill="#FFD27A"
                    initial={{ cx: 78, cy: 52, opacity: 0 }}
                    animate={{
                      cx: [78, 150 + i * 20],
                      cy: [52, 173],
                      opacity: [0, 1, 0],
                    }}
                    transition={{
                      duration: 2.5,
                      repeat: Infinity,
                      delay: i * 0.5,
                      ease: "easeOut",
                    }}
                  />
                ))}
            </svg>
          </motion.div>
          <span className="text-[11px] font-medium text-muted-foreground mt-2 text-center">
            {isHi
              ? "छत के किसी भी घटक पर क्लिक करके जानकारी देखें"
              : "Tap any component on the roof to see how it works"}
          </span>
        </div>

        {/* Controls & Explanations */}
        <div className="w-full md:w-2/5 flex flex-col justify-center">
          <div className="grid grid-cols-2 gap-2 sm:gap-3 mb-6">
            {[
              {
                key: "panel" as ElementKey,
                icon: Sun,
                labelEn: "1. Solar Panels",
                labelHi: "1. सोलर पैनल",
              },
              {
                key: "inverter" as ElementKey,
                icon: Cpu,
                labelEn: "2. Solar Inverter",
                labelHi: "2. सोलर इन्वर्टर",
              },
              {
                key: "battery" as ElementKey,
                icon: Battery,
                labelEn: "3. Battery Bank",
                labelHi: "3. बैटरी स्टोरेज",
              },
              {
                key: "structure" as ElementKey,
                icon: ShieldCheck,
                labelEn: "4. Mounting Frame",
                labelHi: "4. माउंटिंग स्ट्रक्चर",
              },
            ].map((item) => (
              <motion.button
                key={item.key}
                onClick={() => setActiveElement(item.key)}
                whileHover={reduceMotion ? {} : { scale: 1.04 }}
                whileTap={{ scale: 0.97 }}
                className={`flex items-center gap-2 rounded-xl p-3 text-xs font-semibold border transition-all text-left ${
                  activeElement === item.key
                    ? "bg-primary text-primary-foreground border-primary shadow-md shadow-primary/30"
                    : "bg-white/70 backdrop-blur-sm border-white/60 text-foreground hover:bg-white"
                }`}
              >
                <item.icon className="h-4 w-4 shrink-0" />
                <span>{isHi ? item.labelHi : item.labelEn}</span>
              </motion.button>
            ))}
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={activeElement}
              className="rounded-2xl border border-white/60 bg-white/80 backdrop-blur-sm p-5 shadow-sm"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.25 }}
            >
              <h4 className="font-display text-base font-bold text-foreground">
                {isHi ? explanations[activeElement].titleHi : explanations[activeElement].titleEn}
              </h4>
              <p className="mt-2 text-sm text-muted-foreground leading-relaxed">
                {isHi ? explanations[activeElement].descHi : explanations[activeElement].descEn}
              </p>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
