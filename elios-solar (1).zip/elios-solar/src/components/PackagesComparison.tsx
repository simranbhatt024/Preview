import React from "react";
import { useLocale, formatINR } from "../lib/locale-context";
import { INITIAL_PACKAGES } from "../lib/mock-data";
import { Check, Star, ArrowRight } from "lucide-react";

interface PackagesComparisonProps {
  onSelectPackage?: (pkgName: string) => void;
}

export function PackagesComparison({ onSelectPackage }: PackagesComparisonProps) {
  const { isHi, t } = useLocale();

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8 items-stretch">
      {INITIAL_PACKAGES.map((pkg) => {
        const isGold = pkg.isPopular;
        return (
          <div
            key={pkg.slug}
            className={`relative flex flex-col justify-between rounded-3xl border transition-all p-6 sm:p-8 ${
              isGold
                ? "border-primary bg-card shadow-xl ring-2 ring-primary/40 -translate-y-1.5"
                : "border-border bg-card/60 shadow-sm hover:border-primary/50"
            }`}
          >
            {isGold && (
              <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 rounded-full bg-primary px-4 py-1 text-[11px] font-bold uppercase tracking-wider text-primary-foreground shadow-sm flex items-center gap-1">
                <Star className="h-3 w-3 fill-current" />
                <span>{isHi ? "सर्वाधिक लोकप्रिय" : "Most Popular"}</span>
              </div>
            )}

            <div>
              <div className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
                {pkg.tier} CARE
              </div>
              <h3 className="font-display text-xl sm:text-2xl font-bold text-foreground mt-1 mb-2">
                {isHi ? pkg.nameHi : pkg.nameEn}
              </h3>

              <div className="flex items-baseline gap-2 mb-4">
                <span className="font-display text-3xl sm:text-4xl font-extrabold text-foreground">
                  {formatINR(pkg.offerPrice)}
                </span>
                <span className="text-xs text-muted-foreground line-through">
                  {formatINR(pkg.originalPrice)}
                </span>
                <span className="text-xs text-muted-foreground font-medium">/ {t("perYear")}</span>
              </div>

              <div className="rounded-lg bg-background p-2.5 text-[11px] font-medium text-muted-foreground mb-6 border border-border/80">
                {isHi ? "वार्षिक सब्सक्रिप्शन पैकेज" : "Yearly subscription plan"}
              </div>

              <ul className="space-y-3 text-xs sm:text-sm text-foreground mb-8">
                {(isHi ? pkg.featuresHi : pkg.featuresEn).map((feature, idx) => (
                  <li key={idx} className="flex items-start gap-2.5">
                    <Check className="h-4 w-4 text-primary shrink-0 mt-0.5" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <button
                onClick={() =>
                  onSelectPackage
                    ? onSelectPackage(isHi ? pkg.nameHi : pkg.nameEn)
                    : window.location.assign(`/contact?service=${encodeURIComponent(pkg.nameEn)}`)
                }
                className={`w-full inline-flex items-center justify-center gap-2 rounded-xl py-3 text-xs sm:text-sm font-bold transition-all shadow-sm active:scale-95 ${
                  isGold
                    ? "bg-primary text-primary-foreground hover:bg-primary-hover"
                    : "bg-secondary text-secondary-foreground hover:bg-secondary/90"
                }`}
              >
                <span>{t("choosePackage")}</span>
                <ArrowRight className="h-4 w-4" />
              </button>

              <div className="mt-3 text-center">
                <a
                  href="/terms#packages"
                  className="text-[11px] text-muted-foreground hover:text-primary transition-colors underline"
                >
                  {isHi ? "ऑफ़र नियम व शर्तें देखें" : "View Offer Terms"}
                </a>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
