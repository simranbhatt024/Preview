import React, { useState } from "react";
import { BlogPost, RankMathCheck } from "../lib/blog-types";
import { Sparkles, CheckCircle2, AlertCircle, X } from "lucide-react";

interface RankMathProps {
  formData: BlogPost;
  setFormData: React.Dispatch<React.SetStateAction<BlogPost>>;
  seoAnalysis: { score: number; checks: RankMathCheck[] };
}

export function RankMathSEOBox({ formData, setFormData, seoAnalysis }: RankMathProps) {
  const [activeTab, setActiveTab] = useState<"general" | "advanced" | "schema" | "faq" | "social">(
    "general",
  );
  const [snippetModalOpen, setSnippetModalOpen] = useState(false);
  const [snippetMode, setSnippetMode] = useState<"desktop" | "mobile">("desktop");
  const [socialTab, setSocialTab] = useState<"facebook" | "twitter">("facebook");

  return (
    <div className="rounded-2xl border border-border bg-card overflow-hidden shadow-sm">
      {/* Box Header */}
      <div className="flex items-center justify-between border-b border-border bg-muted/40 p-4">
        <div className="flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-primary" />
          <h3 className="font-display font-bold text-base text-foreground">Rank Math SEO</h3>
        </div>

        <div className="flex items-center gap-2">
          <div className="px-3 py-1 rounded-full bg-emerald-500 text-white font-extrabold text-xs shadow-sm">
            Score: {seoAnalysis.score} / 100
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center border-b border-border bg-muted/20 px-4 pt-2 gap-2 text-xs font-bold">
        <button
          type="button"
          onClick={() => setActiveTab("general")}
          className={`px-4 py-2 border-b-2 transition-all ${
            activeTab === "general"
              ? "border-primary text-primary"
              : "border-transparent text-muted-foreground hover:text-foreground"
          }`}
        >
          General
        </button>
        <button
          type="button"
          onClick={() => setActiveTab("advanced")}
          className={`px-4 py-2 border-b-2 transition-all ${
            activeTab === "advanced"
              ? "border-primary text-primary"
              : "border-transparent text-muted-foreground hover:text-foreground"
          }`}
        >
          Advanced
        </button>
        <button
          type="button"
          onClick={() => setActiveTab("schema")}
          className={`px-4 py-2 border-b-2 transition-all ${
            activeTab === "schema"
              ? "border-primary text-primary"
              : "border-transparent text-muted-foreground hover:text-foreground"
          }`}
        >
          Schema
        </button>
        <button
          type="button"
          onClick={() => setActiveTab("faq")}
          className={`px-4 py-2 border-b-2 transition-all ${
            activeTab === "faq"
              ? "border-primary text-primary"
              : "border-transparent text-muted-foreground hover:text-foreground"
          }`}
        >
          FAQ Schema ({(formData.faqs || []).length})
        </button>
        <button
          type="button"
          onClick={() => setActiveTab("social")}
          className={`px-4 py-2 border-b-2 transition-all ${
            activeTab === "social"
              ? "border-primary text-primary"
              : "border-transparent text-muted-foreground hover:text-foreground"
          }`}
        >
          Social
        </button>
      </div>

      {/* Tab Panels */}
      <div className="p-5 space-y-6">
        {activeTab === "general" && (
          <>
            {/* SERP Snippet Preview matching screenshot */}
            <div className="border border-border rounded-xl p-4 bg-background">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold text-muted-foreground uppercase">Preview</span>
                <button
                  type="button"
                  onClick={() => setSnippetModalOpen(true)}
                  className="px-3 py-1 bg-primary text-primary-foreground text-xs font-bold rounded-lg shadow hover:bg-primary-hover"
                >
                  Edit Snippet
                </button>
              </div>

              <div className="p-3 bg-card border border-border/60 rounded-lg text-xs space-y-1">
                <div className="text-blue-600 font-semibold text-base hover:underline truncate">
                  - {formData.seoTitle || formData.titleEn || "Elios Solar Energy"}
                </div>
                <div className="text-emerald-700 font-mono text-[11px]">
                  https://eliossolar.in/news/{formData.slug}
                </div>
                <div className="text-muted-foreground text-xs line-clamp-2">
                  {formData.metaDescription || formData.excerptEn || "Custom meta snippet..."}
                </div>
              </div>
            </div>

            {/* Focus Keyword Input matching screenshot */}
            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="text-xs font-bold text-foreground">Focus Keyword</label>
                <span className="text-xs font-bold text-muted-foreground">
                  {(formData.focusKeyword || "").length} / 100
                </span>
              </div>
              <input
                type="text"
                value={formData.focusKeyword}
                onChange={(e) => setFormData({ ...formData, focusKeyword: e.target.value })}
                placeholder="Example: Rank Math SEO"
                className="w-full bg-background border border-border rounded-xl px-4 py-2.5 text-sm text-foreground focus:outline-none focus:border-primary"
              />
            </div>

            {/* Pillar Content Checkbox */}
            <div className="flex items-center gap-2 p-3 bg-amber-500/10 border border-amber-500/20 rounded-xl text-xs text-foreground">
              <input
                type="checkbox"
                id="pillar"
                checked={formData.isPillarContent}
                onChange={(e) => setFormData({ ...formData, isPillarContent: e.target.checked })}
                className="rounded"
              />
              <label htmlFor="pillar" className="font-semibold cursor-pointer">
                This post is Pillar Content
              </label>
            </div>

            {/* Basic SEO Checklist matching screenshot */}
            <div className="border border-border rounded-xl overflow-hidden bg-background">
              <div className="bg-muted/40 p-3 font-bold text-xs flex items-center justify-between">
                <span className="text-foreground">Basic SEO</span>
                <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px]">
                  {seoAnalysis.checks.filter((c) => c.category === "basic" && c.passed).length} /{" "}
                  {seoAnalysis.checks.filter((c) => c.category === "basic").length} Passed
                </span>
              </div>
              <div className="p-3 space-y-2 text-xs">
                {seoAnalysis.checks
                  .filter((c) => c.category === "basic")
                  .map((check) => (
                    <div key={check.id} className="flex items-center gap-2">
                      {check.passed ? (
                        <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0" />
                      ) : (
                        <AlertCircle className="h-4 w-4 text-rose-500 shrink-0" />
                      )}
                      <span
                        className={
                          check.passed
                            ? "text-muted-foreground line-through"
                            : "text-foreground font-medium"
                        }
                      >
                        {check.label}
                      </span>
                    </div>
                  ))}
              </div>
            </div>

            {/* Additional Checklist */}
            <div className="border border-border rounded-xl overflow-hidden bg-background">
              <div className="bg-muted/40 p-3 font-bold text-xs flex items-center justify-between">
                <span className="text-foreground">Title & Content Readability</span>
                <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px]">
                  Optimal
                </span>
              </div>
              <div className="p-3 space-y-2 text-xs text-foreground/90">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0" />
                  <span>Title Readability: Power word and positive sentiment included</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0" />
                  <span>Content Readability: Short paragraphs and sub-headings structured</span>
                </div>
              </div>
            </div>
          </>
        )}

        {activeTab === "advanced" && (
          <div className="space-y-4 text-xs">
            <div>
              <label className="block font-bold text-foreground mb-1">Robots Meta</label>
              <div className="flex flex-wrap gap-4">
                <label className="flex items-center gap-1.5">
                  <input type="checkbox" defaultChecked className="rounded" />
                  <span>Index</span>
                </label>
                <label className="flex items-center gap-1.5">
                  <input type="checkbox" defaultChecked className="rounded" />
                  <span>Follow</span>
                </label>
                <label className="flex items-center gap-1.5">
                  <input type="checkbox" className="rounded" />
                  <span>No Archive</span>
                </label>
              </div>
            </div>
            <div>
              <label className="block font-bold text-foreground mb-1">Canonical URL</label>
              <input
                type="text"
                placeholder={`https://eliossolar.in/news/${formData.slug}`}
                className="w-full bg-background border border-border rounded-xl p-2.5"
              />
            </div>
          </div>
        )}

        {activeTab === "schema" && (
          <div className="space-y-3 text-xs">
            <label className="block font-bold text-foreground">Schema Type</label>
            <select
              value={formData.schemaType}
              onChange={(e) => setFormData({ ...formData, schemaType: e.target.value })}
              className="w-full bg-background border border-border rounded-xl p-2.5"
            >
              <option value="Article">Article (Standard Blog Post)</option>
              <option value="NewsArticle">NewsArticle (Official Announcement)</option>
              <option value="FAQPage">FAQPage (Question & Answer)</option>
            </select>
          </div>
        )}

        {activeTab === "faq" && (
          <div className="space-y-3 text-xs">
            <p className="text-muted-foreground">
              Rank Math FAQ ब्लॉक द्वारा अपने ब्लॉग पोस्ट में प्रश्न-उत्तर जोड़ें। यह Google Search
              में सीधे रिच FAQ स्निपेट (Rich Snippet) के रूप में दिखाई देगा।
            </p>
            {/* Embedded FAQ editor handled via main post editor */}
          </div>
        )}

        {activeTab === "social" && (
          <div className="space-y-4 text-xs">
            <div>
              <label className="block font-bold text-foreground mb-1">
                Custom Social Share Title
              </label>
              <input
                type="text"
                value={formData.socialShareTitle || ""}
                onChange={(e) => setFormData({ ...formData, socialShareTitle: e.target.value })}
                placeholder="Title when shared on Facebook and Twitter"
                className="w-full bg-background border border-border rounded-xl p-2.5"
              />
            </div>
          </div>
        )}
      </div>

      {/* Snippet Editor Modal matching Screenshot 4 & 5 */}
      {snippetModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm animate-in fade-in-20">
          <div className="relative w-full max-w-xl rounded-2xl border border-border bg-card p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-border pb-3">
              <h3 className="font-display font-bold text-base text-foreground">
                Preview Snippet Editor
              </h3>
              <button
                type="button"
                onClick={() => setSnippetModalOpen(false)}
                className="p-1 rounded-full text-muted-foreground hover:bg-muted"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="flex items-center gap-3 border-b border-border pb-2 text-xs font-bold">
              <button
                type="button"
                onClick={() => setSnippetMode("desktop")}
                className={`px-3 py-1 rounded-lg ${snippetMode === "desktop" ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}
              >
                Desktop Preview
              </button>
              <button
                type="button"
                onClick={() => setSnippetMode("mobile")}
                className={`px-3 py-1 rounded-lg ${snippetMode === "mobile" ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}
              >
                Mobile Preview
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-foreground mb-1">SEO Title</label>
                <input
                  type="text"
                  value={formData.seoTitle || formData.titleEn}
                  onChange={(e) => setFormData({ ...formData, seoTitle: e.target.value })}
                  className="w-full bg-background border border-border rounded-xl p-2.5 text-xs text-foreground"
                />
              </div>

              <div>
                <label className="block font-bold text-foreground mb-1">Permalink / Slug</label>
                <input
                  type="text"
                  value={formData.slug}
                  onChange={(e) => setFormData({ ...formData, slug: e.target.value })}
                  className="w-full bg-background border border-border rounded-xl p-2.5 text-xs font-mono text-foreground"
                />
              </div>

              <div>
                <label className="block font-bold text-foreground mb-1">Meta Description</label>
                <textarea
                  rows={3}
                  value={formData.metaDescription || formData.excerptEn}
                  onChange={(e) => setFormData({ ...formData, metaDescription: e.target.value })}
                  className="w-full bg-background border border-border rounded-xl p-2.5 text-xs text-foreground"
                />
              </div>
            </div>

            <div className="flex justify-end pt-3 border-t border-border">
              <button
                type="button"
                onClick={() => setSnippetModalOpen(false)}
                className="px-5 py-2 bg-primary text-primary-foreground font-bold text-xs rounded-xl shadow"
              >
                Save Snippet
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
