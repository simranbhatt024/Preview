import React, { useState } from "react";
import { UserPlus, ShieldCheck } from "lucide-react";

interface AuthorManagerProps {
  author: string;
  setAuthor: (val: string) => void;
  factChecker: string | undefined;
  setFactChecker: (val: string) => void;
  authorsList: string[];
  setAuthorsList: (list: string[]) => void;
  factCheckersList: string[];
  setFactCheckersList: (list: string[]) => void;
}

export function AuthorManagerBox({
  author,
  setAuthor,
  factChecker,
  setFactChecker,
  authorsList,
  setAuthorsList,
  factCheckersList,
  setFactCheckersList,
}: AuthorManagerProps) {
  const [newAuthorName, setNewAuthorName] = useState("");
  const [showAddAuthor, setShowAddAuthor] = useState(false);
  const [newFactCheckerName, setNewFactCheckerName] = useState("");
  const [showAddFactChecker, setShowAddFactChecker] = useState(false);

  const handleAddAuthor = (e: React.FormEvent) => {
    e.preventDefault();
    const name = newAuthorName.trim();
    if (!name) return;
    if (!authorsList.includes(name)) {
      const updated = [...authorsList, name];
      setAuthorsList(updated);
      try {
        localStorage.setItem("elios_blog_authors", JSON.stringify(updated));
      } catch {}
    }
    setAuthor(name);
    setNewAuthorName("");
    setShowAddAuthor(false);
  };

  const handleAddFactChecker = (e: React.FormEvent) => {
    e.preventDefault();
    const name = newFactCheckerName.trim();
    if (!name) return;
    if (!factCheckersList.includes(name)) {
      const updated = [...factCheckersList, name];
      setFactCheckersList(updated);
      try {
        localStorage.setItem("elios_blog_factcheckers", JSON.stringify(updated));
      } catch {}
    }
    setFactChecker(name);
    setNewFactCheckerName("");
    setShowAddFactChecker(false);
  };

  return (
    <div className="bg-card border border-border rounded-2xl p-5 shadow-sm space-y-4">
      <div className="flex items-center justify-between border-b border-border pb-2">
        <h4 className="font-bold text-sm text-foreground">post_author_name</h4>
        <span className="text-[10px] bg-primary/10 text-primary font-bold px-2 py-0.5 rounded">
          {authorsList.length} Authors
        </span>
      </div>

      <div>
        <div className="flex items-center justify-between mb-1">
          <label className="block text-xs text-muted-foreground font-semibold">written_by</label>
          <button
            type="button"
            onClick={() => setShowAddAuthor(!showAddAuthor)}
            className="text-[11px] text-primary hover:underline font-bold inline-flex items-center gap-1"
          >
            <UserPlus className="h-3 w-3" />
            <span>+ Add Author</span>
          </button>
        </div>

        {showAddAuthor && (
          <div className="mb-2.5 p-2.5 bg-background border border-primary/30 rounded-xl space-y-2">
            <input
              type="text"
              value={newAuthorName}
              onChange={(e) => setNewAuthorName(e.target.value)}
              placeholder="e.g. Er. Manish Sharma"
              className="w-full text-xs p-2 rounded-lg border border-border bg-card text-foreground"
            />
            <div className="flex justify-end gap-1.5">
              <button
                type="button"
                onClick={() => setShowAddAuthor(false)}
                className="px-2 py-1 text-[11px] text-muted-foreground"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleAddAuthor}
                className="px-3 py-1 text-[11px] bg-primary text-primary-foreground font-bold rounded-lg shadow-sm"
              >
                Save
              </button>
            </div>
          </div>
        )}

        <select
          value={author}
          onChange={(e) => setAuthor(e.target.value)}
          className="w-full bg-background border border-border rounded-xl p-2.5 text-xs text-foreground font-medium"
        >
          {authorsList.map((a) => (
            <option key={a} value={a}>
              {a}
            </option>
          ))}
        </select>
      </div>

      <div className="pt-2 border-t border-border/60">
        <div className="flex items-center justify-between mb-1">
          <label className="block text-xs text-muted-foreground font-semibold">
            fact_check_by *
          </label>
          <button
            type="button"
            onClick={() => setShowAddFactChecker(!showAddFactChecker)}
            className="text-[11px] text-primary hover:underline font-bold inline-flex items-center gap-1"
          >
            <ShieldCheck className="h-3 w-3" />
            <span>+ Add Checker</span>
          </button>
        </div>

        {showAddFactChecker && (
          <div className="mb-2.5 p-2.5 bg-background border border-primary/30 rounded-xl space-y-2">
            <input
              type="text"
              value={newFactCheckerName}
              onChange={(e) => setNewFactCheckerName(e.target.value)}
              placeholder="e.g. Er. Priya Sinha (Solar Auditor)"
              className="w-full text-xs p-2 rounded-lg border border-border bg-card text-foreground"
            />
            <div className="flex justify-end gap-1.5">
              <button
                type="button"
                onClick={() => setShowAddFactChecker(false)}
                className="px-2 py-1 text-[11px] text-muted-foreground"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleAddFactChecker}
                className="px-3 py-1 text-[11px] bg-primary text-primary-foreground font-bold rounded-lg shadow-sm"
              >
                Save
              </button>
            </div>
          </div>
        )}

        <select
          value={factChecker}
          onChange={(e) => setFactChecker(e.target.value)}
          className="w-full bg-background border border-border rounded-xl p-2.5 text-xs text-foreground font-medium"
        >
          {factCheckersList.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
      </div>
    </div>
  );
}
