import React, { useState, useEffect } from "react";
import { useLocale } from "../lib/locale-context";
import { X, Send, Bot, User, Check } from "lucide-react";

interface LiveChatWidgetProps {
  isOpen: boolean;
  onClose: () => void;
}

export function LiveChatWidget({ isOpen, onClose }: LiveChatWidgetProps) {
  const { isHi } = useLocale();
  const [messages, setMessages] = useState<
    Array<{ id: string; sender: "bot" | "user"; text: string; time: string }>
  >([
    {
      id: "m1",
      sender: "bot",
      text: isHi
        ? "नमस्ते! एलियोस सोलर में आपका स्वागत है। बिहार में रूफटॉप सोलर, पीएम सूर्य घर सब्सिडी या लोन के संबंध में आप क्या जानकारी चाहते हैं?"
        : "Hello! Welcome to Elios Solar Energy. How can we help you with rooftop solar, PM Surya Ghar subsidy, or solar loans in Bihar today?",
      time: "Just now",
    },
  ]);
  const [inputVal, setInputVal] = useState("");

  if (!isOpen) return null;

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputVal.trim()) return;

    const userText = inputVal;
    const newMsg = {
      id: "u_" + Date.now(),
      sender: "user" as const,
      text: userText,
      time: "Just now",
    };
    setMessages((prev) => [...prev, newMsg]);
    setInputVal("");

    // Simulated responsive EPC bot
    setTimeout(() => {
      let reply = isHi
        ? "धन्यवाद! हमारे सोलर विशेषज्ञ आपकी आवश्यकता देख रहे हैं। मुफ़्त कोटेशन के लिए कृपया अपना फोन नंबर साझा करें या +91 91539 33318 पर कॉल करें।"
        : "Thank you! Our Bihar solar EPC engineers are reviewing your query. For a free site inspection and subsidy estimate, please call +91 91539 33318 or use our Get Free Quotation form.";
      setMessages((prev) => [
        ...prev,
        {
          id: "b_" + Date.now(),
          sender: "bot",
          text: reply,
          time: "Just now",
        },
      ]);
    }, 1000);
  };

  return (
    <div className="fixed bottom-24 right-6 z-50 w-88 max-w-[calc(100vw-2rem)] rounded-2xl border border-border bg-card shadow-2xl overflow-hidden flex flex-col h-[460px] animate-in slide-in-from-bottom-5">
      {/* Header */}
      <div className="bg-secondary p-4 text-secondary-foreground flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="h-9 w-9 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-bold">
            <Bot className="h-5 w-5" />
          </div>
          <div>
            <h4 className="font-display font-bold text-sm text-white">Elios Solar Support</h4>
            <div className="flex items-center gap-1.5 text-xs text-secondary-foreground/80">
              <span className="h-2 w-2 rounded-full bg-success" />
              <span>{isHi ? "सोलर विशेषज्ञ ऑनलाइन" : "Solar Expert Online"}</span>
            </div>
          </div>
        </div>
        <button
          onClick={onClose}
          className="rounded-full p-1.5 text-secondary-foreground/70 hover:bg-white/10 hover:text-white"
        >
          <X className="h-5 w-5" />
        </button>
      </div>

      {/* Messages list */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-background">
        {messages.map((m) => (
          <div
            key={m.id}
            className={`flex flex-col ${m.sender === "user" ? "items-end" : "items-start"}`}
          >
            <div
              className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 text-xs leading-relaxed ${
                m.sender === "user"
                  ? "bg-primary text-primary-foreground font-medium rounded-br-none"
                  : "bg-muted text-foreground border border-border rounded-bl-none"
              }`}
            >
              {m.text}
            </div>
            <span className="text-[10px] text-muted-foreground mt-1 px-1">{m.time}</span>
          </div>
        ))}
      </div>

      {/* Input bar */}
      <form onSubmit={handleSend} className="p-3 bg-card border-t border-border flex gap-2">
        <input
          type="text"
          value={inputVal}
          onChange={(e) => setInputVal(e.target.value)}
          placeholder={isHi ? "संदेश टाइप करें..." : "Type your solar query..."}
          className="flex-1 rounded-xl border border-border bg-background px-3 py-2 text-xs text-foreground focus:border-primary focus:outline-none"
        />
        <button
          type="submit"
          className="rounded-xl bg-primary px-3 py-2 text-primary-foreground hover:bg-primary-hover"
        >
          <Send className="h-4 w-4" />
        </button>
      </form>
    </div>
  );
}
