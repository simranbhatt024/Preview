import React, { useState } from "react";
import { useLocale } from "../lib/locale-context";
import { X, CheckCircle, SunMedium, ShieldAlert } from "lucide-react";
import { submitLeadToCRM } from "../lib/crm-tracking";
import { redirectToWhatsApp } from "../lib/whatsapp";

interface QuoteModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialService?: string;
  initialMessage?: string;
  source?: string;
}

export function QuoteModal({
  isOpen,
  onClose,
  initialService = "Residential Homes",
  initialMessage = "",
  source = "free_quotation",
}: QuoteModalProps) {
  const { t, isHi } = useLocale();
  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [city, setCity] = useState("Patna");
  const [serviceNeeded, setServiceNeeded] = useState(initialService);
  const [message, setMessage] = useState(initialMessage);
  const [submitted, setSubmitted] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg("");

    // Indian phone validation (10 digits starting with 6-9)
    const cleanPhone = phone.replace(/\D/g, "");
    if (!/^[6-9]\d{9}$/.test(cleanPhone)) {
      setErrorMsg(
        isHi
          ? "कृपया 10 अंकों का मान्य भारतीय मोबाइल नंबर दर्ज करें।"
          : "Please enter a valid 10-digit Indian mobile number.",
      );
      return;
    }

    // Save lead locally + push to CRM (non-blocking).
    submitLeadToCRM({
      formId: "elios-quote-modal",
      formName: "Free Quotation / Consultation",
      fullName,
      phone: cleanPhone,
      email,
      city,
      serviceNeeded,
      source,
      message,
    });

    setSubmitted(true);
    // Direct redirect to WhatsApp with pre-filled details.
    const waText = `Hello Elios Solar Energy, I would like to request a quotation:\n\n*Name:* ${fullName}\n*Phone:* ${cleanPhone}\n*City:* ${city}\n*Service Needed:* ${serviceNeeded}${message ? `\n*Details:* ${message}` : ""}`;
    redirectToWhatsApp(waText);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm animate-in fade-in-20">
      <div className="relative w-full max-w-lg rounded-2xl border border-border bg-card p-6 shadow-2xl sm:p-8">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 rounded-full p-1.5 text-muted-foreground hover:bg-muted hover:text-foreground"
        >
          <X className="h-5 w-5" />
        </button>

        {submitted ? (
          <div className="flex flex-col items-center py-8 text-center">
            <CheckCircle className="h-16 w-16 text-success animate-bounce" />
            <h3 className="mt-4 font-display text-2xl font-bold text-foreground">
              {isHi ? "कोटेशन अनुरोध प्राप्त हुआ!" : "Quotation Request Received!"}
            </h3>
            <p className="mt-2 text-sm text-muted-foreground">
              {isHi
                ? "हमारी सोलर इंजीनियरिंग टीम जल्द ही आपसे संपर्क करेगी।"
                : "Our technical solar expert will connect with you shortly."}
            </p>
          </div>
        ) : (
          <div>
            <div className="flex items-center gap-2 text-primary mb-1">
              <SunMedium className="h-5 w-5" />
              <span className="text-xs font-bold uppercase tracking-wider">
                {isHi ? "मुफ़्त छत निरीक्षण एवं कोटेशन" : "Free Rooftop Inspection & Quote"}
              </span>
            </div>
            <h3 className="font-display text-2xl font-bold text-foreground">
              {t("getFreeQuotation")}
            </h3>
            <p className="mt-1 text-xs text-muted-foreground">
              {isHi
                ? "अपनी आवश्यकताएं दर्ज करें। बिना किसी अग्रिम शुल्क के सटीक बचत रिपोर्ट प्राप्त करें।"
                : "Share your roof requirements to receive a customized subsidy & savings estimation."}
            </p>

            {errorMsg && (
              <div className="mt-3 flex items-center gap-2 rounded-lg bg-destructive/10 p-3 text-xs text-destructive">
                <ShieldAlert className="h-4 w-4 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="mt-4 space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-foreground mb-1">
                  {isHi ? "पूरा नाम" : "Full Name"} *
                </label>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder={isHi ? "उदा. राहुल कुमार" : "e.g. Rahul Kumar"}
                  className="w-full rounded-lg border border-border bg-background px-3.5 py-2 text-sm text-foreground focus:border-primary focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div>
                  <label className="block text-xs font-semibold text-foreground mb-1">
                    {isHi ? "मोबाइल नंबर (10 अंक)" : "Phone Number (10 digits)"} *
                  </label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="9876543210"
                    className="w-full rounded-lg border border-border bg-background px-3.5 py-2 text-sm text-foreground focus:border-primary focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-foreground mb-1">
                    {isHi ? "शहर (बिहार)" : "City (Bihar)"} *
                  </label>
                  <select
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    className="w-full rounded-lg border border-border bg-background px-3.5 py-2 text-sm text-foreground focus:border-primary focus:outline-none"
                  >
                    <option value="Patna">Patna (पटना)</option>
                    <option value="Gaya">Gaya (गया)</option>
                    <option value="Muzaffarpur">Muzaffarpur (मुज़फ़्फ़रपुर)</option>
                    <option value="Bhagalpur">Bhagalpur (भागलपुर)</option>
                    <option value="Darbhanga">Darbhanga (दरभंगा)</option>
                    <option value="Purnia">Purnia (पूर्णिया)</option>
                    <option value="Other Bihar City">Other Bihar City</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-foreground mb-1">
                  {isHi ? "ईमेल पता (वैकल्पिक)" : "Email Address (Optional)"}
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full rounded-lg border border-border bg-background px-3.5 py-2 text-sm text-foreground focus:border-primary focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-foreground mb-1">
                  {isHi ? "सेवा की आवश्यकता" : "Service Needed"}
                </label>
                <select
                  value={serviceNeeded}
                  onChange={(e) => setServiceNeeded(e.target.value)}
                  className="w-full rounded-lg border border-border bg-background px-3.5 py-2 text-sm text-foreground focus:border-primary focus:outline-none"
                >
                  <option value="Residential Homes">Residential Homes (आवासीय घर)</option>
                  <option value="Housing Society">Housing Society (हाउसिंग सोसाइटी)</option>
                  <option value="Commercial and Industrial">
                    Commercial & Industrial (फैक्ट्री/कमर्शियल)
                  </option>
                  <option value="Off-Grid Solar">Off-Grid Solar (ऑफ-ग्रिड बैटरी सिस्टम)</option>
                  <option value="Products and Packages">Products & Annual Packages</option>
                  <option value="Partnership">Partnership Enquiry</option>
                  <option value="Other">Other Enquiry</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-foreground mb-1">
                  {isHi ? "छत का विवरण / संदेश" : "Tell us about your rooftop"}
                </label>
                <textarea
                  rows={2}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder={
                    isHi
                      ? "उदा. मासिक बिजली बिल लगभग ₹3,500 है..."
                      : "e.g. Current monthly bill is approx ₹3,500..."
                  }
                  className="w-full rounded-lg border border-border bg-background px-3.5 py-2 text-sm text-foreground focus:border-primary focus:outline-none"
                />
              </div>

              <div className="flex items-center gap-2 pt-1 text-[11px] text-muted-foreground">
                <input
                  type="checkbox"
                  defaultChecked
                  required
                  id="consentModal"
                  className="rounded"
                />
                <label htmlFor="consentModal">
                  {isHi
                    ? "मैं एलियोस सोलर से परामर्श हेतु कॉल/व्हाट्सएप संपर्क के लिए सहमत हूं।"
                    : "I agree to be contacted for solar consultation & savings assessment."}
                </label>
              </div>

              <button
                type="submit"
                className="w-full rounded-lg bg-primary py-2.5 text-sm font-bold text-primary-foreground shadow-md transition-all hover:bg-primary-hover active:scale-95"
              >
                {t("getFreeQuotation")}
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}
