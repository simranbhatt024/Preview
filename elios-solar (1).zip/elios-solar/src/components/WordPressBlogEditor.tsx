import React, { useState, useEffect } from "react";
import { useLocale } from "../lib/locale-context";
import { BlogPost, computeRankMathScore } from "../lib/blog-types";
import { RankMathSEOBox } from "./RankMathSEOBox";
import { AuthorManagerBox } from "./AuthorManagerBox";
import { WYSIWYGContentEditor } from "./WYSIWYGContentEditor";
import { RankMathFAQEditor } from "./RankMathFAQEditor";
import { INITIAL_POSTS } from "../lib/mock-data";
import {
  Plus,
  Edit3,
  Trash2,
  Sparkles,
  X,
  ShieldCheck,
  Upload,
  Image as ImageIcon,
} from "lucide-react";

export function WordPressBlogEditor() {
  const { isHi } = useLocale();
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [activeTab, setActiveTab] = useState<"posts" | "editor">("posts");
  const [editorMode, setEditorMode] = useState<"visual" | "code">("visual");

  const [authorsList, setAuthorsList] = useState<string[]>([
    "Elios Solar Team",
    "Er. Rajesh Kumar",
    "Amit Vikram",
    "Priya Sharma",
  ]);
  const [factCheckersList, setFactCheckersList] = useState<string[]>([
    "Er. Rajesh Kumar (Senior Solar Engineer)",
    "Elios Engineering Board",
    "Dr. S. K. Verma (Energy Auditor)",
  ]);

  const [categories, setCategories] = useState([
    "Solar Basics",
    "PM Surya Ghar",
    "Subsidy & Finance",
    "Installation Tips",
    "Success Stories",
    "Commercial Solar",
  ]);
  const [newCat, setNewCat] = useState("");

  const [formData, setFormData] = useState<BlogPost>({
    id: "",
    slug: "",
    titleEn: "",
    titleHi: "",
    excerptEn: "",
    excerptHi: "",
    contentEn: "",
    contentHi: "",
    postType: "education",
    category: "Solar Basics",
    tags: ["Solar", "PM Surya Ghar", "Bihar"],
    author: "Elios Solar Team",
    authorRole: "Solar Engineers",
    factChecker: "Er. Rajesh Kumar (Senior Solar Engineer)",
    coverImage:
      "https://vibe.filesafe.space/1792820769937918655/assets/176fee8d-679a-4bc7-842d-c24b2c667d29.png",
    published: true,
    publishedAt: new Date().toISOString().split("T")[0] || "2026-10-24",
    readingTime: "4 min read",
    focusKeyword: "rooftop solar bihar",
    seoTitle: "Rooftop Solar in Bihar — Subsidy & Savings Guide | Elios Solar",
    metaDescription:
      "Learn how rooftop solar installation in Bihar cuts electricity bills with up to ₹78,000 PM Surya Ghar subsidy.",
    isPillarContent: false,
    schemaType: "Article",
  });

  useEffect(() => {
    try {
      const storedAuthors = localStorage.getItem("elios_blog_authors");
      if (storedAuthors) setAuthorsList(JSON.parse(storedAuthors));

      const storedFact = localStorage.getItem("elios_blog_factcheckers");
      if (storedFact) setFactCheckersList(JSON.parse(storedFact));

      const stored = localStorage.getItem("elios_blog_posts");
      if (stored) {
        setPosts(JSON.parse(stored));
      } else {
        const initial: BlogPost[] = INITIAL_POSTS.map((p, idx) => ({
          id: "post_" + (idx + 1),
          slug: p.slug,
          titleEn: p.titleEn,
          titleHi: p.titleHi,
          excerptEn: p.excerptEn,
          excerptHi: p.excerptHi,
          contentEn: p.contentEn,
          contentHi: p.contentHi,
          postType: "education",
          category: p.category,
          tags: ["Solar", "Bihar", "EPC"],
          author: p.author,
          authorRole: p.authorRole || "Solar Engineers",
          factChecker: "Er. Rajesh Kumar (Senior Solar Engineer)",
          coverImage: p.coverImage,
          published: true,
          publishedAt: p.publishedAt,
          readingTime: p.readingTime,
          focusKeyword: p.focusKeyword || "rooftop solar bihar",
          seoTitle: p.seoTitle || p.titleEn,
          metaDescription: p.metaDescription || p.excerptEn,
          isPillarContent: idx === 0,
          schemaType: "Article",
        }));
        localStorage.setItem("elios_blog_posts", JSON.stringify(initial));
        setPosts(initial);
      }
    } catch {
      setPosts([]);
    }
  }, []);

  const savePosts = (items: BlogPost[]) => {
    setPosts(items);
    try {
      localStorage.setItem("elios_blog_posts", JSON.stringify(items));
    } catch {}
  };

  const handleCreate = () => {
    const fresh: BlogPost = {
      id: "post_" + Date.now(),
      slug: "rooftop-solar-guide-" + Date.now().toString().slice(-4),
      titleEn: "Complete Rooftop Solar Guide for Bihar Homeowners",
      titleHi: "",
      excerptEn:
        "Explore the process of getting rooftop solar panels with PM Surya Ghar Muft Bijli Yojana subsidy support.",
      excerptHi: "",
      contentEn: `<h2>Why Rooftop Solar is Ideal for Bihar</h2>
<p>Bihar receives bright sunshine for most of the year. With the PM Surya Ghar Muft Bijli Yojana providing direct bank subsidies up to ₹78,000, homeowners can cut their monthly electricity bill down to near zero.</p>
<h3>Step 1: Free Rooftop Feasibility Assessment</h3>
<p>Certified engineers calculate the shadow-free terrace area, tilt angles, and electrical load capacity to maximize generation.</p>`,
      contentHi: "",
      postType: "education",
      category: "Solar Basics",
      tags: ["Solar", "PM Surya Ghar", "Bihar"],
      author: authorsList[0] || "Elios Solar Team",
      authorRole: "Solar Engineers",
      factChecker: factCheckersList[0] || "Er. Rajesh Kumar (Senior Solar Engineer)",
      coverImage:
        "https://vibe.filesafe.space/1792820769937918655/assets/176fee8d-679a-4bc7-842d-c24b2c667d29.png",
      published: true,
      publishedAt: new Date().toISOString().split("T")[0] || "2026-10-24",
      readingTime: "5 min read",
      focusKeyword: "rooftop solar bihar",
      seoTitle: "Rooftop Solar in Bihar — Subsidy & Savings Guide | Elios Solar",
      metaDescription:
        "Install rooftop solar in Bihar with up to ₹78,000 PM Surya Ghar subsidy and 25-year performance warranty.",
      isPillarContent: false,
      schemaType: "Article",
      faqs: [
        {
          question: "How much subsidy is available for rooftop solar in Bihar?",
          answer:
            "Under PM Surya Ghar Muft Bijli Yojana, the central subsidy is ₹30,000 for 1 kW, ₹60,000 for 2 kW, and up to ₹78,000 for 3 kW and above systems.",
        },
      ],
    };
    setFormData(fresh);
    setActiveTab("editor");
    setEditorMode("visual");
  };

  const handleEdit = (p: BlogPost) => {
    setFormData({ ...p });
    setActiveTab("editor");
    setEditorMode("visual");
  };

  const handleDelete = (id: string) => {
    if (confirm("Delete this blog post?")) {
      const updated = posts.filter((p) => p.id !== id);
      savePosts(updated);
      if (formData.id === id) setActiveTab("posts");
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const idx = posts.findIndex((p) => p.id === formData.id);
    let updated: BlogPost[];
    if (idx >= 0) {
      updated = [...posts];
      updated[idx] = formData;
    } else {
      updated = [formData, ...posts];
    }
    savePosts(updated);
    alert(isHi ? "ब्लॉग पोस्ट सफलतापूर्वक सहेजा गया!" : "Blog post successfully published!");
    setActiveTab("posts");
  };

  const seoAnalysis = computeRankMathScore(formData);

  return (
    <div className="w-full bg-[#f0f0f1] text-[#2c3338] min-h-[85vh] p-4 sm:p-6 rounded-2xl">
      {/* Top Bar - Clean WordPress Style with Posts & Add New */}
      <div className="flex flex-wrap items-center justify-between bg-card border border-border p-4 rounded-2xl shadow-sm mb-6 gap-3">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary text-primary-foreground font-black text-lg shadow-sm">
            W
          </div>
          <div>
            <h2 className="font-display text-lg font-bold text-foreground">
              {isHi ? "पोस्ट" : "Posts"}
            </h2>
            <p className="text-xs text-muted-foreground">
              {isHi ? "सभी प्रकाशित और ड्राफ्ट ब्लॉग पोस्ट" : "All published and draft blog posts"}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setActiveTab("posts")}
            className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all ${
              activeTab === "posts"
                ? "bg-secondary text-secondary-foreground shadow-sm font-bold"
                : "bg-background text-muted-foreground hover:bg-muted"
            }`}
          >
            {isHi ? `सभी पोस्ट (${posts.length})` : `All Posts (${posts.length})`}
          </button>
          <button
            type="button"
            onClick={handleCreate}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold bg-primary text-primary-foreground rounded-xl shadow hover:bg-primary-hover transition-all"
          >
            <Plus className="h-4 w-4" />
            <span>{isHi ? "नई पोस्ट जोड़ें" : "Add New Post"}</span>
          </button>
        </div>
      </div>

      {/* ALL POSTS TABLE */}
      {activeTab === "posts" && (
        <div className="bg-card border border-border rounded-2xl p-6 shadow-sm">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-bold text-base text-foreground">Posts Catalog</h3>
            <span className="text-xs text-muted-foreground">{posts.length} Posts</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-border bg-muted/40 text-muted-foreground">
                  <th className="p-3 font-semibold">Title</th>
                  <th className="p-3 font-semibold">Author & Fact-Checker</th>
                  <th className="p-3 font-semibold">Category</th>
                  <th className="p-3 font-semibold">Rank Math Score</th>
                  <th className="p-3 font-semibold">Date</th>
                  <th className="p-3 font-semibold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {posts.map((post) => {
                  const postScore = computeRankMathScore(post).score;
                  return (
                    <tr key={post.id} className="hover:bg-muted/20 transition-colors">
                      <td className="p-3 font-bold text-foreground max-w-xs truncate">
                        <div className="flex items-center gap-2">
                          <img
                            src={post.coverImage}
                            alt=""
                            className="h-8 w-12 rounded object-cover shrink-0 border border-border"
                          />
                          <span className="truncate">
                            {isHi ? post.titleHi || post.titleEn : post.titleEn}
                          </span>
                        </div>
                      </td>
                      <td className="p-3 text-muted-foreground">
                        <div className="font-semibold text-foreground">{post.author}</div>
                        {post.factChecker && (
                          <div className="text-[10px] text-emerald-600 flex items-center gap-1 font-medium">
                            <ShieldCheck className="h-3 w-3 shrink-0" />
                            <span className="truncate max-w-[140px]">{post.factChecker}</span>
                          </div>
                        )}
                      </td>
                      <td className="p-3">
                        <span className="px-2 py-0.5 rounded bg-primary/10 text-primary font-bold text-[10px]">
                          {post.category}
                        </span>
                      </td>
                      <td className="p-3">
                        <div
                          className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full font-bold text-[11px] border ${
                            postScore >= 80
                              ? "bg-emerald-100 text-emerald-800 border-emerald-300"
                              : postScore >= 50
                                ? "bg-amber-100 text-amber-800 border-amber-300"
                                : "bg-rose-100 text-rose-800 border-rose-300"
                          }`}
                        >
                          <Sparkles className="h-3 w-3" />
                          <span>Score: {postScore}/100</span>
                        </div>
                      </td>
                      <td className="p-3 text-muted-foreground">{post.publishedAt}</td>
                      <td className="p-3 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            type="button"
                            onClick={() => handleEdit(post)}
                            className="p-1.5 text-primary hover:bg-primary/10 rounded-lg transition-colors"
                            title="Edit"
                          >
                            <Edit3 className="h-4 w-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDelete(post.id)}
                            className="p-1.5 text-destructive hover:bg-destructive/10 rounded-lg transition-colors"
                            title="Delete"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* WORDPRESS CLASSIC EDITOR VIEW */}
      {activeTab === "editor" && (
        <form onSubmit={handleSubmit} className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Main Left Section */}
          <div className="lg:col-span-8 space-y-6">
            {/* Title Block - English Only */}
            <div className="bg-card border border-border p-4 rounded-2xl shadow-sm">
              <label className="block text-xs font-bold text-muted-foreground uppercase mb-1">
                Post Title (English)
              </label>
              <input
                type="text"
                required
                value={formData.titleEn || ""}
                onChange={(e) => setFormData({ ...formData, titleEn: e.target.value })}
                placeholder="Enter the blog post title here..."
                className="w-full text-xl sm:text-2xl font-bold bg-background border border-border rounded-xl px-4 py-3 text-foreground focus:outline-none focus:border-primary"
              />
            </div>

            {/* WYSIWYG Content Editor Module */}
            <WYSIWYGContentEditor
              value={formData.contentEn || ""}
              onChange={(html) => setFormData((prev) => ({ ...prev, contentEn: html }))}
              editorMode={editorMode}
              setEditorMode={setEditorMode}
            />

            {/* Rank Math FAQ Block */}
            <div className="bg-card border border-border p-4 rounded-2xl shadow-sm">
              <RankMathFAQEditor
                faqs={formData.faqs || []}
                onChange={(faqs) => setFormData((prev) => ({ ...prev, faqs }))}
              />
            </div>

            {/* Rank Math SEO Box Component */}
            <RankMathSEOBox
              formData={formData}
              setFormData={setFormData}
              seoAnalysis={seoAnalysis}
            />
          </div>

          {/* Right Sidebar Widgets */}
          <div className="lg:col-span-4 space-y-6">
            {/* Publish Box */}
            <div className="bg-card border border-border rounded-2xl p-5 shadow-sm space-y-4">
              <div className="flex items-center justify-between border-b border-border pb-3">
                <h4 className="font-bold text-sm text-foreground">Publish</h4>
                <span className="text-xs px-2 py-0.5 rounded bg-primary/10 text-primary font-bold">
                  {formData.published ? "Live" : "Draft"}
                </span>
              </div>

              <div className="space-y-2 text-xs text-muted-foreground">
                <div className="flex items-center justify-between">
                  <span>Status:</span>
                  <span className="font-bold text-foreground">
                    {formData.published ? "Published" : "Draft"}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Visibility:</span>
                  <span className="font-bold text-foreground">Public</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Publish Date:</span>
                  <span className="font-bold text-foreground">{formData.publishedAt}</span>
                </div>
              </div>

              <div className="pt-2 border-t border-border flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, published: !formData.published })}
                  className="px-3 py-2 border border-border rounded-xl text-xs font-semibold hover:bg-muted"
                >
                  {formData.published ? "Save Draft" : "Mark Ready"}
                </button>

                <button
                  type="submit"
                  className="px-5 py-2 bg-primary text-primary-foreground text-xs font-bold rounded-xl shadow hover:bg-primary-hover transition-all"
                >
                  Publish Post
                </button>
              </div>
            </div>

            {/* Modular Author & Fact Checker Box */}
            <AuthorManagerBox
              author={formData.author}
              setAuthor={(val) => setFormData((prev) => ({ ...prev, author: val }))}
              factChecker={formData.factChecker}
              setFactChecker={(val) => setFormData((prev) => ({ ...prev, factChecker: val }))}
              authorsList={authorsList}
              setAuthorsList={setAuthorsList}
              factCheckersList={factCheckersList}
              setFactCheckersList={setFactCheckersList}
            />

            {/* Featured Image Box matching WordPress & user screenshot */}
            <div className="bg-card border border-border rounded-2xl p-5 shadow-sm space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-sm text-foreground">Featured image</h4>
                {formData.coverImage && (
                  <span className="text-[10px] text-emerald-600 font-bold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    Image Set
                  </span>
                )}
              </div>

              {formData.coverImage ? (
                <div className="space-y-3">
                  <div className="relative aspect-[16/10] rounded-xl overflow-hidden border border-border group bg-muted">
                    <img src={formData.coverImage} alt="" className="w-full h-full object-cover" />
                    <button
                      type="button"
                      onClick={() => setFormData({ ...formData, coverImage: "" })}
                      className="absolute top-2 right-2 p-1.5 rounded-full bg-black/70 text-white hover:bg-destructive transition-colors shadow"
                      title="Remove image"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      const url = prompt(
                        "Enter new image URL (or upload):",
                        formData.coverImage || "",
                      );
                      if (url && url.trim()) {
                        setFormData({ ...formData, coverImage: url.trim() });
                      }
                    }}
                    className="w-full text-center text-xs text-primary font-bold hover:underline py-1"
                  >
                    Replace featured image
                  </button>
                </div>
              ) : (
                <div className="space-y-2">
                  <label className="block w-full border-2 border-dashed border-border rounded-xl p-6 text-center cursor-pointer hover:bg-muted/30 transition-all group">
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          const reader = new FileReader();
                          reader.onload = (ev) => {
                            const res = ev.target?.result as string;
                            if (res) {
                              setFormData({ ...formData, coverImage: res });
                            }
                          };
                          reader.readAsDataURL(file);
                        }
                      }}
                    />
                    <div className="flex flex-col items-center justify-center gap-1.5">
                      <ImageIcon className="h-6 w-6 text-primary group-hover:scale-110 transition-transform" />
                      <span className="text-xs font-bold text-primary">Set featured image</span>
                      <span className="text-[10px] text-muted-foreground">
                        Click to upload or drag & drop image
                      </span>
                    </div>
                  </label>

                  <div className="flex items-center gap-2 pt-1">
                    <input
                      type="text"
                      placeholder="Or paste image URL..."
                      className="flex-1 bg-background border border-border rounded-lg px-2.5 py-1.5 text-xs text-foreground focus:outline-none focus:border-primary"
                      onKeyDown={(e) => {
                        if (e.key === "Enter") {
                          e.preventDefault();
                          const val = (e.target as HTMLInputElement).value;
                          if (val.trim()) {
                            setFormData({ ...formData, coverImage: val.trim() });
                          }
                        }
                      }}
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Categories Box */}
            <div className="bg-card border border-border rounded-2xl p-5 shadow-sm space-y-3">
              <h4 className="font-bold text-sm text-foreground">Categories</h4>
              <div className="max-h-40 overflow-y-auto space-y-2 border border-border/60 p-3 rounded-xl bg-background text-xs">
                {categories.map((cat) => (
                  <label key={cat} className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      name="cat"
                      checked={formData.category === cat}
                      onChange={() => setFormData({ ...formData, category: cat })}
                      className="rounded text-primary"
                    />
                    <span className="text-foreground">{cat}</span>
                  </label>
                ))}
              </div>

              <div className="flex gap-2 pt-2">
                <input
                  type="text"
                  value={newCat}
                  onChange={(e) => setNewCat(e.target.value)}
                  placeholder="+ Add Category"
                  className="flex-1 bg-background border border-border rounded-lg px-3 py-1.5 text-xs text-foreground"
                />
                <button
                  type="button"
                  onClick={() => {
                    if (newCat.trim()) {
                      setCategories([...categories, newCat.trim()]);
                      setFormData({ ...formData, category: newCat.trim() });
                      setNewCat("");
                    }
                  }}
                  className="px-3 py-1.5 bg-secondary text-secondary-foreground font-bold text-xs rounded-lg"
                >
                  Add
                </button>
              </div>
            </div>
          </div>
        </form>
      )}
    </div>
  );
}
