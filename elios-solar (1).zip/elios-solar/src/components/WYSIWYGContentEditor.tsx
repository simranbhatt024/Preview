import React, { useRef, useEffect } from "react";
import { Bold, Italic, List, ListOrdered, Quote, Link2 } from "lucide-react";

interface WYSIWYGProps {
  value: string;
  onChange: (html: string) => void;
  editorMode: "visual" | "code";
  setEditorMode: (mode: "visual" | "code") => void;
}

export function WYSIWYGContentEditor({ value, onChange, editorMode, setEditorMode }: WYSIWYGProps) {
  const visualRef = useRef<HTMLDivElement>(null);

  // Sync value to editable element on mount or mode switch
  useEffect(() => {
    if (editorMode === "visual" && visualRef.current) {
      if (visualRef.current.innerHTML !== value) {
        visualRef.current.innerHTML = value || "";
      }
    }
  }, [editorMode]);

  const execCmd = (cmd: string, val: string | undefined = undefined) => {
    if (editorMode !== "visual") return;
    document.execCommand(cmd, false, val);
    if (visualRef.current) {
      onChange(visualRef.current.innerHTML);
    }
  };

  const wordCount = (value || "")
    .replace(/<[^>]*>/g, " ")
    .split(/\s+/)
    .filter(Boolean).length;

  return (
    <div className="bg-card border border-border rounded-2xl overflow-hidden shadow-sm">
      <div className="flex items-center justify-between border-b border-border bg-muted/40 px-4 py-2">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => {
              setEditorMode("visual");
            }}
            className={`px-3 py-1 text-xs font-semibold rounded-lg transition-all ${
              editorMode === "visual"
                ? "bg-background text-foreground shadow-sm font-bold"
                : "text-muted-foreground hover:bg-muted"
            }`}
          >
            Visual (Rich Text)
          </button>
          <button
            type="button"
            onClick={() => {
              if (visualRef.current) {
                onChange(visualRef.current.innerHTML);
              }
              setEditorMode("code");
            }}
            className={`px-3 py-1 text-xs font-semibold rounded-lg transition-all ${
              editorMode === "code"
                ? "bg-background text-foreground shadow-sm font-bold"
                : "text-muted-foreground hover:bg-muted"
            }`}
          >
            Text / HTML
          </button>
        </div>

        <div className="text-xs text-muted-foreground font-mono">Word count: {wordCount}</div>
      </div>

      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-1.5 border-b border-border p-2 bg-background/50 text-foreground text-xs font-medium">
        <button
          type="button"
          onClick={() => execCmd("formatBlock", "<h2>")}
          className="px-2 py-1 hover:bg-muted rounded font-bold text-xs border border-border/60"
        >
          H2
        </button>
        <button
          type="button"
          onClick={() => execCmd("formatBlock", "<h3>")}
          className="px-2 py-1 hover:bg-muted rounded font-bold text-xs border border-border/60"
        >
          H3
        </button>
        <button
          type="button"
          onClick={() => execCmd("formatBlock", "<p>")}
          className="px-2 py-1 hover:bg-muted rounded text-xs border border-border/60"
        >
          Paragraph
        </button>

        <div className="h-4 w-px bg-border mx-1" />

        <button
          type="button"
          onClick={() => execCmd("bold")}
          className="p-1.5 hover:bg-muted rounded border border-border/40"
          title="Bold (Ctrl+B)"
        >
          <Bold className="h-3.5 w-3.5" />
        </button>
        <button
          type="button"
          onClick={() => execCmd("italic")}
          className="p-1.5 hover:bg-muted rounded border border-border/40"
          title="Italic (Ctrl+I)"
        >
          <Italic className="h-3.5 w-3.5" />
        </button>
        <button
          type="button"
          onClick={() => execCmd("insertUnorderedList")}
          className="p-1.5 hover:bg-muted rounded border border-border/40"
          title="Bullet list"
        >
          <List className="h-3.5 w-3.5" />
        </button>
        <button
          type="button"
          onClick={() => execCmd("insertOrderedList")}
          className="p-1.5 hover:bg-muted rounded border border-border/40"
          title="Numbered list"
        >
          <ListOrdered className="h-3.5 w-3.5" />
        </button>
        <button
          type="button"
          onClick={() => execCmd("formatBlock", "<blockquote>")}
          className="p-1.5 hover:bg-muted rounded border border-border/40"
          title="Quote"
        >
          <Quote className="h-3.5 w-3.5" />
        </button>
        <button
          type="button"
          onClick={() => {
            const url = prompt("Enter link URL:");
            if (url) execCmd("createLink", url);
          }}
          className="p-1.5 hover:bg-muted rounded text-primary border border-border/40"
          title="Insert Link"
        >
          <Link2 className="h-3.5 w-3.5" />
        </button>
      </div>

      {/* Editor Surface */}
      <div className="p-4">
        {editorMode === "visual" ? (
          <div
            ref={visualRef}
            contentEditable
            suppressContentEditableWarning
            onInput={(e) => onChange((e.target as HTMLDivElement).innerHTML)}
            onBlur={(e) => onChange((e.target as HTMLDivElement).innerHTML)}
            className="min-h-[260px] max-h-[500px] overflow-y-auto w-full bg-background border border-border rounded-xl p-5 text-sm text-foreground focus:outline-none focus:border-primary leading-relaxed font-sans prose prose-sm max-w-none prose-headings:font-bold prose-headings:text-foreground prose-p:text-foreground/90 prose-p:my-2 prose-h2:text-xl prose-h3:text-lg prose-ul:list-disc prose-ul:pl-5"
          />
        ) : (
          <textarea
            rows={12}
            value={value}
            onChange={(e) => onChange(e.target.value)}
            className="w-full bg-slate-950 border border-border rounded-xl p-4 text-xs text-emerald-400 font-mono focus:outline-none focus:border-primary leading-relaxed"
          />
        )}
      </div>
    </div>
  );
}
