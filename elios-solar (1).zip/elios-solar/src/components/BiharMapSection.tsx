import React, { useState } from "react";
import { useLocale } from "../lib/locale-context";
import { MapPin, Phone, Calendar, Sun, CheckCircle2, Building2, ShieldCheck } from "lucide-react";
import {
  BIHAR_DISTRICTS,
  filterDistricts,
  REGION_OPTIONS,
  type DistrictInfo,
  type RegionFilter,
} from "../lib/bihar-districts";

interface BiharMapSectionProps {
  onBookInspection?: (cityName: string) => void;
}

export function BiharMapSection({ onBookInspection }: BiharMapSectionProps) {
  const { isHi } = useLocale();
  const [selectedDistrict, setSelectedDistrict] = useState<DistrictInfo>(BIHAR_DISTRICTS[0]!);
  const [filterRegion, setFilterRegion] = useState<RegionFilter>("all");

  const filteredDistricts = filterDistricts(filterRegion);

  const handleRegionChange = (r: RegionFilter) => {
    setFilterRegion(r);
    const list = filterDistricts(r);
    if (list.length > 0 && !list.some((d) => d.id === selectedDistrict.id)) {
      setSelectedDistrict(list[0]!);
    }
  };

  const regionLabel = (r: RegionFilter) => {
    if (r === "all") return isHi ? "सभी" : "All";
    if (r === "north") return isHi ? "उत्तर बिहार" : "North";
    if (r === "south") return isHi ? "दक्षिण बिहार" : "South";
    if (r === "central") return isHi ? "मध्य बिहार" : "Central";
    return isHi ? "पूर्वी बिहार" : "East";
  };

  return (
    <div className="w-full rounded-3xl border border-border bg-gradient-to-b from-card via-card to-secondary/5 p-4 sm:p-8 lg:p-10 shadow-lg">
      <div className="flex flex-col lg:flex-row gap-8 lg:gap-10 items-stretch">
        {/* Left: Authentic Bihar District Map Visual matching user's image exactly */}
        <div className="w-full lg:w-7/12 flex flex-col justify-between rounded-2xl border border-blue-900/30 bg-gradient-to-br from-[#0c2b48] via-[#10385e] to-[#081e33] text-white p-5 sm:p-7 overflow-hidden shadow-xl relative">
          {/* Header on top of map container */}
          <div className="relative z-10 flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-white/10">
            <div className="flex items-center gap-2.5">
              <div className="h-9 w-9 rounded-xl bg-[#2980b9] text-white flex items-center justify-center font-bold shadow-md shadow-blue-500/20">
                <Sun className="h-5 w-5 text-amber-300" />
              </div>
              <div>
                <h3 className="text-sm sm:text-base font-bold text-white tracking-wide">
                  {isHi ? "बिहार रूफटॉप सोलर सेवा मानचित्र" : "Bihar Rooftop Solar EPC Map"}
                </h3>
                <span className="text-[11px] text-sky-200/80">
                  {isHi ? "सभी जिलों में ऑन-साइट इंस्टॉलेशन" : "Active Field Installation Teams"}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-400/40 text-[11px] font-semibold text-emerald-300 shadow-sm">
              <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>{isHi ? "38 जिले कवर्ड" : "All 38 Districts Covered"}</span>
            </div>
          </div>

          {/* District Map Graphic Canvas matching the blue district map in user's image */}
          <div className="relative z-10 my-4 w-full aspect-[4/3] sm:aspect-[16/11] max-h-[460px] rounded-2xl overflow-hidden bg-[#18395e]/80 border border-sky-400/30 p-2 sm:p-3 flex items-center justify-center shadow-inner">
            {/* Visual Bihar Map Image from user reference as true geographic background */}
            <div className="absolute inset-0 p-2 flex items-center justify-center pointer-events-none opacity-90">
              <img
                src="https://vibe.filesafe.space/1792820769937918655/attachments/2caa65e7-13fb-4501-b1fe-2813d9a448df.png"
                alt="Bihar Solar EPC Map"
                className="w-full h-full object-contain filter drop-shadow-[0_8px_20px_rgba(0,0,0,0.6)]"
              />
            </div>

            {/* Interactive Overlay with Clickable District Pulse Points */}
            <div className="relative w-full h-full">
              {filteredDistricts.map((d) => {
                const isSelected = selectedDistrict.id === d.id;
                const isHub = d.tier === "hub";

                return (
                  <button
                    key={d.id}
                    type="button"
                    onClick={() => setSelectedDistrict(d)}
                    style={{ left: `${d.coords.x}%`, top: `${d.coords.y}%` }}
                    className="absolute -translate-x-1/2 -translate-y-1/2 transition-transform duration-200 z-20 group focus:outline-none"
                    title={`${d.nameEn} - Click to view details`}
                  >
                    {/* Ring for active selection */}
                    {isSelected && (
                      <span className="absolute -inset-2.5 rounded-full border-2 border-amber-400 animate-ping opacity-75" />
                    )}

                    {/* Node Circle */}
                    <span
                      className={`flex items-center justify-center rounded-full transition-all shadow-lg ${
                        isSelected
                          ? "h-6 w-6 bg-amber-400 text-slate-900 ring-4 ring-amber-300/40 scale-125"
                          : isHub
                            ? "h-4 w-4 bg-sky-200 text-slate-900 border-2 border-white hover:scale-125"
                            : "h-3 w-3 bg-white/90 border border-sky-600 hover:scale-125 hover:bg-amber-300"
                      }`}
                    >
                      {isSelected && <span className="h-2 w-2 rounded-full bg-slate-950" />}
                    </span>

                    {/* Popover Badge for Hubs and Selected item */}
                    {(isHub || isSelected) && (
                      <span
                        className={`absolute left-1/2 -top-6 -translate-x-1/2 whitespace-nowrap px-2 py-0.5 rounded text-[10px] font-bold tracking-tight shadow-md transition-all ${
                          isSelected
                            ? "bg-amber-400 text-slate-950 scale-105 z-30 ring-1 ring-white"
                            : "bg-[#0b2036]/90 text-white border border-sky-300/40 group-hover:bg-amber-400 group-hover:text-slate-950"
                        }`}
                      >
                        {isHi ? d.nameHi : d.nameEn}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* District Quick Filter Bar */}
          <div className="relative z-10 pt-2 border-t border-white/10 flex flex-wrap items-center justify-between gap-2 text-xs">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-[11px] text-sky-200/70 font-semibold mr-1">
                {isHi ? "क्षेत्र:" : "Region:"}
              </span>
              {REGION_OPTIONS.map((r) => (
                <button
                  key={r}
                  type="button"
                  onClick={() => handleRegionChange(r)}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all ${
                    filterRegion === r
                      ? "bg-amber-400 text-slate-950 shadow font-bold"
                      : "bg-white/10 text-white/80 hover:bg-white/20"
                  }`}
                >
                  {regionLabel(r)}
                </button>
              ))}
            </div>

            <div className="text-[11px] text-amber-300 font-medium">
              ★ {isHi ? "क्लिक करके जिला चुनें" : "Tap any point to inspect"}
            </div>
          </div>
        </div>

        {/* Right: Selected District Details, EPC Facility & Free Inspection CTA */}
        <div className="w-full lg:w-5/12 flex flex-col justify-between">
          <div>
            <div className="mb-4">
              <label className="block text-xs font-bold uppercase tracking-wider text-primary mb-1.5">
                {isHi ? "चयनित जिला एवं सौर कार्यालय" : "Selected Bihar District & Solar Hub"}
              </label>

              {/* District Dropdown */}
              <div className="flex items-center gap-2 p-1.5 rounded-2xl border border-border bg-background">
                <MapPin className="h-5 w-5 text-primary ml-2 shrink-0" />
                <select
                  value={selectedDistrict.id}
                  onChange={(e) => {
                    const dist = filteredDistricts.find((d) => d.id === e.target.value);
                    if (dist) setSelectedDistrict(dist);
                  }}
                  className="w-full bg-transparent py-1.5 pr-3 text-sm font-bold text-foreground focus:outline-none"
                >
                  {filteredDistricts.map((d) => (
                    <option key={d.id} value={d.id}>
                      {isHi ? d.nameHi : d.nameEn} — {d.addressEn}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* District Hub Card */}
            <div className="rounded-2xl border border-border bg-card p-6 shadow-sm mb-6">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2.5">
                  <div className="h-10 w-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center font-bold">
                    <Building2 className="h-5 w-5" />
                  </div>
                  <div>
                    <h4 className="font-display text-xl font-bold text-foreground">
                      {isHi
                        ? `${selectedDistrict.nameHi} सौर केंद्र`
                        : `${selectedDistrict.nameEn} Solar Center`}
                    </h4>
                    <span className="text-xs text-muted-foreground font-medium">
                      {isHi ? selectedDistrict.statusTextHi : selectedDistrict.statusTextEn}
                    </span>
                  </div>
                </div>

                <span className="px-2.5 py-1 rounded-full bg-success/10 text-success text-[11px] font-bold">
                  {selectedDistrict.installationCount}
                </span>
              </div>

              <div className="space-y-3 pt-3 border-t border-border/60 text-xs">
                <div>
                  <span className="font-semibold text-muted-foreground block mb-0.5">
                    {isHi ? "कार्यालय / सेवा केंद्र का पता" : "Office / Field Service Center"}:
                  </span>
                  <p className="text-foreground font-semibold text-sm">
                    {isHi ? selectedDistrict.addressHi : selectedDistrict.addressEn}
                  </p>
                </div>

                <div className="flex items-center justify-between pt-1">
                  <div>
                    <span className="font-semibold text-muted-foreground block mb-0.5">
                      {isHi ? "ईपीसी हेल्पलाइन" : "Solar EPC Helpline"}:
                    </span>
                    <a
                      href={`tel:${selectedDistrict.phone.replace(/\s+/g, "")}`}
                      className="font-bold text-primary text-sm hover:underline"
                    >
                      {selectedDistrict.phone}
                    </a>
                  </div>

                  <div className="text-right">
                    <span className="font-semibold text-muted-foreground block mb-0.5">
                      {isHi ? "निरीक्षण समय" : "Site Visit Time"}:
                    </span>
                    <span className="text-foreground font-bold text-xs bg-primary/10 px-2 py-0.5 rounded text-primary">
                      24 - 48 Hours
                    </span>
                  </div>
                </div>
              </div>

              {/* What Elios engineers provide in this district */}
              <div className="mt-4 pt-3 border-t border-border/60 space-y-2">
                <div className="flex items-center gap-2 text-xs text-foreground/90">
                  <CheckCircle2 className="h-4 w-4 text-success shrink-0" />
                  <span>
                    {isHi
                      ? "मुफ़्त 3D छाया एवं रूफटॉप लोड विश्लेषण"
                      : "Free 3D roof shadow analysis & structural assessment"}
                  </span>
                </div>
                <div className="flex items-center gap-2 text-xs text-foreground/90">
                  <CheckCircle2 className="h-4 w-4 text-success shrink-0" />
                  <span>
                    {isHi
                      ? "NBPDCL / SBPDCL बायो-डायरेक्शनल नेट-मीटरिंग दस्तावेज़ीकरण"
                      : "NBPDCL / SBPDCL bi-directional net-metering liaison"}
                  </span>
                </div>
                <div className="flex items-center gap-2 text-xs text-foreground/90">
                  <ShieldCheck className="h-4 w-4 text-primary shrink-0" />
                  <span>
                    {isHi
                      ? "पीएम सूर्य घर सब्सिडी (अधिकतम ₹78,000) संपूर्ण सहायता"
                      : "PM Surya Ghar subsidy (up to ₹78,000) turnkey claim support"}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Action CTAs */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <a
              href={`tel:${selectedDistrict.phone.replace(/\s+/g, "")}`}
              className="inline-flex items-center justify-center gap-2 rounded-xl border border-border bg-card px-4 py-3 text-xs sm:text-sm font-semibold text-foreground hover:border-primary hover:text-primary transition-all"
            >
              <Phone className="h-4 w-4 text-primary" />
              <span>{isHi ? "कार्यालय कॉल करें" : "Call Office"}</span>
            </a>

            <button
              type="button"
              onClick={() => {
                const districtName = isHi ? selectedDistrict.nameHi : selectedDistrict.nameEn;
                if (onBookInspection) {
                  onBookInspection(districtName);
                } else {
                  // Direct to WhatsApp
                  const waText = encodeURIComponent(
                    `Hello Elios Solar Energy, I would like to book a Free Rooftop Solar Inspection in ${selectedDistrict.nameEn}, Bihar.`,
                  );
                  window.location.href = `https://wa.me/919153933318?text=${waText}`;
                }
              }}
              className="inline-flex items-center justify-center gap-2 rounded-xl bg-primary px-4 py-3 text-xs sm:text-sm font-bold text-primary-foreground shadow-md hover:bg-primary-hover active:scale-95 transition-all"
            >
              <Calendar className="h-4 w-4" />
              <span>{isHi ? "छत निरीक्षण बुक करें" : "Book Rooftop Inspection"}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
