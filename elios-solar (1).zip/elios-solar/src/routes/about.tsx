import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useLocale } from "../lib/locale-context";
import { ASSETS, CONTACT_INFO } from "../lib/constants";
import { QuoteModal } from "../components/QuoteModal";
import { ShieldCheck, Award, Users, CheckCircle, ArrowRight } from "lucide-react";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About Elios Solar Energy — Rooftop Solar EPC in Bihar" },
      {
        name: "description",
        content:
          "Elios Solar Energy engineers, supplies and installs turnkey rooftop solar plants for homes, housing societies and commercial facilities across Bihar.",
      },
      { property: "og:title", content: "About Elios Solar Energy — Rooftop Solar EPC in Bihar" },
      { property: "og:image", content: ASSETS.residentialHero },
    ],
    links: [{ rel: "canonical", href: "https://eliossolar.in/about" }],
  }),
  component: AboutPage,
});

function AboutPage() {
  const { isHi, t } = useLocale();
  const [quoteOpen, setQuoteOpen] = useState(false);

  return (
    <div className="w-full bg-background py-12 sm:py-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center mb-16">
          <div className="lg:col-span-7">
            <span className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-3.5 py-1 text-xs font-semibold text-foreground mb-4">
              <ShieldCheck className="h-3.5 w-3.5 text-primary" />
              <span>{isHi ? "बिहार की विश्वसनीय सोलर कंपनी" : "Trusted Solar EPC Partner"}</span>
            </span>
            <h1 className="font-display text-3xl sm:text-5xl font-extrabold text-foreground leading-tight">
              {isHi
                ? "एलियोस सोलर एनर्जी: बिहार को स्वच्छ ऊर्जा से रोशन करना"
                : "About Elios Solar Energy"}
            </h1>
            <p className="mt-4 text-base sm:text-lg text-muted-foreground leading-relaxed">
              {isHi
                ? "एलियोस सोलर एनर्जी एक संपूर्ण सोलर ईपीसी कंपनी है, जो बिहार में आवासीय, हाउसिंग सोसाइटी, कमर्शियल और औद्योगिक रूफटॉप सोलर परियोजनाओं की इंजीनियरिंग, आपूर्ति और सुरक्षित इंस्टॉलेशन करती है। हम सरकारी सब्सिडी और लोन की पूरी प्रक्रिया को सरल बनाते हैं।"
                : "Elios Solar Energy delivers turnkey rooftop solar engineering, procurement, and construction (EPC) solutions throughout Bihar. From shadow analysis and Tier-1 hardware sourcing to state DISCOM net-metering approvals and subsidy disbursement, we provide total single-point project accountability."}
            </p>

            <div className="mt-8">
              <button
                onClick={() => setQuoteOpen(true)}
                className="inline-flex items-center gap-2 rounded-xl bg-primary px-6 py-3 text-sm font-bold text-primary-foreground shadow-sm hover:bg-primary-hover"
              >
                <span>{t("getFreeQuotation")}</span>
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          </div>

          <div className="lg:col-span-5 rounded-3xl overflow-hidden border border-border shadow-xl">
            <img
              src={ASSETS.residentialHero}
              alt="Elios Solar Team Installation in Bihar"
              className="w-full h-80 sm:h-96 object-cover"
            />
          </div>
        </div>

        {/* Core Values */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="rounded-3xl border border-border bg-card p-8 shadow-sm">
            <ShieldCheck className="h-8 w-8 text-primary mb-4" />
            <h3 className="font-display text-xl font-bold text-foreground mb-2">
              {isHi ? "विश्वसनीयता एवं निष्ठा" : "Integrity & Standards"}
            </h3>
            <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed">
              {isHi
                ? "केवल उच्च गुणवत्ता वाले प्रमाणित उपकरण और वाटरप्रूफ सीलिंग के साथ सुरक्षित माउंटिंग।"
                : "ALMM-approved monocrystalline solar modules, certified inverters, and hot-dip galvanized mounting structures."}
            </p>
          </div>

          <div className="rounded-3xl border border-border bg-card p-8 shadow-sm">
            <Users className="h-8 w-8 text-primary mb-4" />
            <h3 className="font-display text-xl font-bold text-foreground mb-2">
              {isHi ? "ग्राहक-केंद्रित सेवा" : "Customer Accountability"}
            </h3>
            <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed">
              {isHi
                ? "सरकारी सब्सिडी की कागजी कार्रवाई से लेकर 25 वर्षों के सोलर रख-रखाव में निरंतर सहयोग।"
                : "Complete management of PM Surya Ghar subsidy paperwork, partner bank loans, and ongoing maintenance."}
            </p>
          </div>

          <div className="rounded-3xl border border-border bg-card p-8 shadow-sm">
            <Award className="h-8 w-8 text-primary mb-4" />
            <h3 className="font-display text-xl font-bold text-foreground mb-2">
              {isHi ? "पर्यावरणीय सततता" : "Clean Sustainability"}
            </h3>
            <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed">
              {isHi
                ? "बिहार के हर जिले में कोयला-आधारित बिजली पर निर्भरता घटाकर प्रदूषण-मुक्त भविष्य बनाना।"
                : "Empowering Bihar households and businesses to eliminate carbon footprint through clean daily sunshine."}
            </p>
          </div>
        </div>
      </div>

      <QuoteModal
        isOpen={quoteOpen}
        onClose={() => setQuoteOpen(false)}
        initialService="Residential Homes"
      />
    </div>
  );
}
