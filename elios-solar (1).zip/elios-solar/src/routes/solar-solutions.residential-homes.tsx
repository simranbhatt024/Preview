import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useLocale } from "../lib/locale-context";
import { ASSETS } from "../lib/constants";
import { SolarCalculatorWidget } from "../components/SolarCalculatorWidget";
import { QuoteModal } from "../components/QuoteModal";
import {
  CheckCircle,
  Sun,
  ShieldCheck,
  Banknote,
  ArrowRight,
  FileText,
  Zap,
  Wrench,
  Clock,
  Layers,
  HelpCircle,
  PhoneCall,
} from "lucide-react";

export const Route = createFileRoute("/solar-solutions/residential-homes")({
  head: () => ({
    meta: [
      { title: "Residential Rooftop Solar — Elios Solar Energy Bihar" },
      {
        name: "description",
        content:
          "PM Surya Ghar Muft Bijli Yojana rooftop solar installations across Bihar with central subsidy up to ₹78,000, 25-year panel warranty, and easy EMI financing.",
      },
      { property: "og:title", content: "Residential Rooftop Solar — Elios Solar Energy Bihar" },
      { property: "og:image", content: ASSETS.residentialHero },
    ],
    links: [{ rel: "canonical", href: "https://eliossolar.in/solar-solutions/residential-homes" }],
  }),
  component: ResidentialHomesPage,
});

function ResidentialHomesPage() {
  const { isHi, t } = useLocale();
  const [quoteOpen, setQuoteOpen] = useState(false);

  const steps = [
    {
      num: "01",
      titleEn: "Free Roof Assessment & Shadow Analysis",
      titleHi: "निःशुल्क छत निरीक्षण एवं शैडो विश्लेषण",
      descEn:
        "Our engineers inspect roof orientation, structural strength, shadow obstacles, and monthly DISCOM electricity usage to engineer the ideal system size.",
      descHi:
        "हमारे इंजीनियर आपकी छत की दिशा, मजबूती, छाया की स्थिति और मासिक बिजली खपत का अध्ययन कर सटीक सिस्टम क्षमता तय करते हैं।",
      img: "https://vibe.filesafe.space/1792820769937918655/assets/d9c6a46a-29e3-4e57-8d9f-9d1f3d886cbc.png",
      altEn: "Solar engineer inspecting a rooftop and analyzing shadows with a tablet",
      altHi: "सोलर इंजीनियर छत का निरीक्षण करते हुए शैडो विश्लेषण",
    },
    {
      num: "02",
      titleEn: "PM Surya Ghar Registration & Discom Approval",
      titleHi: "पीएम सूर्य घर पंजीकरण एवं डिस्कॉम स्वीकृति",
      descEn:
        "Elios handles 100% of the online subsidy portal application, NBPDCL/SBPDCL feasibility approvals, and bank loan documentation for you.",
      descHi:
        "एलियोस टीम राष्ट्रीय पोर्टल पर पंजीकरण, उत्तर/दक्षिण बिहार बिजली कंपनी से फिजिबिलिटी अप्रूवल और बैंक लोन की पूरी कागजी कार्रवाई खुद करती है।",
      img: "https://vibe.filesafe.space/1792820769937918655/assets/002911d6-e404-48c0-91af-6923bf062ca1.png",
      altEn: "Government solar subsidy portal registration and approval documents on a laptop",
      altHi: "सरकारी सोलर सब्सिडी पोर्टल पंजीकरण और स्वीकृति दस्तावेज़",
    },
    {
      num: "03",
      titleEn: "Precision Tier-1 Installation",
      titleHi: "टियर-1 उपकरण एवं पेशेवर इंस्टॉलेशन",
      descEn:
        "Hot-dip galvanized mounting structures, ALMM-listed TopCon/Mono-PERC panels, micro-switch protection, and lightning arresters installed in 1-2 days.",
      descHi:
        "जंग-रोधी हॉट-डिप गैल्वनाइज्ड स्ट्रक्चर, टॉपकॉन मोनो-पर्क पैनल्स, अर्थिंग किट और तड़ित चालक की सुरक्षित एवं मजबूत फिटिंग।",
      img: "https://vibe.filesafe.space/1792820769937918655/assets/76c0bad6-6607-4cf0-bb2a-e8911a74796b.png",
      altEn: "Technicians installing premium monocrystalline solar panels on a rooftop",
      altHi: "तकनीशियन छत पर प्रीमियम मोनोक्रिस्टलाइन सोलर पैनल लगाते हुए",
    },
    {
      num: "04",
      titleEn: "Bi-directional Net Metering & Subsidy Credit",
      titleHi: "नेट-मीटरिंग एवं डायरेक्ट बैंक सब्सिडी",
      descEn:
        "DISCOM inspects and connects the bi-directional meter. Excess daytime units export to the grid, and subsidy credits directly into your bank account.",
      descHi:
        "बिजली कंपनी द्वारा नेट मीटर लगाने के बाद अतिरिक्त बिजली ग्रिड में जाती है और सरकारी सब्सिडी सीधे आपके बैंक खाते (DBT) में जमा होती है।",
      img: "https://vibe.filesafe.space/1792820769937918655/assets/7c361d34-350d-491d-b382-7a95c8efca6b.png",
      altEn: "Bi-directional smart net meter showing exported solar units on a solar-equipped home",
      altHi: "बाय-डायरेक्शनल स्मार्ट नेट मीटर निर्यातित सोलर यूनिट दिखाते हुए",
    },
  ];

  const packagesData = [
    {
      capacity: "2 kW",
      idealForEn: "Small homes, 2–3 BHK (150–220 units/mo)",
      idealForHi: "छोटे परिवार, 2–3 बीएचके (150–220 यूनिट/माह)",
      subsidy: "Up to ₹60,000",
      generationEn: "8–9 units / day",
      generationHi: "8–9 यूनिट / दिन",
      roofEn: "150–180 sq. ft. shade-free",
      roofHi: "150–180 वर्ग फुट छाया-मुक्त छत",
    },
    {
      capacity: "3 kW",
      badgeEn: "Most Popular",
      badgeHi: "सर्वाधिक लोकप्रिय",
      idealForEn: "Medium homes with AC (250–350 units/mo)",
      idealForHi: "मध्यम परिवार + एसी (250–350 यूनिट/माह)",
      subsidy: "Up to ₹78,000",
      generationEn: "12–14 units / day",
      generationHi: "12–14 यूनिट / दिन",
      roofEn: "220–270 sq. ft. shade-free",
      roofHi: "220–270 वर्ग फुट छाया-मुक्त छत",
    },
    {
      capacity: "5 kW",
      idealForEn: "Large multi-floor homes, 2+ ACs (450–600 units/mo)",
      idealForHi: "बड़े घर, बहुमंजिला भवन, 2+ एसी (450–600 यूनिट/माह)",
      subsidy: "Up to ₹78,000 (Max Central Cap)",
      generationEn: "20–22 units / day",
      generationHi: "20–22 यूनिट / दिन",
      roofEn: "380–450 sq. ft. shade-free",
      roofHi: "380–450 वर्ग फुट छाया-मुक्त छत",
    },
  ];

  return (
    <div className="w-full bg-background py-12 sm:py-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        {/* 1. Header Hero */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center mb-16">
          <div className="lg:col-span-7">
            <span className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-3.5 py-1 text-xs font-semibold text-foreground mb-4">
              <Sun className="h-3.5 w-3.5 text-primary" />
              <span>PM Surya Ghar Muft Bijli Yojana</span>
            </span>
            <h1 className="font-display text-3xl sm:text-5xl font-extrabold text-foreground leading-tight">
              {isHi
                ? "आवासीय रूफटॉप सोलर: 90% तक बिजली बिल बचत"
                : "Residential Rooftop Solar for Homeowners in Bihar"}
            </h1>
            <p className="mt-4 text-base sm:text-lg text-muted-foreground leading-relaxed">
              {isHi
                ? "प्रधानमंत्री सूर्य घर मुफ्त बिजली योजना के अंतर्गत केंद्र सरकार की ₹78,000 तक की प्रत्यक्ष डीबीटी सब्सिडी का लाभ उठाएं। एलियोस सोलर एनर्जी छत के निरीक्षण से लेकर नेट मीटरिंग तक पूरी कागजी कार्रवाई खुद संभालती है।"
                : "Generate free, clean solar power directly from your roof terrace. Claim central government subsidies up to ₹78,000 and take advantage of partner bank EMI financing with 100% turnkey paperwork managed by Elios Solar."}
            </p>

            <div className="mt-6 space-y-3 text-sm font-semibold text-foreground">
              <div className="flex items-center gap-2.5">
                <CheckCircle className="h-4 w-4 text-success" />
                <span>
                  {isHi
                    ? "1 kW: ₹30,000 तक केंद्रीय सब्सिडी"
                    : "1 kW Plant: Up to ₹30,000 central subsidy"}
                </span>
              </div>
              <div className="flex items-center gap-2.5">
                <CheckCircle className="h-4 w-4 text-success" />
                <span>
                  {isHi
                    ? "2 kW: ₹60,000 तक केंद्रीय सब्सिडी"
                    : "2 kW Plant: Up to ₹60,000 central subsidy"}
                </span>
              </div>
              <div className="flex items-center gap-2.5">
                <CheckCircle className="h-4 w-4 text-success" />
                <span>
                  {isHi
                    ? "3 kW से 10 kW: ₹78,000 तक अधिकतम केंद्रीय सब्सिडी"
                    : "3 kW to 10 kW: Up to ₹78,000 central subsidy"}
                </span>
              </div>
            </div>

            <p className="mt-4 text-xs text-muted-foreground italic">{t("subsidyDisclaimer")}</p>

            <div className="mt-8 flex flex-wrap gap-4">
              <button
                onClick={() => setQuoteOpen(true)}
                className="inline-flex items-center gap-2 rounded-xl bg-primary px-6 py-3 text-sm font-bold text-primary-foreground shadow-sm hover:bg-primary-hover transition-all"
              >
                <span>{t("getFreeQuotation")}</span>
                <ArrowRight className="h-4 w-4" />
              </button>
              <a
                href="tel:+919153933318"
                className="inline-flex items-center gap-2 rounded-xl border border-border bg-card px-5 py-3 text-sm font-bold text-foreground hover:border-primary transition-colors"
              >
                <PhoneCall className="h-4 w-4 text-primary" />
                <span>{isHi ? "कॉल पर बात करें" : "Talk to Expert"}</span>
              </a>
            </div>
          </div>

          <div className="lg:col-span-5 rounded-3xl overflow-hidden border border-border shadow-xl">
            <img
              src={ASSETS.residentialHero}
              alt="Residential Rooftop Solar in Bihar"
              className="w-full h-80 sm:h-96 object-cover"
            />
          </div>
        </div>

        {/* 2. Key Advantages Grid */}
        <div className="mb-20">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <span className="text-xs font-bold uppercase tracking-wider text-primary">
              {isHi ? "घर के लिए सोलर क्यों?" : "Key Home Benefits"}
            </span>
            <h2 className="mt-2 font-display text-2xl sm:text-3xl font-extrabold text-foreground">
              {isHi
                ? "घर पर सोलर लगाने के प्रत्यक्ष लाभ"
                : "Why Bihar Families Choose Elios Residential Solar"}
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="group rounded-2xl border border-border bg-card overflow-hidden flex flex-col transition-all duration-300 hover:shadow-xl hover:-translate-y-1 hover:border-primary/40">
              <div className="relative aspect-[4/3] overflow-hidden">
                <img
                  src="https://vibe.filesafe.space/1792820769937918655/assets/fae8a68d-94ef-4ee9-bb53-b80467eafcc3.png"
                  alt={
                    isHi
                      ? "घर की छत पर सोलर पैनल और कम बिजली बिल"
                      : "Rooftop solar panels on a home with reduced electricity bill"
                  }
                  loading="lazy"
                  className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-navy-premium/70 via-navy-premium/10 to-transparent pointer-events-none" />
                <div className="absolute top-3 left-3 h-10 w-10 rounded-xl bg-primary/90 text-primary-foreground flex items-center justify-center shadow-lg ring-2 ring-white/20">
                  <Banknote className="h-5 w-5" />
                </div>
              </div>
              <div className="p-6 flex-1 flex flex-col">
                <h3 className="font-display text-lg font-bold text-foreground mb-2">
                  {isHi ? "90% तक बिजली बिल में कटौती" : "Up to 90% Bill Reduction"}
                </h3>
                <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed flex-1">
                  {isHi
                    ? "दिन के समय आपके पंखे, एसी, फ्रिज और मोटर सीधे धूप से चलते हैं। अतिरिक्त बिजली ग्रिड को निर्यात होकर मासिक बिल को न्यूनतम कर देती है।"
                    : "During sunlight hours, your appliances run directly on clean solar power. Surplus electricity exports back to DISCOM via net metering, reducing bills dramatically."}
                </p>
              </div>
            </div>

            <div className="group rounded-2xl border border-border bg-card overflow-hidden flex flex-col transition-all duration-300 hover:shadow-xl hover:-translate-y-1 hover:border-primary/40">
              <div className="relative aspect-[4/3] overflow-hidden">
                <img
                  src="https://vibe.filesafe.space/1792820769937918655/assets/ed88fb84-ae4e-4b85-86e9-435030150de5.png"
                  alt={
                    isHi
                      ? "प्रीमियम सोलर पैनल और वारंटी प्रमाणपत्र"
                      : "Premium solar panels with a warranty certificate"
                  }
                  loading="lazy"
                  className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-navy-premium/70 via-navy-premium/10 to-transparent pointer-events-none" />
                <div className="absolute top-3 left-3 h-10 w-10 rounded-xl bg-primary/90 text-primary-foreground flex items-center justify-center shadow-lg ring-2 ring-white/20">
                  <ShieldCheck className="h-5 w-5" />
                </div>
              </div>
              <div className="p-6 flex-1 flex flex-col">
                <h3 className="font-display text-lg font-bold text-foreground mb-2">
                  {isHi ? "25 साल की वारंटी सुरक्षा" : "25-Year Performance Warranty"}
                </h3>
                <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed flex-1">
                  {isHi
                    ? "टियर-1 मोनो-पर्क और टॉपकॉन पैनल्स 25 वर्षों तक 80%+ उत्पादन गारंटी के साथ आते हैं। एक बार का निवेश पीढ़ियों तक मुफ्त बिजली देता है।"
                    : "ALMM-approved monocrystalline panels engineered for extreme Bihar summers and rain with a linear 25-year performance warranty."}
                </p>
              </div>
            </div>

            <div className="group rounded-2xl border border-border bg-card overflow-hidden flex flex-col transition-all duration-300 hover:shadow-xl hover:-translate-y-1 hover:border-primary/40">
              <div className="relative aspect-[4/3] overflow-hidden">
                <img
                  src="https://vibe.filesafe.space/1792820769937918655/assets/0c736f80-6cb5-4648-ae5e-3389b16074da.png"
                  alt={
                    isHi
                      ? "सोलर सिस्टम और तेज़ लागत वसूली"
                      : "Solar system with rapid payback concept"
                  }
                  loading="lazy"
                  className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-navy-premium/70 via-navy-premium/10 to-transparent pointer-events-none" />
                <div className="absolute top-3 left-3 h-10 w-10 rounded-xl bg-primary/90 text-primary-foreground flex items-center justify-center shadow-lg ring-2 ring-white/20">
                  <Clock className="h-5 w-5" />
                </div>
              </div>
              <div className="p-6 flex-1 flex flex-col">
                <h3 className="font-display text-lg font-bold text-foreground mb-2">
                  {isHi ? "3–4 साल में पूरी लागत वसूल" : "Rapid 3 to 4 Year Payback"}
                </h3>
                <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed flex-1">
                  {isHi
                    ? "सब्सिडी और मासिक बिजली बिल में बचत के कारण सोलर सिस्टम का पूरा खर्च 3-4 वर्षों में वापस निकल आता है। अगले 20+ साल शुद्ध लाभ।"
                    : "Factoring in central subsidy and recurring power savings, your rooftop solar plant recovers its entire investment in 36 to 48 months."}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* 3. System Capacity Guide */}
        <div className="mb-20 rounded-3xl border border-border bg-card/60 p-6 sm:p-10">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <span className="text-xs font-bold uppercase tracking-wider text-primary">
              {isHi ? "सही आकार का चयन" : "System Sizing Guide"}
            </span>
            <h2 className="mt-2 font-display text-2xl sm:text-3xl font-extrabold text-foreground">
              {isHi
                ? "आपके घर के लिए कौन सा सोलर सिस्टम सही है?"
                : "Popular Residential Sizing Configurations"}
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {packagesData.map((pkg, idx) => (
              <div
                key={idx}
                className={`relative rounded-2xl border p-6 bg-card transition-all ${
                  pkg.badgeEn ? "border-primary shadow-md ring-1 ring-primary/40" : "border-border"
                }`}
              >
                {pkg.badgeEn && (
                  <span className="absolute -top-3 left-6 px-3 py-0.5 rounded-full bg-primary text-primary-foreground text-[10px] font-bold uppercase tracking-wider">
                    {isHi ? pkg.badgeHi : pkg.badgeEn}
                  </span>
                )}
                <div className="font-display text-3xl font-extrabold text-foreground mb-2">
                  {pkg.capacity}
                </div>
                <p className="text-xs text-muted-foreground mb-4 pb-4 border-b border-border/60">
                  {isHi ? pkg.idealForHi : pkg.idealForEn}
                </p>
                <div className="space-y-2.5 text-xs">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">
                      {isHi ? "सरकारी सब्सिडी:" : "Subsidy Benefit:"}
                    </span>
                    <span className="font-bold text-success">{pkg.subsidy}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">
                      {isHi ? "दैनिक उत्पादन:" : "Daily Output:"}
                    </span>
                    <span className="font-bold text-foreground">
                      {isHi ? pkg.generationHi : pkg.generationEn}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">
                      {isHi ? "छत का क्षेत्रफल:" : "Roof Area Req:"}
                    </span>
                    <span className="font-semibold text-foreground">
                      {isHi ? pkg.roofHi : pkg.roofEn}
                    </span>
                  </div>
                </div>

                <button
                  onClick={() => setQuoteOpen(true)}
                  className="mt-6 w-full py-2.5 rounded-xl bg-primary/10 text-primary hover:bg-primary hover:text-primary-foreground font-bold text-xs transition-colors"
                >
                  {isHi ? `यह क्षमता चुनें (${pkg.capacity})` : `Select ${pkg.capacity} Size`}
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* 4. 4-Step Turnkey Process */}
        <div className="mb-20">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <span className="text-xs font-bold uppercase tracking-wider text-primary">
              {isHi ? "सरल प्रक्रिया" : "Step-by-Step Execution"}
            </span>
            <h2 className="mt-2 font-display text-2xl sm:text-3xl font-extrabold text-foreground">
              {isHi
                ? "छत के सर्वे से लेकर सब्सिडी खाते में आने तक की प्रक्रिया"
                : "How Elios Delivers Your Solar Project in Bihar"}
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {steps.map((st, i) => (
              <div
                key={i}
                className="group rounded-2xl border border-border bg-card overflow-hidden flex flex-col transition-all duration-300 hover:shadow-xl hover:-translate-y-1 hover:border-primary/40"
              >
                <div className="relative aspect-[4/3] overflow-hidden">
                  <img
                    src={st.img}
                    alt={isHi ? st.altHi : st.altEn}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-navy-premium/70 via-navy-premium/10 to-transparent pointer-events-none" />
                  <span className="absolute top-3 left-3 font-display text-2xl font-black text-primary-foreground bg-primary/90 h-11 w-11 rounded-xl flex items-center justify-center shadow-lg ring-2 ring-white/20">
                    {st.num}
                  </span>
                </div>
                <div className="p-6 flex-1 flex flex-col">
                  <h3 className="font-display text-base font-bold text-foreground mb-2 leading-snug">
                    {isHi ? st.titleHi : st.titleEn}
                  </h3>
                  <p className="text-xs text-muted-foreground leading-relaxed flex-1">
                    {isHi ? st.descHi : st.descEn}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 5. Subsidy & Savings Calculator */}
        <div className="mb-16">
          <div className="text-center max-w-xl mx-auto mb-8">
            <span className="text-xs font-bold uppercase tracking-wider text-primary">
              {isHi ? "सटीक अनुमान" : "Instant Estimate"}
            </span>
            <h2 className="mt-2 font-display text-2xl sm:text-3xl font-bold text-foreground">
              {isHi ? "सोलर बचत एवं सब्सिडी कैलकुलेटर" : "Home Solar Savings & Subsidy Estimator"}
            </h2>
            <p className="mt-2 text-xs sm:text-sm text-muted-foreground">
              {isHi
                ? "अपने मासिक बिजली बिल के आधार पर उपयुक्त किलोवाट और अनुमानित बचत जानें।"
                : "Enter your monthly bill to see recommended system size, investment payback, and subsidy entitlement."}
            </p>
          </div>
          <SolarCalculatorWidget onGetExactQuote={() => setQuoteOpen(true)} />
        </div>

        {/* 6. Closing CTA Banner */}
        <div className="rounded-3xl border border-border bg-navy-dark text-white p-8 sm:p-12 text-center relative overflow-hidden">
          <div className="relative z-10 max-w-2xl mx-auto">
            <h3 className="font-display text-2xl sm:text-3xl font-extrabold text-cream-surface mb-3">
              {isHi
                ? "आज ही अपनी छत के लिए मुफ़्त सोलर कोटेशन प्राप्त करें"
                : "Ready to Cut Your Home Electricity Bills?"}
            </h3>
            <p className="text-xs sm:text-sm text-cream-surface/80 mb-6">
              {isHi
                ? "हमारे सोलर इंजीनियर आपके घर आकर छत का मुफ़्त मुआयना करेंगे और सब्सिडी की पूरी प्रक्रिया समझाएंगे।"
                : "Book a complimentary site visit with our Bihar engineers. We will analyze your shadow profile and prepare an exact quotation."}
            </p>
            <button
              onClick={() => setQuoteOpen(true)}
              className="inline-flex items-center gap-2 rounded-xl bg-primary px-7 py-3.5 text-sm font-bold text-primary-foreground shadow-lg hover:bg-primary-hover transition-all"
            >
              <span>{t("getFreeQuotation")}</span>
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      <QuoteModal
        isOpen={quoteOpen}
        onClose={() => setQuoteOpen(false)}
        initialService="Residential Homes"
      />
    </div>
  );
}
