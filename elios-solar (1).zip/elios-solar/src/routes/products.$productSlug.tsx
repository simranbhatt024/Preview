import { createFileRoute, notFound, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useLocale } from "../lib/locale-context";
import { INITIAL_PRODUCTS, type ProductItem, type ProductSpec } from "../lib/products-catalog";
import { QuoteModal } from "../components/QuoteModal";
import {
  ArrowLeft,
  ArrowRight,
  Sun,
  ShieldCheck,
  CheckCircle2,
  Cpu,
  Layers,
  Sparkles,
  Zap,
  Info,
  PhoneCall,
  Share2,
} from "lucide-react";

export const Route = createFileRoute("/products/$productSlug")({
  loader: ({ params }): { product: ProductItem } => {
    const product = INITIAL_PRODUCTS.find((p: ProductItem) => p.slug === params.productSlug);
    if (!product) {
      throw notFound();
    }
    return { product };
  },
  head: ({ loaderData }) => {
    if (!loaderData?.product) {
      return {
        meta: [
          { title: "Product Not Found — Elios Solar Energy" },
          { name: "robots", content: "noindex" },
        ],
      };
    }
    const p: ProductItem = loaderData.product;
    return {
      meta: [
        { title: `${p.nameEn} — Elios Solar Energy Bihar` },
        {
          name: "description",
          content: `${p.taglineEn} Technical specifications, features, and quotation for ${p.nameEn}.`,
        },
        { property: "og:title", content: `${p.nameEn} — Elios Solar Energy Bihar` },
        { property: "og:description", content: p.descriptionEn },
        { property: "og:image", content: p.image },
        { name: "twitter:card", content: "summary_large_image" },
        { name: "twitter:image", content: p.image },
      ],
    };
  },
  notFoundComponent: () => {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center px-4 text-center">
        <h2 className="text-2xl font-bold text-foreground">Product Not Found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The requested solar product could not be located in our catalog.
        </p>
        <Link
          to="/products"
          className="mt-6 inline-flex items-center gap-2 rounded-xl bg-primary px-5 py-2.5 text-xs font-bold text-primary-foreground"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Products</span>
        </Link>
      </div>
    );
  },
  component: ProductDetailPage,
});

function ProductDetailPage() {
  const data = Route.useLoaderData();
  const product: ProductItem = data.product;
  const { isHi, t } = useLocale();
  const [quoteOpen, setQuoteOpen] = useState(false);
  const [copied, setCopied] = useState(false);

  // Related products from same category or others
  const related: ProductItem[] = INITIAL_PRODUCTS.filter(
    (p: ProductItem) => p.id !== product.id,
  ).slice(0, 3);

  const handleShare = () => {
    if (typeof window !== "undefined") {
      navigator.clipboard?.writeText(window.location.href);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="w-full bg-background min-h-screen">
      {/* Breadcrumb Bar */}
      <div className="border-b border-border bg-card/60 backdrop-blur-sm sticky top-16 z-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 py-3 flex items-center justify-between">
          <Link
            to="/products"
            className="inline-flex items-center gap-2 text-xs font-bold text-muted-foreground hover:text-primary transition-colors"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            <span>{isHi ? "← सभी उत्पाद सूची" : "← Back to Products & Services"}</span>
          </Link>
          <div className="flex items-center gap-2">
            <button
              onClick={handleShare}
              className="inline-flex items-center gap-1.5 rounded-lg border border-border bg-background px-3 py-1.5 text-xs font-semibold text-foreground hover:bg-muted transition-colors"
            >
              <Share2 className="h-3.5 w-3.5 text-primary" />
              <span>{copied ? (isHi ? "कॉपी हो गया!" : "Copied!") : isHi ? "शेयर" : "Share"}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Product Showcase Section (Waaree Layout replica) */}
      <section className="py-10 sm:py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-start">
            {/* Left Column: Big Product Image & Visual Highlights */}
            <div className="lg:col-span-6 flex flex-col gap-6">
              <div className="relative aspect-[4/3] rounded-3xl bg-muted/30 border border-border overflow-hidden shadow-lg group">
                <img
                  src={product.image}
                  alt={isHi ? product.nameHi : product.nameEn}
                  className="h-full w-full object-contain p-6 group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute top-4 left-4 rounded-full bg-[#0B2036]/90 px-3.5 py-1 text-xs font-bold text-white backdrop-blur-sm shadow-sm">
                  {product.subcategory}
                </div>
                <div className="absolute top-4 right-4 rounded-full bg-primary px-3.5 py-1 text-xs font-extrabold text-[#0B2036] shadow-sm">
                  {isHi ? "कोटेशन पर उपलब्ध" : "Price on Request"}
                </div>
              </div>

              {/* Waaree-style Spotlight Badges */}
              <div className="grid grid-cols-3 gap-3">
                <div className="rounded-2xl border border-border bg-card p-3.5 text-center shadow-sm">
                  <ShieldCheck className="h-5 w-5 text-primary mx-auto mb-1" />
                  <div className="text-[11px] font-bold text-foreground">
                    {isHi ? "BIS व IEC प्रमाणित" : "BIS & IEC Certified"}
                  </div>
                  <div className="text-[10px] text-muted-foreground mt-0.5">
                    {isHi ? "सुरक्षा मानक" : "Safety Standards"}
                  </div>
                </div>

                <div className="rounded-2xl border border-border bg-card p-3.5 text-center shadow-sm">
                  <Zap className="h-5 w-5 text-emerald-500 mx-auto mb-1" />
                  <div className="text-[11px] font-bold text-foreground">
                    {isHi ? "उच्च रूपांतरण" : "Max Efficiency"}
                  </div>
                  <div className="text-[10px] text-muted-foreground mt-0.5">
                    {isHi ? "कम धूप में भी सक्रिय" : "Low Start-up"}
                  </div>
                </div>

                <div className="rounded-2xl border border-border bg-card p-3.5 text-center shadow-sm">
                  <Sun className="h-5 w-5 text-amber-500 mx-auto mb-1" />
                  <div className="text-[11px] font-bold text-foreground">
                    {isHi ? "बिहार हेतु अनुकूल" : "Engineered for Bihar"}
                  </div>
                  <div className="text-[10px] text-muted-foreground mt-0.5">
                    {isHi ? "गर्मी व धूल प्रतिरोधी" : "C5 Anti-Corrosion"}
                  </div>
                </div>
              </div>

              {/* Quick Contact Box */}
              <div className="rounded-2xl border border-primary/20 bg-primary/5 p-4 flex items-center justify-between">
                <div>
                  <div className="text-xs font-bold text-foreground">
                    {isHi ? "तकनीकी सहायता चाहिए?" : "Need Technical Sizing Advice?"}
                  </div>
                  <div className="text-[11px] text-muted-foreground mt-0.5">
                    {isHi
                      ? "हमारे इंजीनियर से सीधे बात करें"
                      : "Talk directly with our solar engineers"}
                  </div>
                </div>
                <a
                  href="tel:+919153933318"
                  className="inline-flex items-center gap-1.5 rounded-xl bg-card border border-border px-3.5 py-2 text-xs font-bold text-foreground hover:bg-muted transition-colors shadow-sm"
                >
                  <PhoneCall className="h-3.5 w-3.5 text-primary" />
                  <span>+91 91539 33318</span>
                </a>
              </div>
            </div>

            {/* Right Column: Title, Description, Detailed Specs & Actions */}
            <div className="lg:col-span-6 flex flex-col justify-between">
              <div>
                <div className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-3 py-1 text-xs font-bold text-foreground mb-3">
                  <Sparkles className="h-3.5 w-3.5 text-primary" />
                  <span>SKU: {product.sku}</span>
                </div>

                <h1 className="font-display text-2xl sm:text-4xl font-extrabold tracking-tight text-foreground leading-tight">
                  {isHi ? product.nameHi : product.nameEn}
                </h1>

                <p className="mt-3 text-base font-semibold text-primary">
                  {isHi ? product.taglineHi : product.taglineEn}
                </p>

                <p className="mt-4 text-sm sm:text-base text-muted-foreground leading-relaxed">
                  {isHi ? product.descriptionHi : product.descriptionEn}
                </p>

                {/* Primary CTA Buttons */}
                <div className="mt-6 flex flex-wrap gap-3">
                  <button
                    onClick={() => setQuoteOpen(true)}
                    className="flex-1 min-w-[200px] inline-flex items-center justify-center gap-2 rounded-xl bg-primary py-3.5 px-6 text-sm font-extrabold text-primary-foreground hover:bg-primary-hover shadow-md hover:shadow-lg transition-all"
                  >
                    <Sun className="h-4 w-4" />
                    <span>{t("requestQuote")}</span>
                    <ArrowRight className="h-4 w-4" />
                  </button>
                  <a
                    href={`https://wa.me/919153933318?text=${encodeURIComponent(
                      `Hello Elios Solar, I am interested in ${isHi ? product.nameHi : product.nameEn} (${product.sku}). Please share details.`,
                    )}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center justify-center gap-2 rounded-xl px-5 py-3.5 text-sm font-bold text-white shadow-md transition-all hover:brightness-110"
                    style={{ backgroundColor: "#25D366" }}
                  >
                    <svg
                      viewBox="0 0 24 24"
                      fill="currentColor"
                      className="h-4 w-4"
                      aria-hidden="true"
                    >
                      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.149-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.149-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.263c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.89c0 2.096.547 4.142 1.588 5.945L.05 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.89a11.821 11.821 0 00-3.48-8.413z" />
                    </svg>
                    <span>{isHi ? "व्हाट्सएप पर पूछें" : "WhatsApp"}</span>
                  </a>
                </div>

                {/* Key Features List */}
                <div className="mt-8 border-t border-border pt-6">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-foreground mb-3.5 flex items-center gap-2">
                    <Layers className="h-4 w-4 text-primary" />
                    <span>
                      {isHi ? "प्रमुख इंजीनियरिंग विशेषताएं" : "Key Engineering Highlights"}
                    </span>
                  </h3>
                  <ul className="space-y-2.5">
                    {(isHi ? product.featuresHi : product.featuresEn).map(
                      (feat: string, i: number) => (
                        <li
                          key={i}
                          className="flex items-start gap-2.5 text-xs sm:text-sm text-foreground"
                        >
                          <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
                          <span className="leading-relaxed">{feat}</span>
                        </li>
                      ),
                    )}
                  </ul>
                </div>

                {/* Technical Specifications Table */}
                <div className="mt-8 border-t border-border pt-6">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-foreground mb-3.5 flex items-center gap-2">
                    <Cpu className="h-4 w-4 text-primary" />
                    <span>{isHi ? "तकनीकी विवरण तालिका" : "Technical Specifications Table"}</span>
                  </h3>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                    {product.specs.map((sp: ProductSpec, i: number) => (
                      <div
                        key={i}
                        className="rounded-xl border border-border bg-card p-3 text-xs shadow-xs"
                      >
                        <div className="text-[10px] text-muted-foreground uppercase font-semibold">
                          {sp.label}
                        </div>
                        <div className="font-extrabold text-foreground mt-1 text-sm">
                          {sp.value}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Applications Section */}
                <div className="mt-8 rounded-2xl bg-muted/60 p-4 border border-border/80">
                  <div className="text-xs font-bold uppercase tracking-wider text-primary mb-1">
                    {isHi
                      ? "अनुशंसित उपयोग (Recommended Applications)"
                      : "Recommended Applications"}
                  </div>
                  <p className="text-xs sm:text-sm text-foreground leading-relaxed">
                    {isHi ? product.applicationsHi : product.applicationsEn}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* MNRE / PM Surya Ghar Subsidized Compliance Notice */}
          <div className="mt-14 rounded-3xl border border-primary/30 bg-primary/5 p-6 sm:p-8 flex items-start gap-4">
            <Info className="h-6 w-6 text-primary shrink-0 mt-0.5" />
            <div className="space-y-1.5 text-xs sm:text-sm text-foreground leading-relaxed">
              <div className="font-extrabold text-base text-foreground">
                {isHi
                  ? "पीएम सूर्य घर एवं एमएनआरई अनुपालन गारंटी"
                  : "PM Surya Ghar & MNRE Compliance Assurance"}
              </div>
              <p className="text-muted-foreground">
                {isHi
                  ? "बिहार में केंद्र सरकार की पीएम सूर्य घर मुफ्त बिजली योजना के अंतर्गत सभी उपकरण (मॉड्यूल, इन्वर्टर, एसीडीबी, डीसीडीबी) डिस्कॉम (NBPDCL / SBPDCL) के तकनीकी नियमों के अनुरूप स्थापित किए जाते हैं। अधिकतम ₹78,000 की केंद्रीय सब्सिडी का संपूर्ण दस्तावेज़ीकरण एलियोस सोलर स्वयं पूरा करता है।"
                  : "All equipment deployed across Bihar under PM Surya Ghar Muft Bijli Yojana complies with strict DISCOM (NBPDCL / SBPDCL) standards and ALMM / BIS quality guidelines. Central subsidy paperwork up to ₹78,000 is directly handled end-to-end by Elios Solar Energy."}
              </p>
            </div>
          </div>

          {/* Related Products from Catalog */}
          {related.length > 0 && (
            <div className="mt-16 border-t border-border pt-12">
              <div className="flex items-center justify-between mb-8">
                <div>
                  <span className="text-xs font-bold uppercase tracking-wider text-primary">
                    {isHi ? "संबंधित उत्पाद" : "Explore More Products"}
                  </span>
                  <h3 className="font-display text-xl sm:text-2xl font-bold text-foreground mt-1">
                    {isHi ? "अन्य लोकप्रिय सौर उपकरण" : "Related Solar Equipment"}
                  </h3>
                </div>
                <Link
                  to="/products"
                  className="inline-flex items-center gap-1.5 text-xs font-bold text-primary hover:underline"
                >
                  <span>{isHi ? "सभी उत्पाद देखें" : "View All"}</span>
                  <ArrowRight className="h-3.5 w-3.5" />
                </Link>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {related.map((item: ProductItem) => (
                  <Link
                    key={item.id}
                    to="/products/$productSlug"
                    params={{ productSlug: item.slug }}
                    className="group flex flex-col justify-between overflow-hidden rounded-3xl border border-border bg-card p-5 hover:border-primary hover:shadow-lg transition-all"
                  >
                    <div>
                      <div className="aspect-[16/11] rounded-2xl bg-muted/40 overflow-hidden mb-4 relative flex items-center justify-center">
                        <img
                          src={item.image}
                          alt={isHi ? item.nameHi : item.nameEn}
                          className="h-full w-full object-contain p-2 group-hover:scale-105 transition-transform duration-300"
                        />
                        <div className="absolute top-2 left-2 rounded-full bg-[#0B2036]/85 px-2.5 py-0.5 text-[10px] font-bold text-white">
                          {item.subcategory}
                        </div>
                      </div>
                      <div className="text-[10px] font-bold text-primary uppercase">{item.sku}</div>
                      <h4 className="font-display text-base font-bold text-foreground group-hover:text-primary transition-colors line-clamp-1 mt-0.5">
                        {isHi ? item.nameHi : item.nameEn}
                      </h4>
                      <p className="mt-1 text-xs text-muted-foreground line-clamp-2">
                        {isHi ? item.taglineHi : item.taglineEn}
                      </p>
                    </div>

                    <div className="mt-4 flex items-center justify-between border-t border-border/60 pt-3 text-xs font-bold text-primary">
                      <span>{isHi ? "विवरण देखें" : "View Full Details"}</span>
                      <ArrowRight className="h-3.5 w-3.5 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Quote Modal */}
      <QuoteModal
        isOpen={quoteOpen}
        onClose={() => setQuoteOpen(false)}
        initialService="Products and Packages"
        initialMessage={isHi ? product.nameHi : product.nameEn}
      />
    </div>
  );
}
