import { createFileRoute, Outlet } from "@tanstack/react-router";

export const Route = createFileRoute("/products")({
  head: () => ({
    meta: [
      { title: "Solar Products & Equipment — Elios Solar Energy Bihar" },
      {
        name: "description",
        content:
          "Explore Tier-1 ALMM approved solar PV modules (HJT, TOPCon, Mono PERC, Flexible), on-grid inverters (1-phase, 3-phase, utility scale), and all-in-one solar kits by Elios Solar Energy.",
      },
      { property: "og:title", content: "Solar Products & Equipment — Elios Solar Energy Bihar" },
    ],
  }),
  component: ProductsLayout,
});

function ProductsLayout() {
  return <Outlet />;
}
