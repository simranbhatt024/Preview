import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { useLocale } from "../lib/locale-context";
import { INITIAL_POSTS } from "../lib/mock-data";
import { BlogPost } from "../lib/blog-types";
import { QuoteModal } from "../components/QuoteModal";
import {
  Calendar,
  Clock,
  ArrowLeft,
  Share2,
  ShieldCheck,
  CheckCircle2,
  HelpCircle,
  Sparkles,
  PhoneCall,
} from "lucide-react";

export const Route = createFileRoute("/news/$postSlug")({
  head: ({ params }) => {
    const slug = params.postSlug;
    return {
      meta: [
        { title: `Solar Blog — Elios Solar Energy Bihar` },
        {
          name: "description",
          content:
            "Complete rooftop solar guide and PM Surya Ghar subsidy insights for Bihar by Elios Solar Energy.",
        },
        { property: "og:title", content: `Solar Guide — Elios Solar Energy` },
        { property: "og:type", content: "article" },
      ],
      links: [
        {
          rel: "canonical",
          href: `https://eliossolar.in/news/${slug}`,
        },
      ],
    };
  },
  component: BlogPostDetailComponent,
});

function BlogPostDetailComponent() {
  const { postSlug } = Route.useParams();
  const { isHi } = useLocale();
  const [post, setPost] = useState<BlogPost | null>(null);
  const [quoteOpen, setQuoteOpen] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    try {
      const stored = localStorage.getItem("elios_blog_posts");
      const list: any[] = stored ? JSON.parse(stored) : INITIAL_POSTS;
      const found = list.find((p) => p.slug === postSlug || p.id === postSlug);
      if (found) {
        setPost(found);
      } else {
        const fallback = INITIAL_POSTS.find((p) => p.slug === postSlug);
        setPost((fallback as any) || null);
      }
    } catch {
      setPost(null);
    }
  }, [postSlug]);

  if (!post) {
    return (
      <div className="w-full min-h-[60vh] flex flex-col items-center justify-center p-6 text-center">
        <h2 className="text-2xl font-bold font-display text-foreground mb-3">
          {isHi
            ? "ब्लॉग लेख लोड हो रहा है या उपलब्ध नहीं है"
            : "Blog post is loading or unavailable"}
        </h2>
        <p className="text-sm text-muted-foreground mb-6">
          {isHi
            ? "यह पोस्ट नहीं मिली। कृपया समाचार एवं ब्लॉग पृष्ठ पर वापस जाएं।"
            : "This post was not found. Please return to the news & blogs page."}
        </p>
        <Link
          to="/news"
          className="inline-flex items-center gap-2 px-5 py-2.5 bg-primary text-primary-foreground font-bold rounded-xl text-xs"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>{isHi ? "सभी ब्लॉग देखें" : "View All Blogs"}</span>
        </Link>
      </div>
    );
  }

  const title = isHi ? post.titleHi || post.titleEn || "" : post.titleEn || post.titleHi || "";
  const content = isHi
    ? post.contentHi || post.contentEn || ""
    : post.contentEn || post.contentHi || "";
  const excerpt = isHi
    ? post.excerptHi || post.excerptEn || ""
    : post.excerptEn || post.excerptHi || "";

  // Rank Math FAQ Schema Generation
  const faqSchema =
    post.faqs && post.faqs.length > 0
      ? {
          "@context": "https://schema.org",
          "@type": "FAQPage",
          mainEntity: post.faqs.map((faq) => ({
            "@type": "Question",
            name: faq.question,
            acceptedAnswer: {
              "@type": "Answer",
              text: faq.answer,
            },
          })),
        }
      : null;

  const articleSchema = {
    "@context": "https://schema.org",
    "@type": post.schemaType || "Article",
    headline: title,
    description: post.metaDescriptionHi || post.metaDescription || excerpt,
    image: post.coverImage,
    author: {
      "@type": "Person",
      name: post.author || "Elios Solar Team",
    },
    publisher: {
      "@type": "Organization",
      name: "Elios Solar Energy",
      logo: {
        "@type": "ImageObject",
        url: "https://vibe.filesafe.space/1792820769937918655/assets/176fee8d-679a-4bc7-842d-c24b2c667d29.png",
      },
    },
    datePublished: post.publishedAt,
    mainEntityOfPage: `https://eliossolar.in/news/${post.slug}`,
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title,
        url: window.location.href,
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="w-full bg-background py-10 sm:py-16">
      {/* Inject Article & FAQ Schema */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(articleSchema) }}
      />
      {faqSchema && (
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}
        />
      )}

      <article className="mx-auto max-w-4xl px-4 sm:px-6">
        {/* Back Link */}
        <div className="mb-6">
          <Link
            to="/news"
            className="inline-flex items-center gap-2 text-xs font-bold text-muted-foreground hover:text-primary transition-colors"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>{isHi ? "सभी समाचार एवं ब्लॉग पर वापस जाएं" : "Back to all news & blogs"}</span>
          </Link>
        </div>

        {/* Category & Reading Time */}
        <div className="flex flex-wrap items-center gap-2 text-xs font-bold text-primary mb-3">
          <span className="px-2.5 py-0.5 rounded-full bg-primary/10">{post.category}</span>
          <span>•</span>
          <span className="text-muted-foreground flex items-center gap-1">
            <Clock className="h-3.5 w-3.5" />
            {post.readingTime}
          </span>
          {post.factChecker && (
            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 font-semibold text-[11px] ml-auto">
              <ShieldCheck className="h-3.5 w-3.5" />
              <span>
                {isHi ? `सत्यापित: ${post.factChecker}` : `Verified: ${post.factChecker}`}
              </span>
            </span>
          )}
        </div>

        {/* Title */}
        <h1 className="font-display text-3xl sm:text-5xl font-extrabold text-foreground leading-tight mb-5">
          {title}
        </h1>

        {/* Author / Date Metadata Bar */}
        <div className="flex flex-wrap items-center justify-between gap-4 py-4 border-y border-border mb-8 text-xs text-muted-foreground">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-full bg-primary/20 text-primary flex items-center justify-center font-bold text-sm">
              {post.author.charAt(0)}
            </div>
            <div>
              <div className="font-bold text-foreground text-sm">{post.author}</div>
              <div className="text-[11px]">
                {post.authorRole || (isHi ? "सोलर विशेषज्ञ" : "Solar Expert")}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5">
              <Calendar className="h-4 w-4" />
              <span>{post.publishedAt}</span>
            </div>
            <button
              onClick={handleShare}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-border bg-card hover:bg-muted font-bold text-foreground transition-all"
            >
              <Share2 className="h-3.5 w-3.5" />
              <span>
                {copied
                  ? isHi
                    ? "लिंक कॉपी हो गया!"
                    : "Link Copied!"
                  : isHi
                    ? "शेयर करें"
                    : "Share"}
              </span>
            </button>
          </div>
        </div>

        {/* Featured Cover Image */}
        {post.coverImage && (
          <div className="mb-10 rounded-3xl overflow-hidden border border-border shadow-md bg-muted aspect-[16/9]">
            <img src={post.coverImage} alt={title} className="w-full h-full object-cover" />
          </div>
        )}

        {/* Full Article Content */}
        <div
          className="article-content max-w-none text-foreground/90 leading-relaxed"
          dangerouslySetInnerHTML={{ __html: content }}
        />

        {/* Rank Math FAQ Section in Blog */}
        {post.faqs && post.faqs.length > 0 && (
          <div className="mt-14 rounded-3xl border border-border bg-card p-6 sm:p-8 shadow-sm">
            <div className="flex items-center gap-2 mb-6 text-primary">
              <HelpCircle className="h-5 w-5" />
              <h2 className="font-display text-xl sm:text-2xl font-bold text-foreground">
                {isHi ? "अक्सर पूछे जाने वाले प्रश्न (FAQ)" : "Frequently Asked Questions (FAQ)"}
              </h2>
            </div>
            <div className="space-y-4">
              {post.faqs.map((faq, idx) => (
                <div
                  key={idx}
                  className="rounded-2xl border border-border bg-background p-5 text-left"
                >
                  <h3 className="text-base font-bold text-foreground mb-2 flex items-start gap-2">
                    <span className="text-primary font-black">Q.</span>
                    <span>{faq.question}</span>
                  </h3>
                  <p className="text-sm text-muted-foreground leading-relaxed pl-6">{faq.answer}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Bottom Consultation Box */}
        <div className="mt-12 rounded-3xl border-2 border-primary/30 bg-primary/5 p-6 sm:p-8 flex flex-col sm:flex-row items-center justify-between gap-6 shadow-sm">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-primary">
              {isHi ? "विशेष परामर्श" : "Expert Consultation"}
            </span>
            <h3 className="font-display text-xl sm:text-2xl font-extrabold text-foreground mt-1">
              {isHi
                ? "अपने छत के लिए सही सोलर सिस्टम जानें"
                : "Find the Right Solar System for Your Roof"}
            </h3>
            <p className="text-xs sm:text-sm text-muted-foreground mt-1 max-w-lg">
              {isHi
                ? "मुफ़्त रूफटॉप सर्वे और पीएम सूर्य घर योजना के तहत ₹78,000 तक की सब्सिडी सहायता प्राप्त करें।"
                : "Get a free rooftop inspection and PM Surya Ghar subsidy assistance of up to ₹78,000."}
            </p>
          </div>
          <button
            onClick={() => setQuoteOpen(true)}
            className="shrink-0 px-6 py-3 bg-primary text-primary-foreground font-bold text-xs sm:text-sm rounded-xl shadow-md hover:bg-primary-hover transition-all"
          >
            {isHi ? "मुफ़्त कोटेशन प्राप्त करें" : "Get Free Quotation"}
          </button>
        </div>
      </article>

      <QuoteModal
        isOpen={quoteOpen}
        onClose={() => setQuoteOpen(false)}
        initialService="Residential Homes"
      />
    </div>
  );
}
