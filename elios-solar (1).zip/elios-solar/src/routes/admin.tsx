import { createFileRoute } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { useLocale } from "../lib/locale-context";
import {
  ShieldCheck,
  Lock,
  LogOut,
  Users,
  FileText,
  Phone,
  Search,
  Download,
  AlertCircle,
  KeyRound,
  CheckCircle,
  FileEdit,
} from "lucide-react";
import { WordPressBlogEditor } from "../components/WordPressBlogEditor";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Admin Portal — Elios Solar Energy" },
      {
        name: "description",
        content:
          "Elios Solar Energy admin dashboard for leads, inquiries, and customer management.",
      },
    ],
  }),
  component: AdminPage,
});

function AdminPage() {
  const { isHi } = useLocale();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState("");
  const [loginError, setLoginError] = useState("");
  const [leads, setLeads] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [adminTab, setAdminTab] = useState<"leads" | "blogs" | "passcode">("blogs");
  const [newPasscode, setNewPasscode] = useState("");
  const [confirmPasscode, setConfirmPasscode] = useState("");
  const [passcodeMsg, setPasscodeMsg] = useState<{
    type: "success" | "error";
    text: string;
  } | null>(null);

  // Check existing session
  useEffect(() => {
    const session = sessionStorage.getItem("elios_admin_auth");
    if (session === "true") {
      setIsAuthenticated(true);
    }
  }, []);

  // Load leads from storage
  useEffect(() => {
    if (!isAuthenticated) return;
    try {
      const stored = JSON.parse(localStorage.getItem("elios_leads") || "[]");
      if (stored.length === 0) {
        const demoLeads = [
          {
            id: "lead_demo_1",
            createdAt: new Date().toISOString(),
            fullName: "Amit Sharma",
            phone: "9876543210",
            email: "amit.sharma@example.com",
            city: "Patna",
            serviceNeeded: "Residential Homes",
            source: "free_quotation",
            message: "Interested in 3 kW PM Surya Ghar system with battery backup.",
          },
          {
            id: "lead_demo_2",
            createdAt: new Date(Date.now() - 86400000).toISOString(),
            fullName: "Sunita Devi",
            phone: "9123456780",
            email: "sunita@example.com",
            city: "Muzaffarpur",
            serviceNeeded: "Housing Society",
            source: "free_consultation",
            message: "Need quote for apartment water pump and lift power.",
          },
        ];
        localStorage.setItem("elios_leads", JSON.stringify(demoLeads));
        setLeads(demoLeads);
      } else {
        setLeads(stored);
      }
    } catch {
      setLeads([]);
    }
  }, [isAuthenticated]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError("");

    // Mandatory master passcode (always works, cannot be removed) + any custom passcode
    // the client has set from the Change Passcode section.
    const customPasscode = localStorage.getItem("elios_admin_custom_passcode") || "";
    const validPasscodes = ["MongersMintDev2002"];
    if (customPasscode) validPasscodes.push(customPasscode);

    if (validPasscodes.includes(password)) {
      sessionStorage.setItem("elios_admin_auth", "true");
      setIsAuthenticated(true);
    } else {
      setLoginError(
        isHi
          ? "अमान्य एडमिन पासवर्ड। कृपया सही क्रेडेंशियल दर्ज करें।"
          : "Invalid admin passcode. Please enter the correct password.",
      );
    }
  };

  const handleLogout = () => {
    sessionStorage.removeItem("elios_admin_auth");
    setIsAuthenticated(false);
    setPassword("");
  };

  const filteredLeads = leads.filter(
    (l) =>
      l.fullName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      l.city?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      l.phone?.includes(searchTerm),
  );

  // If NOT authenticated, show exclusive login gate
  if (!isAuthenticated) {
    return (
      <div className="flex min-h-[75vh] items-center justify-center bg-background px-4 py-12">
        <div className="w-full max-w-md rounded-3xl border border-border bg-card p-8 shadow-xl">
          <div className="text-center mb-6">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10 text-primary mb-3">
              <Lock className="h-7 w-7" />
            </div>
            <h1 className="font-display text-2xl font-bold text-foreground">
              {isHi ? "एलियोस एडमिन पोर्टल लॉगिन" : "Elios Admin Portal Login"}
            </h1>
            <p className="mt-1 text-xs text-muted-foreground">
              {isHi
                ? "यह क्षेत्र केवल अधिकृत व्यवस्थापकों के लिए सुरक्षित है।"
                : "Restricted area. Please sign in with your administrative credentials."}
            </p>
          </div>

          {loginError && (
            <div className="mb-4 flex items-center gap-2 rounded-xl bg-destructive/10 p-3 text-xs text-destructive">
              <AlertCircle className="h-4 w-4 shrink-0" />
              <span>{loginError}</span>
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-foreground mb-1">
                {isHi ? "एडमिन पासवर्ड" : "Admin Passcode"}
              </label>
              <div className="relative">
                <KeyRound className="h-4 w-4 absolute left-3.5 top-3 text-muted-foreground" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full rounded-xl border border-border bg-background pl-10 pr-4 py-2.5 text-sm text-foreground focus:border-primary focus:outline-none"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full rounded-xl bg-primary py-2.5 text-sm font-bold text-primary-foreground shadow-md hover:bg-primary-hover transition-all active:scale-95"
            >
              {isHi ? "पोर्टल में प्रवेश करें" : "Access Admin Portal"}
            </button>
          </form>

          <div className="mt-6 text-center text-[11px] text-muted-foreground border-t border-border pt-4">
            Elios Solar Energy EPC • Internal Operations System
          </div>
        </div>
      </div>
    );
  }

  // Authenticated Admin Dashboard View
  return (
    <div className="w-full bg-background py-10 sm:py-14">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        {/* Admin Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 border-b border-border gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="h-2.5 w-2.5 rounded-full bg-success animate-pulse" />
              <span className="text-xs font-bold uppercase tracking-wider text-primary">
                Elios Admin Portal • Authenticated
              </span>
            </div>
            <h1 className="font-display text-2xl sm:text-3xl font-extrabold text-foreground mt-1">
              {isHi ? "प्रबंधन डैशबोर्ड" : "Elios Operations & Content CMS"}
            </h1>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setAdminTab("blogs")}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold rounded-xl transition-all ${
                adminTab === "blogs"
                  ? "bg-primary text-primary-foreground shadow"
                  : "bg-card border border-border text-foreground hover:bg-muted"
              }`}
            >
              <FileEdit className="h-3.5 w-3.5" />
              <span>{isHi ? "पोस्ट" : "Posts"}</span>
            </button>

            <button
              onClick={() => setAdminTab("leads")}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold rounded-xl transition-all ${
                adminTab === "leads"
                  ? "bg-primary text-primary-foreground shadow"
                  : "bg-card border border-border text-foreground hover:bg-muted"
              }`}
            >
              <Users className="h-3.5 w-3.5" />
              <span>Customer Leads ({leads.length})</span>
            </button>

            <button
              onClick={() => setAdminTab("passcode")}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold rounded-xl transition-all ${
                adminTab === "passcode"
                  ? "bg-primary text-primary-foreground shadow"
                  : "bg-card border border-border text-foreground hover:bg-muted"
              }`}
            >
              <KeyRound className="h-3.5 w-3.5" />
              <span>{isHi ? "पासकोड बदलें" : "Change Passcode"}</span>
            </button>

            <button
              onClick={handleLogout}
              className="inline-flex items-center gap-1.5 rounded-xl border border-destructive/40 bg-destructive/10 px-3 py-1.5 text-xs font-semibold text-destructive hover:bg-destructive/20 transition-all ml-2"
            >
              <LogOut className="h-3.5 w-3.5" />
              <span>{isHi ? "लॉग आउट" : "Sign Out"}</span>
            </button>
          </div>
        </div>

        {adminTab === "blogs" && (
          <div className="mt-6">
            <WordPressBlogEditor />
          </div>
        )}

        {adminTab === "leads" && (
          <>
            {/* Search Bar */}
            <div className="mt-6 mb-6 max-w-md relative">
              <Search className="h-4 w-4 absolute left-3 top-3 text-muted-foreground" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search leads by name, city or phone..."
                className="w-full rounded-xl border border-border bg-background pl-9 pr-4 py-2 text-xs text-foreground focus:border-primary focus:outline-none"
              />
            </div>

            {/* Leads Table */}
            <div className="rounded-2xl border border-border bg-card overflow-hidden shadow-sm">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-secondary/10 border-b border-border text-muted-foreground font-semibold">
                    <tr>
                      <th className="p-3.5">Name</th>
                      <th className="p-3.5">Phone</th>
                      <th className="p-3.5">City</th>
                      <th className="p-3.5">Service</th>
                      <th className="p-3.5">Source</th>
                      <th className="p-3.5">Message / Details</th>
                      <th className="p-3.5">Date</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {filteredLeads.map((lead) => (
                      <tr key={lead.id} className="hover:bg-muted/40 transition-colors">
                        <td className="p-3.5 font-bold text-foreground">{lead.fullName}</td>
                        <td className="p-3.5">
                          <a
                            href={`tel:${lead.phone}`}
                            className="text-primary hover:underline font-medium"
                          >
                            {lead.phone}
                          </a>
                        </td>
                        <td className="p-3.5 text-foreground">{lead.city}</td>
                        <td className="p-3.5">
                          <span className="px-2 py-0.5 rounded-full bg-primary/10 text-primary font-semibold text-[11px]">
                            {lead.serviceNeeded}
                          </span>
                        </td>
                        <td className="p-3.5 text-muted-foreground">{lead.source}</td>
                        <td
                          className="p-3.5 text-muted-foreground max-w-xs truncate"
                          title={lead.message}
                        >
                          {lead.message || "—"}
                        </td>
                        <td className="p-3.5 text-muted-foreground text-[11px]">
                          {new Date(lead.createdAt).toLocaleDateString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        )}

        {adminTab === "passcode" && (
          <div className="mt-6 max-w-2xl">
            <div className="rounded-2xl border border-border bg-card p-6 sm:p-8 shadow-sm">
              <div className="flex items-center gap-3 mb-6">
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/10 text-primary">
                  <KeyRound className="h-5 w-5" />
                </div>
                <div>
                  <h2 className="font-display text-xl font-bold text-foreground">
                    {isHi ? "एडमिन पासकोड बदलें" : "Change Admin Passcode"}
                  </h2>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    {isHi
                      ? "एडमिन पोर्टल के लिए अपना नया पासकोड सेट करें।"
                      : "Set your new security passcode for the admin portal."}
                  </p>
                </div>
              </div>

              {passcodeMsg && (
                <div
                  className={`mb-5 flex items-center gap-2 rounded-xl p-3.5 text-xs font-medium ${
                    passcodeMsg.type === "success"
                      ? "bg-success/10 text-success border border-success/30"
                      : "bg-destructive/10 text-destructive border border-destructive/30"
                  }`}
                >
                  {passcodeMsg.type === "success" ? (
                    <CheckCircle className="h-4 w-4 shrink-0" />
                  ) : (
                    <AlertCircle className="h-4 w-4 shrink-0" />
                  )}
                  <span>{passcodeMsg.text}</span>
                </div>
              )}

              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  setPasscodeMsg(null);

                  if (!newPasscode.trim()) {
                    setPasscodeMsg({
                      type: "error",
                      text: isHi
                        ? "कृपया एक नया पासकोड दर्ज करें।"
                        : "Please enter a new passcode.",
                    });
                    return;
                  }
                  if (newPasscode.length < 6) {
                    setPasscodeMsg({
                      type: "error",
                      text: isHi
                        ? "पासकोड कम से कम 6 अक्षर का होना चाहिए।"
                        : "Passcode must be at least 6 characters.",
                    });
                    return;
                  }
                  if (newPasscode !== confirmPasscode) {
                    setPasscodeMsg({
                      type: "error",
                      text: isHi
                        ? "पासकोड मेल नहीं खाते। कृपया दोबारा दर्ज करें।"
                        : "Passcodes do not match. Please re-enter.",
                    });
                    return;
                  }
                  localStorage.setItem("elios_admin_custom_passcode", newPasscode);
                  setNewPasscode("");
                  setConfirmPasscode("");
                  setPasscodeMsg({
                    type: "success",
                    text: isHi
                      ? "पासकोड सफलतापूर्वक अपडेट कर दिया गया।"
                      : "Passcode updated successfully.",
                  });
                }}
                className="space-y-5"
              >
                <div>
                  <label className="block text-xs font-bold text-muted-foreground uppercase mb-1.5">
                    {isHi ? "नया पासकोड" : "New Passcode"}
                  </label>
                  <div className="relative">
                    <KeyRound className="h-4 w-4 absolute left-3.5 top-3 text-muted-foreground" />
                    <input
                      type="password"
                      required
                      value={newPasscode}
                      onChange={(e) => setNewPasscode(e.target.value)}
                      placeholder={isHi ? "नया पासकोड दर्ज करें" : "Enter new passcode"}
                      className="w-full rounded-xl border border-border bg-background pl-10 pr-4 py-2.5 text-sm text-foreground focus:border-primary focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-muted-foreground uppercase mb-1.5">
                    {isHi ? "पासकोड की पुष्टि करें" : "Confirm Passcode"}
                  </label>
                  <div className="relative">
                    <KeyRound className="h-4 w-4 absolute left-3.5 top-3 text-muted-foreground" />
                    <input
                      type="password"
                      required
                      value={confirmPasscode}
                      onChange={(e) => setConfirmPasscode(e.target.value)}
                      placeholder={isHi ? "पासकोड दोबारा दर्ज करें" : "Re-enter passcode"}
                      className="w-full rounded-xl border border-border bg-background pl-10 pr-4 py-2.5 text-sm text-foreground focus:border-primary focus:outline-none"
                    />
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-3 pt-2">
                  <button
                    type="submit"
                    className="inline-flex items-center gap-2 rounded-xl bg-primary px-5 py-2.5 text-xs font-bold text-primary-foreground shadow hover:bg-primary-hover transition-all active:scale-95"
                  >
                    <KeyRound className="h-4 w-4" />
                    <span>{isHi ? "पासकोड सेव करें" : "Save Passcode"}</span>
                  </button>
                </div>
              </form>

              <div className="mt-6 pt-5 border-t border-border text-[11px] text-muted-foreground">
                {isHi
                  ? "नोट: पासकोड इस ब्राउज़र में सेव रहता है। सुरक्षा के लिए इसे किसी सुरक्षित स्थान पर नोट कर लें।"
                  : "Note: The passcode is stored in this browser. Keep it noted in a secure place for safety."}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
