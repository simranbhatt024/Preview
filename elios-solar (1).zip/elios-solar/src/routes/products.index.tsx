import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useLocale } from "../lib/locale-context";
import { INITIAL_PRODUCTS, type ProductItem } from "../lib/products-catalog";
import { PackagesComparison } from "../components/PackagesComparison";
import { QuoteModal } from "../components/QuoteModal";
import {
  ArrowRight,
  Sun,
  CheckCircle2,
  Filter,
  Sparkles,
  Info,
  Maximize2,
  Cpu,
  Layers,
} from "lucide-react";

export const Route = createFileRoute("/products/")({
  head: () => ({
    meta: [
      { title: "Solar Products & Equipment — Elios Solar Energy Bihar" },
      {
        name: "description",
        content:
          "Explore Tier-1 ALMM approved solar PV modules (HJT, TOPCon, Mono PERC, Flexible), on-grid inverters (1-phase, 3-phase, utility scale), and all-in-one solar kits by Elios Solar Energy.",
      },
      { property: "og:title", content: "Solar Products & Equipment — Elios Solar Energy Bihar" },
    ],
  }),
  component: ProductsPage,
});

type CategoryFilter = "all" | "pv_modules" | "inverters" | "solar_kits";

function ProductsPage() {
  const { isHi, t } = useLocale();
  const [activeTab, setActiveTab] = useState<"by_product" | "packages">("by_product");
  const [selectedCategory, setSelectedCategory] = useState<CategoryFilter>("all");
  const [selectedDetailProduct, setSelectedDetailProduct] = useState<ProductItem | null>(null);
  const [quoteOpen, setQuoteOpen] = useState(false);
  const [quoteProductTitle, setQuoteProductTitle] = useState("Solar Equipment");

  const openProductQuote = (name: string) => {
    setQuoteProductTitle(name);
    setQuoteOpen(true);
  };

  const filteredProducts =
    selectedCategory === "all"
      ? INITIAL_PRODUCTS
      : INITIAL_PRODUCTS.filter((p) => p.category === selectedCategory);

  return (
    <div className="w-full bg-background min-h-screen">
      {/* ======================================================== */}
      {/* 1. HERO SECTION (Waaree-inspired Clean Layout) */}
      {/* ======================================================== */}
      <section className="relative overflow-hidden border-b border-border bg-gradient-to-b from-[#0B2036]/5 via-background to-background py-14 sm:py-20">
        <div className="absolute inset-0 -z-10 opacity-30 pointer-events-none">
          <div className="absolute -top-32 right-1/4 h-96 w-96 rounded-full bg-primary/20 blur-3xl" />
          <div className="absolute top-1/2 left-10 h-72 w-72 rounded-full bg-secondary/15 blur-2xl" />
        </div>

        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 text-xs font-semibold text-foreground mb-4">
              <Sparkles className="h-3.5 w-3.5 text-primary" />
              <span>
                {isHi
                  ? "टियर-1 उपकरण एवं ऑल-इन-वन समाधान"
                  : "Tier-1 Equipment & All-in-One Solar Solutions"}
              </span>
            </div>
            <h1 className="font-display text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-foreground leading-[1.15]">
              {isHi
                ? "प्रत्येक छत के लिए स्मार्ट ऊर्जा समाधान"
                : "Smart Energy Solutions for Every Need, Every Scale"}
            </h1>
            <p className="mt-4 text-base sm:text-lg text-muted-foreground leading-relaxed">
              {isHi
                ? "उच्च-दक्षता वाले बायोफेशियल पीवी मॉड्यूल, स्मार्ट ऑन-ग्रिड इन्वर्टर और संपूर्ण आवासीय सोलर किट। सरकारी सब्सिडी (₹78,000 तक) और 30 वर्ष की परफॉर्मेंस वारंटी के साथ।"
                : "Explore our comprehensive portfolio of high-efficiency PV modules, smart grid-tied inverters, and turnkey all-in-one solar kits engineered for durability and peak generation across Bihar."}
            </p>

            {/* Top Switcher: By Product vs Care Packages */}
            <div className="mt-8 inline-flex rounded-2xl border border-border bg-card p-1.5 shadow-sm">
              <button
                onClick={() => {
                  setActiveTab("by_product");
                  setSelectedDetailProduct(null);
                }}
                className={`rounded-xl px-6 py-2.5 text-xs sm:text-sm font-bold transition-all ${
                  activeTab === "by_product"
                    ? "bg-primary text-primary-foreground shadow-md"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {isHi ? "उत्पाद श्रृंखला (By Product)" : "By Product (Catalog)"}
              </button>
              <button
                onClick={() => {
                  setActiveTab("packages");
                  setSelectedDetailProduct(null);
                }}
                className={`rounded-xl px-6 py-2.5 text-xs sm:text-sm font-bold transition-all ${
                  activeTab === "packages"
                    ? "bg-primary text-primary-foreground shadow-md"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {isHi ? "वार्षिक केयर पैकेज" : "Annual Care Packages"}
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* ======================================================== */}
      {/* 2. MAIN CATALOG CONTENT */}
      {/* ======================================================== */}
      {activeTab === "by_product" && (
        <section className="py-12 sm:py-16">
          <div className="mx-auto max-w-7xl px-4 sm:px-6">
            {/* Waaree-style Category Showcase Cards */}
            <div className="mb-12">
              <div className="text-center sm:text-left mb-6">
                <span className="text-xs font-bold uppercase tracking-wider text-primary">
                  {isHi ? "श्रेणी अनुसार खोजें" : "Explore by Category"}
                </span>
                <h2 className="font-display text-2xl sm:text-3xl font-bold text-foreground mt-1">
                  {isHi ? "हमारे प्रमुख सौर उपकरण" : "Explore Our Core Solar Categories"}
                </h2>
              </div>

              {/* 3 Waaree Category Hero Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* 1. PV Modules */}
                <div
                  onClick={() => setSelectedCategory("pv_modules")}
                  className={`group relative cursor-pointer overflow-hidden rounded-3xl border p-6 transition-all duration-300 ${
                    selectedCategory === "pv_modules"
                      ? "border-primary bg-primary/5 shadow-lg shadow-primary/10 ring-2 ring-primary"
                      : "border-border bg-card hover:border-primary/50 hover:shadow-md"
                  }`}
                >
                  <div className="h-44 w-full rounded-2xl bg-muted/50 overflow-hidden mb-5 relative flex items-center justify-center">
                    <img
                      src="https://vibe.filesafe.space/1792820769937918655/assets/edd7fdc6-f99c-4e66-82ca-4b30f178e6ab.jpg"
                      alt="PV Modules"
                      className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute top-3 left-3 rounded-full bg-[#0B2036]/80 px-3 py-1 text-[11px] font-bold text-white backdrop-blur-sm">
                      4 {isHi ? "प्रकार उपलब्ध" : "Variants"}
                    </div>
                  </div>
                  <h3 className="font-display text-xl font-extrabold text-foreground group-hover:text-primary transition-colors">
                    {isHi ? "सोलर पीवी मॉड्यूल" : "PV Modules"}
                  </h3>
                  <p className="mt-2 text-xs text-muted-foreground leading-relaxed">
                    {isHi
                      ? "एचजेटी (HJT), एन-टाइप टॉपकॉन, मोनो पर्क और अल्ट्रा-लाइटवेट फ्लेक्सिबल पैनल।"
                      : "Maximise energy output with high-efficiency HJT, N-Type TOPCon, Mono PERC, and bendable modules."}
                  </p>
                  <div className="mt-4 flex items-center gap-2 text-xs font-bold text-primary">
                    <span>{isHi ? "मॉड्यूल देखें" : "Explore PV Modules"}</span>
                    <ArrowRight className="h-3.5 w-3.5 group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>

                {/* 2. Inverters */}
                <div
                  onClick={() => setSelectedCategory("inverters")}
                  className={`group relative cursor-pointer overflow-hidden rounded-3xl border p-6 transition-all duration-300 ${
                    selectedCategory === "inverters"
                      ? "border-primary bg-primary/5 shadow-lg shadow-primary/10 ring-2 ring-primary"
                      : "border-border bg-card hover:border-primary/50 hover:shadow-md"
                  }`}
                >
                  <div className="h-44 w-full rounded-2xl bg-muted/50 overflow-hidden mb-5 relative flex items-center justify-center">
                    <img
                      src="https://vibe.filesafe.space/1792820769937918655/assets/a989c731-c4f4-4f0c-b9b6-43b75bec8220.png"
                      alt="Inverters"
                      className="h-full w-full object-contain p-3 group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute top-3 left-3 rounded-full bg-[#0B2036]/80 px-3 py-1 text-[11px] font-bold text-white backdrop-blur-sm">
                      5 {isHi ? "मॉडल उपलब्ध" : "Models Available"}
                    </div>
                  </div>
                  <h3 className="font-display text-xl font-extrabold text-foreground group-hover:text-primary transition-colors">
                    {isHi ? "ऑन-ग्रिड एवं यूटिलिटी इन्वर्टर" : "Inverters"}
                  </h3>
                  <p className="mt-2 text-xs text-muted-foreground leading-relaxed">
                    {isHi
                      ? "सिंगल-फेज घरेलू इन्वर्टर (1-6 kW), थ्री-फेज कमर्शियल (30-75 kW) और यूटिलिटी स्केल।"
                      : "Achieve peak conversion efficiency with single-phase residential and multi-MPPT industrial inverters."}
                  </p>
                  <div className="mt-4 flex items-center gap-2 text-xs font-bold text-primary">
                    <span>{isHi ? "इन्वर्टर देखें" : "Explore Inverters"}</span>
                    <ArrowRight className="h-3.5 w-3.5 group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>

                {/* 3. Solar Kits */}
                <div
                  onClick={() => setSelectedCategory("solar_kits")}
                  className={`group relative cursor-pointer overflow-hidden rounded-3xl border p-6 transition-all duration-300 ${
                    selectedCategory === "solar_kits"
                      ? "border-primary bg-primary/5 shadow-lg shadow-primary/10 ring-2 ring-primary"
                      : "border-border bg-card hover:border-primary/50 hover:shadow-md"
                  }`}
                >
                  <div className="h-44 w-full rounded-2xl bg-muted/50 overflow-hidden mb-5 relative flex items-center justify-center">
                    <img
                      src="https://vibe.filesafe.space/1792820769937918655/assets/ff251352-caa0-4eb2-bf5e-efd843a89aee.jpg"
                      alt="Solar Kits"
                      className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute top-3 left-3 rounded-full bg-emerald-600 px-3 py-1 text-[11px] font-bold text-white shadow-sm">
                      PM Surya Ghar {isHi ? "सब्सिडी पात्र" : "Eligible"}
                    </div>
                  </div>
                  <h3 className="font-display text-xl font-extrabold text-foreground group-hover:text-primary transition-colors">
                    {isHi ? "ऑल-इन-वन सोलर किट्स" : "All-in-One Solar Kits"}
                  </h3>
                  <p className="mt-2 text-xs text-muted-foreground leading-relaxed">
                    {isHi
                      ? "3.2 kW एवं 5 kW टर्नकी पैकेज जिसमें बायोफेशियल मॉड्यूल, इन्वर्टर और संपूर्ण वायरिंग किट शामिल है।"
                      : "Power your home or shop with pre-configured, complete DCR solar kits bundled with full balance-of-system."}
                  </p>
                  <div className="mt-4 flex items-center gap-2 text-xs font-bold text-primary">
                    <span>{isHi ? "सोलर किट्स देखें" : "Explore Solar Kits"}</span>
                    <ArrowRight className="h-3.5 w-3.5 group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              </div>
            </div>

            {/* Filter Pills */}
            <div className="flex flex-wrap items-center justify-between gap-4 border-y border-border py-4 mb-8">
              <div className="flex items-center gap-2">
                <Filter className="h-4 w-4 text-primary" />
                <span className="text-xs font-bold text-foreground">
                  {isHi ? "फ़िल्टर:" : "Filter By:"}
                </span>
                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={() => setSelectedCategory("all")}
                    className={`rounded-full px-4 py-1.5 text-xs font-bold transition-all ${
                      selectedCategory === "all"
                        ? "bg-primary text-primary-foreground shadow-sm"
                        : "bg-muted text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    {isHi ? "सभी उत्पाद (All)" : "All Products"} ({INITIAL_PRODUCTS.length})
                  </button>
                  <button
                    onClick={() => setSelectedCategory("pv_modules")}
                    className={`rounded-full px-4 py-1.5 text-xs font-bold transition-all ${
                      selectedCategory === "pv_modules"
                        ? "bg-primary text-primary-foreground shadow-sm"
                        : "bg-muted text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    {isHi ? "पीवी मॉड्यूल" : "PV Modules"}
                  </button>
                  <button
                    onClick={() => setSelectedCategory("inverters")}
                    className={`rounded-full px-4 py-1.5 text-xs font-bold transition-all ${
                      selectedCategory === "inverters"
                        ? "bg-primary text-primary-foreground shadow-sm"
                        : "bg-muted text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    {isHi ? "इन्वर्टर" : "Inverters"}
                  </button>
                  <button
                    onClick={() => setSelectedCategory("solar_kits")}
                    className={`rounded-full px-4 py-1.5 text-xs font-bold transition-all ${
                      selectedCategory === "solar_kits"
                        ? "bg-primary text-primary-foreground shadow-sm"
                        : "bg-muted text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    {isHi ? "सोलर किट्स" : "Solar Kits"}
                  </button>
                </div>
              </div>

              <div className="text-xs text-muted-foreground">
                {isHi
                  ? `${filteredProducts.length} उत्पाद प्रदर्शित`
                  : `Showing ${filteredProducts.length} verified products`}
              </div>
            </div>

            {/* Subsidized MNRE Compliance Note */}
            <div className="mb-10 rounded-2xl border border-primary/30 bg-primary/5 p-4 flex items-start gap-3.5 text-xs text-foreground">
              <Info className="h-5 w-5 text-primary shrink-0 mt-0.5" />
              <div className="leading-relaxed">
                <strong>
                  {isHi
                    ? "एमएनआरई एवं पीएम सूर्य घर अनुपालन सूचना:"
                    : "MNRE & PM Surya Ghar Compliance Guarantee:"}
                </strong>{" "}
                {isHi
                  ? "सभी सब्सिडी वाले आवासीय प्रोजेक्ट्स हेतु केवल केंद्र सरकार की एएलएमएम (ALMM) अनुमोदित सूची से ही टियर-1 सोलर मॉड्यूल लगाए जाते हैं। हमारे विशेषज्ञ संपूर्ण दस्तावेज़ीकरण स्वयं संभालते हैं।"
                  : "All residential projects eligible for central subsidy are supplied strictly with ALMM / MNRE approved Tier-1 DCR solar modules. Our EPC engineering team validates grid compliance with NBPDCL / SBPDCL before dispatch."}
              </div>
            </div>

            {/* Products Grid (Waaree-style Product Cards) */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredProducts.map((prod) => (
                <div
                  key={prod.id}
                  className="group relative flex flex-col justify-between overflow-hidden rounded-3xl border border-border bg-card shadow-sm hover:border-primary/60 hover:shadow-xl transition-all duration-300"
                >
                  <div>
                    {/* Image Area with Badge - opens full-description popup */}
                    <button
                      onClick={() => setSelectedDetailProduct(prod)}
                      className="block w-full text-left relative aspect-[16/11] bg-muted/40 overflow-hidden cursor-pointer"
                    >
                      <img
                        src={prod.image}
                        alt={isHi ? prod.nameHi : prod.nameEn}
                        className="h-full w-full object-contain p-3 group-hover:scale-105 transition-transform duration-500"
                      />
                      <div className="absolute top-3 left-3 rounded-full bg-[#0B2036]/85 px-3 py-1 text-[10px] font-extrabold uppercase tracking-wider text-white backdrop-blur-sm">
                        {prod.subcategory}
                      </div>
                      <div className="absolute top-3 right-3 rounded-full bg-primary px-3 py-1 text-[10px] font-extrabold text-[#0B2036] shadow-sm">
                        {isHi ? "कोटेशन पर उपलब्ध" : "Price on Request"}
                      </div>
                      <div className="absolute inset-0 bg-[#0B2036]/0 group-hover:bg-[#0B2036]/5 transition-colors" />
                    </button>

                    {/* Content Area */}
                    <div className="p-6">
                      <div className="text-[11px] font-bold uppercase tracking-wider text-primary mb-1">
                        {prod.sku}
                      </div>
                      <button
                        onClick={() => setSelectedDetailProduct(prod)}
                        className="block w-full text-left font-display text-lg font-bold text-foreground leading-snug group-hover:text-primary transition-colors cursor-pointer"
                      >
                        {isHi ? prod.nameHi : prod.nameEn}
                      </button>
                      <p className="mt-2 text-xs text-muted-foreground line-clamp-2 leading-relaxed">
                        {isHi ? prod.taglineHi : prod.taglineEn}
                      </p>

                      {/* Key Specs Pills */}
                      <div className="mt-4 grid grid-cols-2 gap-2 border-t border-border/60 pt-3">
                        {prod.specs.slice(0, 4).map((spec, idx) => (
                          <div key={idx} className="rounded-xl bg-muted/50 p-2 text-[11px]">
                            <div className="text-[10px] text-muted-foreground">{spec.label}</div>
                            <div className="font-bold text-foreground truncate">{spec.value}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Actions Bar */}
                  <div className="p-6 pt-0 flex gap-2.5">
                    <button
                      onClick={() => setSelectedDetailProduct(prod)}
                      className="flex-1 inline-flex items-center justify-center gap-1.5 rounded-xl border border-border bg-background py-2.5 text-xs font-bold text-foreground hover:bg-muted hover:border-primary/40 transition-all text-center"
                    >
                      <Maximize2 className="h-3.5 w-3.5 text-primary" />
                      <span>{isHi ? "पूरा विवरण देखें" : "View Full Details"}</span>
                    </button>
                    <button
                      onClick={() => openProductQuote(isHi ? prod.nameHi : prod.nameEn)}
                      className="flex-1 inline-flex items-center justify-center gap-1.5 rounded-xl bg-primary py-2.5 text-xs font-bold text-primary-foreground hover:bg-primary-hover shadow-sm transition-all"
                    >
                      <span>{t("requestQuote")}</span>
                      <ArrowRight className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ======================================================== */}
      {/* 3. PACKAGES TAB */}
      {/* ======================================================== */}
      {activeTab === "packages" && (
        <section className="py-12 sm:py-16">
          <div className="mx-auto max-w-7xl px-4 sm:px-6">
            <PackagesComparison onSelectPackage={(pkg) => openProductQuote(pkg)} />
          </div>
        </section>
      )}

      {/* ======================================================== */}
      {/* 4. PRODUCT DETAIL MODAL (Waaree Page Layout replica) */}
      {/* ======================================================== */}
      {selectedDetailProduct && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-md animate-in fade-in-20"
          onClick={() => setSelectedDetailProduct(null)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="relative w-full max-w-4xl max-h-[90vh] overflow-y-auto rounded-3xl border border-border bg-card p-6 sm:p-10 shadow-2xl"
          >
            {/* Close Button */}
            <button
              onClick={() => setSelectedDetailProduct(null)}
              className="absolute right-5 top-5 rounded-full bg-muted/80 p-2 text-muted-foreground hover:bg-muted hover:text-foreground transition-colors z-10"
            >
              ✕
            </button>

            {/* Modal Content Grid */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
              {/* Left Column: Product Image & Badges */}
              <div className="md:col-span-5 flex flex-col">
                <div className="relative aspect-[4/3] rounded-2xl bg-muted/40 overflow-hidden border border-border">
                  <img
                    src={selectedDetailProduct.image}
                    alt={isHi ? selectedDetailProduct.nameHi : selectedDetailProduct.nameEn}
                    className="h-full w-full object-contain p-4"
                  />
                  <div className="absolute top-3 left-3 rounded-full bg-[#0B2036]/90 px-3 py-1 text-[11px] font-bold text-white">
                    {selectedDetailProduct.subcategory}
                  </div>
                  <div className="absolute top-3 right-3 rounded-full bg-primary px-3 py-1 text-[11px] font-bold text-[#0B2036] shadow-sm">
                    {isHi ? "कोटेशन पर उपलब्ध" : "Price on Request"}
                  </div>
                </div>

                {/* SKU & Brand Assurance */}
                <div className="mt-4 rounded-2xl bg-primary/5 border border-primary/20 p-4 space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">
                      {isHi ? "मॉडल कोड:" : "Model SKU:"}
                    </span>
                    <span className="font-bold text-foreground">{selectedDetailProduct.sku}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">
                      {isHi ? "वारंटी:" : "Warranty Assurance:"}
                    </span>
                    <span className="font-bold text-emerald-600">30 Years Performance</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">
                      {isHi ? "मान्यता:" : "Certification:"}
                    </span>
                    <span className="font-bold text-foreground">MNRE / ALMM / BIS</span>
                  </div>
                </div>

                <button
                  onClick={() => {
                    openProductQuote(
                      isHi ? selectedDetailProduct.nameHi : selectedDetailProduct.nameEn,
                    );
                    setSelectedDetailProduct(null);
                  }}
                  className="mt-5 w-full inline-flex items-center justify-center gap-2 rounded-xl bg-primary py-3 text-sm font-extrabold text-primary-foreground hover:bg-primary-hover shadow-md transition-all"
                >
                  <Sun className="h-4 w-4" />
                  <span>{t("requestQuote")}</span>
                  <ArrowRight className="h-4 w-4" />
                </button>
              </div>

              {/* Right Column: Detailed Product Specs & Features */}
              <div className="md:col-span-7 flex flex-col justify-between">
                <div>
                  <div className="text-xs font-bold uppercase tracking-wider text-primary mb-1">
                    {selectedDetailProduct.subcategory}
                  </div>
                  <h2 className="font-display text-2xl sm:text-3xl font-extrabold text-foreground leading-tight">
                    {isHi ? selectedDetailProduct.nameHi : selectedDetailProduct.nameEn}
                  </h2>
                  <p className="mt-2 text-sm text-primary font-semibold">
                    {isHi ? selectedDetailProduct.taglineHi : selectedDetailProduct.taglineEn}
                  </p>

                  <p className="mt-3 text-xs sm:text-sm text-muted-foreground leading-relaxed">
                    {isHi
                      ? selectedDetailProduct.descriptionHi
                      : selectedDetailProduct.descriptionEn}
                  </p>

                  {/* Key Features List */}
                  <div className="mt-5">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-foreground mb-3 flex items-center gap-1.5">
                      <Layers className="h-3.5 w-3.5 text-primary" />
                      <span>{isHi ? "प्रमुख विशेषताएं" : "Key Engineering Highlights"}</span>
                    </h4>
                    <ul className="space-y-2">
                      {(isHi
                        ? selectedDetailProduct.featuresHi
                        : selectedDetailProduct.featuresEn
                      ).map((feat, i) => (
                        <li key={i} className="flex items-start gap-2 text-xs text-foreground">
                          <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
                          <span>{feat}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Technical Specifications Table */}
                  <div className="mt-6">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-foreground mb-3 flex items-center gap-1.5">
                      <Cpu className="h-3.5 w-3.5 text-primary" />
                      <span>{isHi ? "तकनीकी विवरण" : "Technical Specifications"}</span>
                    </h4>
                    <div className="grid grid-cols-2 gap-2.5">
                      {selectedDetailProduct.specs.map((sp, i) => (
                        <div
                          key={i}
                          className="rounded-xl border border-border bg-muted/40 p-2.5 text-xs"
                        >
                          <div className="text-[10px] text-muted-foreground">{sp.label}</div>
                          <div className="font-bold text-foreground mt-0.5">{sp.value}</div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Ideal Applications */}
                  <div className="mt-5 rounded-2xl bg-muted/60 p-3.5 text-xs">
                    <span className="font-bold text-foreground">
                      {isHi ? "उपयुक्त अनुप्रयोग: " : "Ideal Applications: "}
                    </span>
                    <span className="text-muted-foreground">
                      {isHi
                        ? selectedDetailProduct.applicationsHi
                        : selectedDetailProduct.applicationsEn}
                    </span>
                  </div>

                  {/* Visit full product page link */}
                  <div className="mt-5 border-t border-border pt-4">
                    <Link
                      to="/products/$productSlug"
                      params={{ productSlug: selectedDetailProduct.slug }}
                      className="inline-flex items-center gap-1.5 text-xs font-bold text-primary hover:underline"
                    >
                      <span>{isHi ? "पूरा उत्पाद पेज खोलें" : "Open full product page"}</span>
                      <ArrowRight className="h-3.5 w-3.5" />
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Quote Modal */}
      <QuoteModal
        isOpen={quoteOpen}
        onClose={() => setQuoteOpen(false)}
        initialService="Products and Packages"
        initialMessage={quoteProductTitle}
      />
    </div>
  );
}
