import { createFileRoute, Link } from "@tanstack/react-router";
import { Scale, FileText, AlertCircle, CheckCircle2, ShieldCheck, Zap } from "lucide-react";

export const Route = createFileRoute("/terms")({
  head: () => ({
    meta: [
      { title: "Terms & Conditions — Elios Solar Energy" },
      {
        name: "description",
        content:
          "Terms of Use and Legal Information for Elios Solar Energy website, solar EPC services, estimates, and annual maintenance packages.",
      },
      { property: "og:title", content: "Terms & Conditions — Elios Solar Energy" },
      {
        property: "og:description",
        content:
          "Terms governing the use of Elios Solar Energy platform, intellectual property, disclaimers, and annual solar care package terms.",
      },
    ],
  }),
  component: TermsPage,
});

function TermsPage() {
  return (
    <div className="bg-background text-foreground min-h-screen py-12 px-4 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-4xl">
        {/* Header Banner */}
        <div className="rounded-3xl bg-secondary text-secondary-foreground p-8 sm:p-12 mb-10 border border-border/20 shadow-xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-96 h-96 bg-primary/10 rounded-full blur-3xl pointer-events-none" />
          <div className="relative z-10">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/20 text-primary-foreground text-xs font-semibold mb-4">
              <Scale className="h-4 w-4" />
              <span>Terms of Use — Important Legal Information</span>
            </div>
            <h1 className="font-display text-3xl sm:text-5xl font-extrabold text-white tracking-tight mb-4">
              Terms & Conditions
            </h1>
            <p className="text-secondary-foreground/80 text-sm sm:text-base max-w-2xl leading-relaxed">
              Carefully read these Terms of Use before using this Website. Your access to, and use
              of, the Website and its content is conditioned upon your acceptance of, and compliance
              with these terms in full.
            </p>
            <div className="mt-6 flex flex-wrap gap-4 text-xs text-secondary-foreground/70">
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="h-4 w-4 text-primary" /> Effective: October 2026
              </span>
              <span className="flex items-center gap-1.5">
                <ShieldCheck className="h-4 w-4 text-primary" /> Governed by Laws of India
              </span>
            </div>
          </div>
        </div>

        {/* Table of Contents */}
        <div className="rounded-2xl bg-card border border-border p-6 mb-10 shadow-sm">
          <h2 className="font-display text-lg font-bold text-foreground mb-3 flex items-center gap-2">
            <FileText className="h-5 w-5 text-primary" />
            <span>Table of Contents</span>
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm text-muted-foreground">
            <a href="#ip-rights" className="hover:text-primary transition-colors">
              1. Intellectual Property Rights & Usage of Content
            </a>
            <a href="#other-terms" className="hover:text-primary transition-colors">
              2. Other Terms and Notices May Apply
            </a>
            <a href="#other-ip" className="hover:text-primary transition-colors">
              3. Other Intellectual Property Rights
            </a>
            <a href="#disclaimers" className="hover:text-primary transition-colors">
              4. Disclaimers
            </a>
            <a href="#submitting-info" className="hover:text-primary transition-colors">
              5. Submitting Information to Elios Solar Energy
            </a>
            <a href="#registration" className="hover:text-primary transition-colors">
              6. Registration
            </a>
            <a href="#code-of-conduct" className="hover:text-primary transition-colors">
              7. Code of Conduct
            </a>
            <a href="#info-provided" className="hover:text-primary transition-colors">
              8. Information Provided by Elios Solar Energy
            </a>
            <a href="#packages" className="hover:text-primary transition-colors">
              9. Offer Terms & Annual Solar Care Packages
            </a>
          </div>
        </div>

        {/* Terms Body */}
        <div className="prose prose-slate max-w-none space-y-10 text-foreground/90 text-sm sm:text-base leading-relaxed">
          <p className="text-base font-medium leading-relaxed bg-muted/40 p-5 rounded-xl border border-border/50">
            Carefully read these Terms of Use before using this Website. Your access to, and use of,
            the Website and its content and materials is conditioned upon your acceptance of, and
            compliance with these terms in full. If you do not accept these terms, you should leave
            the Website immediately and cease any further use of any content and materials you have
            obtained from the Website.
          </p>

          {/* Section 1 */}
          <section id="ip-rights" className="scroll-mt-24 border-t border-border/60 pt-8">
            <h2 className="font-display text-xl font-bold text-foreground mb-3">
              1. Intellectual Property Rights and Usage of Content
            </h2>
            <p>
              All intellectual property rights of the content on this Website including, but not
              limited to, text, photographs, rooftop 3D illustrations, designs, logos, calculators,
              and images ("Content") vests with Elios Solar Energy, unless otherwise indicated.
              Elios Solar Energy's intellectual property rights are protected by Indian laws and
              international copyright treaties.
            </p>
            <p className="mt-3">
              Except as expressly permitted by this Website or applicable laws, other uses of the
              Content including, but not limited to, duplication, distribution, re-posting, sending,
              deleting, editing, or adapting are strictly prohibited without prior written
              permission of Elios Solar Energy.
            </p>
            <p className="mt-3">
              No part of the Content shall be made available as part of another Website. This
              Website and the Content shall not be stored (in whole or part) in a database of any
              kind, or used to construct a database or to distribute a database containing this
              Website or Content.
            </p>
          </section>

          {/* Section 2 */}
          <section id="other-terms" className="scroll-mt-24 border-t border-border/60 pt-8">
            <h2 className="font-display text-xl font-bold text-foreground mb-3">
              2. Other Terms and Notices May Apply
            </h2>
            <p>
              Additional terms and conditions will apply to business transactions, rooftop EPC
              contracts, site engineering assessments, or annual solar maintenance packages offered
              by Elios Solar Energy via this Website.
            </p>
            <p className="mt-3">
              Please note that any solar product, rooftop engineering process, or technology
              described in the materials on this Website may be the subject of other intellectual
              property rights reserved by Elios Solar Energy or its component technology partners
              and are not licensed hereunder.
            </p>
          </section>

          {/* Section 3 */}
          <section id="other-ip" className="scroll-mt-24 border-t border-border/60 pt-8">
            <h2 className="font-display text-xl font-bold text-foreground mb-3">
              3. Other Intellectual Property Rights
            </h2>
            <p>
              Elios Solar Energy and the Elios Solar Energy logo are trademarks of Elios Solar
              Energy. Other logos (such as tier-1 solar module or inverter manufacturer partner
              logos) displayed on this Website belong to their respective trademark owners and
              associates.
            </p>
          </section>

          {/* Section 4 */}
          <section id="disclaimers" className="scroll-mt-24 border-t border-border/60 pt-8">
            <h2 className="font-display text-xl font-bold text-foreground mb-3">4. Disclaimers</h2>
            <div className="bg-destructive/10 border border-destructive/20 p-5 rounded-xl text-xs sm:text-sm font-mono leading-relaxed uppercase text-foreground mb-4">
              THE INFORMATION CONTAINED IN THIS WEB SITE IS PROVIDED TO YOU "AS IS," FOR YOUR
              INFORMATIONAL PURPOSES ONLY, WITHOUT ANY REPRESENTATION OR WARRANTY OF ACCURACY OR
              COMPLETENESS OF INFORMATION OR OTHER WARRANTY OF ANY KIND INCLUDING BUT NOT LIMITED
              TO, ANY IMPLIED WARRANTY OF QUALITY, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
              OR NON-INFRINGEMENT.
            </div>
            <p>
              IN NO EVENT WILL ELIOS SOLAR ENERGY BE LIABLE TO ANY PARTY FOR ANY DIRECT, INDIRECT,
              INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES FOR USE OF THIS WEB SITE OR RELIANCE UPON
              ANY INFORMATION OR MATERIAL ACCESSED VIA THIS WEB SITE INCLUDING, BUT NOT LIMITED TO,
              DAMAGES ARISING FROM LOSS OF PROFITS, BUSINESS INTERRUPTION, OR LOSS OF DATA, TO THE
              FULLEST EXTENT ALLOWABLE BY LAW.
            </p>
            <p className="mt-3">
              The material on this Website could contain technical inaccuracies or typographical
              errors. Information may be updated or modified without prior notice. Solar
              calculators, financial payback estimates, and central PM Surya Ghar subsidy amounts
              are indicative figures ("up to") dependent on actual DISCOM tariff rules, roof shadow
              inspection, eligibility criteria, and government policy in force.
            </p>
          </section>

          {/* Section 5 */}
          <section id="submitting-info" className="scroll-mt-24 border-t border-border/60 pt-8">
            <h2 className="font-display text-xl font-bold text-foreground mb-3">
              5. Submitting Information to Elios Solar Energy
            </h2>
            <p>
              Elios Solar Energy does not want to receive confidential or proprietary information
              from you through this Website unless you have a separate written agreement related to
              the sharing of such information. Any project feedback or general inquiries sent
              electronically shall be deemed NON-CONFIDENTIAL unless governed by an executed
              non-disclosure agreement.
            </p>
          </section>

          {/* Section 6 */}
          <section id="registration" className="scroll-mt-24 border-t border-border/60 pt-8">
            <h2 className="font-display text-xl font-bold text-foreground mb-3">6. Registration</h2>
            <p>
              Some areas of the Website (e.g. customer account dashboard or admin portal) may
              require you to register. When registering, you agree to:
            </p>
            <ul className="list-disc pl-5 space-y-2 mt-2">
              <li>
                Provide accurate, current, and complete information as prompted by our registration
                form.
              </li>
              <li>
                Maintain and update your account information to keep it accurate, current, and
                complete.
              </li>
              <li>Maintain the strict confidentiality of your login credentials and password.</li>
            </ul>
          </section>

          {/* Section 7 */}
          <section id="code-of-conduct" className="scroll-mt-24 border-t border-border/60 pt-8">
            <h2 className="font-display text-xl font-bold text-foreground mb-3">
              7. Code of Conduct
            </h2>
            <p>While using the Website, you agree NOT to:</p>
            <ul className="list-disc pl-5 space-y-2 mt-2">
              <li>
                Restrict or inhibit any other visitor from using the Website, including by means of
                hacking or defacing.
              </li>
              <li>Use the Website or Content for any unlawful or unauthorized purpose.</li>
              <li>
                Express or imply that any statements you make are endorsed by Elios Solar Energy
                without prior written consent.
              </li>
              <li>Transmit any software, worms, viruses, or destructive code.</li>
              <li>
                Modify, adapt, sublicense, translate, sell, reverse engineer, or disassemble any
                portion of the Website.
              </li>
              <li>
                Remove any copyright, trademark, or proprietary rights notices contained on the
                Website.
              </li>
            </ul>
          </section>

          {/* Section 8 */}
          <section id="info-provided" className="scroll-mt-24 border-t border-border/60 pt-8">
            <h2 className="font-display text-xl font-bold text-foreground mb-3">
              8. Information Provided by Elios Solar Energy
            </h2>
            <p>
              Although Elios Solar Energy strives to provide Content that is both useful and
              accurate, solar policy regulations and tariff structures change frequently. In the
              event that a situation arises in which the Website's accuracy is in question, please
              contact us so we can address your concerns.
            </p>
          </section>

          {/* Section 9 - Annual Care Packages & Offer Terms */}
          <section id="packages" className="scroll-mt-24 border-t border-border/60 pt-8">
            <div className="rounded-2xl bg-card border border-primary/30 p-6 shadow-md">
              <h2 className="font-display text-xl font-bold text-primary mb-3 flex items-center gap-2">
                <Zap className="h-5 w-5" />
                <span>9. Offer Terms & Annual Solar Care Packages</span>
              </h2>
              <p className="text-sm leading-relaxed text-foreground/90">
                Elios Solar Energy offers annual cleaning, health-check, and monitoring
                subscriptions for rooftop solar installations (Silver, Gold, and Platinum Care
                Tiers):
              </p>
              <ul className="list-disc pl-5 space-y-2 mt-3 text-sm text-muted-foreground">
                <li>
                  Package prices are listed per year ("per year subscription") and cover scheduled
                  maintenance, cleaning visits, and remote monitoring according to the selected
                  tier.
                </li>
                <li>
                  Limited-time promotional discount prices are subject to offer availability and may
                  end upon notice or on the specified offer end date.
                </li>
                <li>
                  Subsidy processing assistance is provided as part of our turnkey EPC services for
                  eligible residential projects under government scheme guidelines.
                </li>
                <li>
                  Annual packages do not cover physical damage caused by external force majeure,
                  lightning strikes without proper earthing installation, or un-authorized
                  third-party tampering.
                </li>
              </ul>
            </div>
          </section>
        </div>

        {/* Bottom Callout */}
        <div className="mt-12 text-center border-t border-border pt-8 text-xs text-muted-foreground">
          Questions regarding legal terms?{" "}
          <Link to="/contact" className="text-primary hover:underline font-semibold">
            Contact Elios Legal Team
          </Link>{" "}
          or read our{" "}
          <Link to="/privacy" className="text-primary hover:underline font-semibold">
            Privacy Policy
          </Link>
          .
        </div>
      </div>
    </div>
  );
}
