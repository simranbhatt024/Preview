import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useLocale } from "../lib/locale-context";
import {
  Briefcase,
  Building,
  ShieldAlert,
  CheckCircle,
  ArrowRight,
  ShieldCheck,
  Truck,
  GraduationCap,
} from "lucide-react";
import { submitLeadToCRM, CRM_CUSTOM_FIELDS } from "../lib/crm-tracking";
import { redirectToWhatsApp } from "../lib/whatsapp";
import { ASSETS } from "../lib/constants";

export const Route = createFileRoute("/become-a-partner/solar-body-program")({
  head: () => ({
    meta: [
      { title: "Solar Body Franchise Program — Elios Solar Energy Bihar" },
      {
        name: "description",
        content:
          "Partner as an authorized franchise dealer or district solar entrepreneur with Elios Solar Energy across Bihar.",
      },
      { property: "og:title", content: "Solar Body Franchise — Elios Solar Energy Bihar" },
    ],
  }),
  component: SolarBodyProgramPage,
});

const HERO_IMG =
  "https://vibe.filesafe.space/1792820769937918655/assets/a4488703-50b0-4bb3-9937-f36065e17417.png";

const BENEFITS = [
  {
    icon: Building,
    titleEn: "Authorized District Representation",
    titleHi: "ब्रांड और डीलरशिप अधिकार",
    descEn:
      "Operate as the recognized solar EPC technology destination in your territory under the Elios brand.",
    descHi: "आपके जिले में एलियोस सोलर एनर्जी के आधिकारिक प्रतिनिधि के रूप में संचालन।",
    img: "https://vibe.filesafe.space/1792820769937918655/assets/8ee3c1e0-1d38-4a69-a118-94704164b4e5.png",
    altEn:
      "A premium authorized solar franchise dealership storefront in a Bihar town with rooftop solar panels and orange and navy branding at golden hour",
    altHi:
      "बिहार के एक कस्बे में रूफटॉप सोलर पैनलों और नारंगी-नेवी ब्रांडिंग के साथ एक प्रीमियम अधिकृत सोलर फ्रेंचाइजी डीलरशिप स्टोरफ्रंट, सुनहरी शाम में",
  },
  {
    icon: ShieldCheck,
    titleEn: "Brand Backing & Business Credibility",
    titleHi: "ब्रांड समर्थन एवं विश्वसनीयता",
    descEn:
      "Leverage the Elios reputation, marketing support, and established customer trust across Bihar.",
    descHi:
      "एलियोस की साख, मार्केटिंग सहायता और पूरे बिहार में स्थापित ग्राहक विश्वास का लाभ उठाएँ।",
    img: "https://vibe.filesafe.space/1792820769937918655/assets/4f4a4af3-4354-4e43-aaf9-6508454bf0fe.png",
    altEn:
      "A confident solar business owner standing proudly in front of his authorized solar dealership store in a Bihar district town at golden hour",
    altHi:
      "बिहार के एक जिला कस्बे में अपने अधिकृत सोलर डीलरशिप स्टोर के सामने गर्व से खड़े एक आत्मविश्वासी सोलर व्यवसायी, सुनहरी शाम में",
  },
  {
    icon: Truck,
    titleEn: "Direct Supply Chain & Training",
    titleHi: "सीधी आपूर्ति और ट्रेनिंग",
    descEn:
      "Direct procurement of Tier-1 solar panels, inverters, and structures with technical DISCOM engineering training.",
    descHi: "Tier-1 सोलर पैनल, इन्वर्टर और स्ट्रक्चर की सीधी आपूर्ति तथा टीम का तकनीकी प्रशिक्षण।",
    img: "https://vibe.filesafe.space/1792820769937918655/assets/cc793045-f705-4f1b-b0eb-7220d54f9906.png",
    altEn:
      "A well-organized solar equipment supply warehouse with rows of Tier-1 solar panels and inverters, technicians in navy uniforms in a training session, bright industrial lighting with warm tones",
    altHi:
      "सुव्यवस्थित सोलर उपकरण आपूर्ति गोदाम, Tier-1 सोलर पैनल और इन्वर्टर की पंक्तियों के साथ, नेवी यूनिफॉर्म में तकनीशियन प्रशिक्षण सत्र में, गर्म टोन के साथ उज्ज्वल औद्योगिक प्रकाश",
  },
];

function SolarBodyProgramPage() {
  const { isHi } = useLocale();
  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");
  const [district, setDistrict] = useState("Patna");
  const [investmentRange, setInvestmentRange] = useState("₹2 Lakhs - ₹5 Lakhs");
  const [submitted, setSubmitted] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg("");

    const cleanPhone = phone.replace(/\D/g, "");
    if (!/^[6-9]\d{9}$/.test(cleanPhone)) {
      setErrorMsg(
        isHi
          ? "कृपया 10 अंकों का मान्य भारतीय मोबाइल नंबर दर्ज करें।"
          : "Please enter a valid 10-digit Indian mobile number.",
      );
      return;
    }

    // Save lead locally + push to CRM (non-blocking).
    submitLeadToCRM({
      formId: "elios-solar-body-franchise",
      formName: "Solar Body Franchise Application",
      fullName,
      phone: cleanPhone,
      city: district,
      serviceNeeded: "Partnership",
      source: "solar_body",
      message: `Investment capacity: ${investmentRange}`,
      custom: {
        [CRM_CUSTOM_FIELDS.targetDistrict]: {
          value: district,
          label: "Target District",
        },
        [CRM_CUSTOM_FIELDS.investmentCapacity]: {
          value: investmentRange,
          label: "Investment Capacity",
        },
      },
    });

    setSubmitted(true);
    const waText = `Hello Elios Solar Energy,\n\nI want to apply for the *Solar Body Franchise Partner Program* in Bihar:\n\n*Name:* ${fullName}\n*Phone:* ${cleanPhone}\n*District:* ${district}\n*Investment Range:* ${investmentRange}`;
    redirectToWhatsApp(waText);
  };

  return (
    <div className="w-full bg-background py-12 sm:py-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        {/* Hero */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center mb-14">
          <div className="text-center lg:text-left">
            <span className="text-xs font-bold uppercase tracking-wider text-primary">
              {isHi ? "फ्रेंचाइजी एवं डीलरशिप" : "Franchise & Dealership Network"}
            </span>
            <h1 className="mt-2 font-display text-3xl sm:text-5xl font-extrabold text-foreground leading-tight">
              {isHi ? "एलियोस सोलर बॉडी प्रोग्राम" : "Elios Solar Body Program"}
            </h1>
            <p className="mt-4 text-base text-muted-foreground max-w-xl mx-auto lg:mx-0">
              {isHi
                ? "बिहार के जिलों में अधिकृत सोलर डीलर या उद्यमी बनें। संपूर्ण तकनीकी आपूर्ति, ब्रांडिंग और डिस्कॉम सहायता।"
                : "Become an authorized Elios Solar district franchise partner in Bihar with brand backing, supply access, and technical EPC guidance."}
            </p>
            <div className="mt-6 flex flex-wrap gap-3 justify-center lg:justify-start">
              <a
                href="#register"
                className="inline-flex items-center rounded-xl bg-primary px-5 py-3 text-sm font-bold text-primary-foreground shadow-sm hover:bg-primary-hover transition-all active:scale-95"
              >
                {isHi ? "फ्रेंचाइजी आवेदन करें" : "Apply for Franchise"}
              </a>
              <a
                href="#benefits"
                className="inline-flex items-center rounded-xl border border-border bg-card px-5 py-3 text-sm font-semibold text-foreground hover:border-primary/40 transition-all"
              >
                {isHi ? "कार्यक्रम के लाभ देखें" : "See Program Benefits"}
              </a>
            </div>
          </div>
          <div className="relative rounded-3xl overflow-hidden border border-border shadow-xl">
            <img
              src={HERO_IMG}
              alt={
                isHi
                  ? "बिहार में अधिकृत सोलर फ्रेंचाइजी डीलरशिप नेटवर्क, ब्रांडेड सोलर स्टोरफ्रंट और रूफटॉप सोलर पैनलों के साथ, सुनहरी शाम में"
                  : "An authorized solar franchise dealership network across Bihar with branded solar store storefronts and rooftop solar panels at golden hour"
              }
              className="w-full h-64 sm:h-80 lg:h-96 object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-navy-premium/70 via-navy-premium/10 to-transparent pointer-events-none" />
            {/* Elios brand badge overlay */}
            <div className="absolute top-4 left-4 flex items-center gap-2 rounded-xl bg-cream-premium/95 px-3 py-2 shadow-lg ring-1 ring-primary/20">
              <img
                src={ASSETS.logo}
                alt="Elios Solar Energy logo"
                className="h-7 w-auto object-contain"
              />
            </div>
            <div className="absolute bottom-4 left-4 right-4 flex items-end justify-between gap-3">
              <span className="rounded-lg bg-navy-premium/85 px-3 py-1.5 text-xs font-semibold text-cream-premium backdrop-blur-sm">
                {isHi ? "अधिकृत एलियोस फ्रेंचाइजी नेटवर्क" : "Authorized Elios Franchise Network"}
              </span>
              <span className="rounded-lg bg-primary/90 px-3 py-1.5 text-xs font-bold text-primary-foreground shadow">
                {isHi ? "बिहार" : "Bihar"}
              </span>
            </div>
          </div>
        </div>

        <div
          id="benefits"
          className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start max-w-6xl mx-auto"
        >
          {/* Program Highlights with images */}
          <div className="lg:col-span-5 space-y-6">
            <h3 className="font-display text-xl font-bold text-foreground px-1">
              {isHi ? "फ्रेंचाइजी पार्टनर लाभ" : "Why Become a Franchise Partner?"}
            </h3>
            {BENEFITS.map((b) => {
              const Icon = b.icon;
              return (
                <div
                  key={b.titleEn}
                  className="group rounded-2xl border border-border bg-card overflow-hidden flex flex-col transition-all duration-300 hover:shadow-xl hover:-translate-y-1 hover:border-primary/40"
                >
                  <div className="relative aspect-[16/10] overflow-hidden">
                    <img
                      src={b.img}
                      alt={isHi ? b.altHi : b.altEn}
                      loading="lazy"
                      className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-navy-premium/70 via-navy-premium/10 to-transparent pointer-events-none" />
                    <div className="absolute top-3 left-3 h-10 w-10 rounded-xl bg-primary/90 text-primary-foreground flex items-center justify-center shadow-lg ring-2 ring-white/20">
                      <Icon className="h-5 w-5" />
                    </div>
                  </div>
                  <div className="p-5 flex-1 flex flex-col">
                    <h4 className="font-display text-base font-bold text-foreground mb-1.5 leading-snug">
                      {isHi ? b.titleHi : b.titleEn}
                    </h4>
                    <p className="text-xs text-muted-foreground leading-relaxed flex-1">
                      {isHi ? b.descHi : b.descEn}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Registration Form */}
          <div
            id="register"
            className="lg:col-span-7 rounded-3xl border border-border bg-card p-6 sm:p-8 shadow-sm lg:sticky lg:top-24"
          >
            {submitted ? (
              <div className="flex flex-col items-center py-10 text-center">
                <CheckCircle className="h-14 w-14 text-success animate-bounce" />
                <h3 className="mt-3 font-display text-xl font-bold text-foreground">
                  {isHi ? "आवेदन प्राप्त हुआ!" : "Franchise Application Received!"}
                </h3>
                <p className="mt-2 text-xs text-muted-foreground">
                  {isHi ? "आपको व्हाट्सएप पर भेजा जा रहा है..." : "Redirecting you to WhatsApp..."}
                </p>
              </div>
            ) : (
              <div>
                <h3 className="font-display text-xl font-bold text-foreground mb-1">
                  {isHi ? "फ्रेंचाइजी पूछताछ फॉर्म" : "Franchise Application Form"}
                </h3>
                <p className="text-xs text-muted-foreground mb-6">
                  {isHi
                    ? "जानकारी जमा करने के बाद आप सीधे हमारे फ्रेंचाइजी डेस्क से व्हाट्सएप पर बात कर सकते हैं।"
                    : "Fill your details to connect directly with our partnership leadership team on WhatsApp."}
                </p>

                {errorMsg && (
                  <div className="mb-4 flex items-center gap-2 rounded-lg bg-destructive/10 p-3 text-xs text-destructive">
                    <ShieldAlert className="h-4 w-4 shrink-0" />
                    <span>{errorMsg}</span>
                  </div>
                )}

                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-foreground mb-1">
                      {isHi ? "पूरा नाम" : "Full Name"} *
                    </label>
                    <input
                      type="text"
                      required
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder="e.g. Rakesh Kumar Singh"
                      className="w-full rounded-xl border border-border bg-background px-4 py-2.5 text-sm text-foreground focus:border-primary focus:outline-none"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-foreground mb-1">
                        {isHi ? "मोबाइल नंबर" : "Phone Number"} *
                      </label>
                      <input
                        type="tel"
                        required
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="9876543210"
                        className="w-full rounded-xl border border-border bg-background px-4 py-2.5 text-sm text-foreground focus:border-primary focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-foreground mb-1">
                        {isHi ? "वांछित जिला / क्षेत्र" : "Target District in Bihar"} *
                      </label>
                      <input
                        type="text"
                        required
                        value={district}
                        onChange={(e) => setDistrict(e.target.value)}
                        placeholder="e.g. Patna, Nalanda, Begusarai"
                        className="w-full rounded-xl border border-border bg-background px-4 py-2.5 text-sm text-foreground focus:border-primary focus:outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-foreground mb-1">
                      {isHi ? "निवेश क्षमता" : "Investment Capacity"}
                    </label>
                    <select
                      value={investmentRange}
                      onChange={(e) => setInvestmentRange(e.target.value)}
                      className="w-full rounded-xl border border-border bg-background px-4 py-2.5 text-sm text-foreground focus:border-primary focus:outline-none"
                    >
                      <option value="₹2 Lakhs - ₹5 Lakhs">₹2 Lakhs – ₹5 Lakhs</option>
                      <option value="₹5 Lakhs - ₹10 Lakhs">₹5 Lakhs – ₹10 Lakhs</option>
                      <option value="₹10 Lakhs+">₹10 Lakhs and above</option>
                    </select>
                  </div>

                  <button
                    type="submit"
                    className="w-full rounded-xl bg-primary py-3 text-sm font-bold text-primary-foreground shadow-sm hover:bg-primary-hover transition-all active:scale-95"
                  >
                    <span>{isHi ? "फ्रेंचाइजी आवेदन भेजें" : "Apply for Franchise"}</span>
                  </button>
                </form>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
