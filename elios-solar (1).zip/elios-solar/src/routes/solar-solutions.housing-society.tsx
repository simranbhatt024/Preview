import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useLocale } from "../lib/locale-context";
import { ASSETS } from "../lib/constants";
import { QuoteModal } from "../components/QuoteModal";
import {
  Building2,
  CheckCircle,
  ArrowRight,
  ShieldCheck,
  TrendingDown,
  Users2,
  Zap,
  Layers,
  PhoneCall,
  CheckSquare2,
} from "lucide-react";

export const Route = createFileRoute("/solar-solutions/housing-society")({
  head: () => ({
    meta: [
      { title: "Housing Society Rooftop Solar — Elios Solar Energy Bihar" },
      {
        name: "description",
        content:
          "Power apartment common facilities including lifts, water pumps and corridor lighting with rooftop solar EPC in Bihar. Slash society maintenance costs.",
      },
      { property: "og:title", content: "Housing Society Rooftop Solar — Elios Solar Energy Bihar" },
      { property: "og:image", content: ASSETS.housingSocietyHero },
    ],
    links: [{ rel: "canonical", href: "https://eliossolar.in/solar-solutions/housing-society" }],
  }),
  component: HousingSocietyPage,
});

function HousingSocietyPage() {
  const { isHi, t } = useLocale();
  const [quoteOpen, setQuoteOpen] = useState(false);
  const [monthlyBill, setMonthlyBill] = useState(25000);

  // Society estimator math
  const estimatedKw = Math.max(5, Math.ceil(monthlyBill / (7 * 4 * 30)));
  const monthlySavings = Math.round(monthlyBill * 0.75);
  const annualSavings = monthlySavings * 12;

  const loadsCovered = [
    {
      titleEn: "Passenger & Freight Elevators",
      titleHi: "यात्री एवं सर्विस लिफ्ट",
      descEn:
        "Elevators run continuous daytime trips, making solar power the cheapest way to run your multi-floor vertical transport.",
      descHi:
        "दिन भर चलने वाली लिफ्टों के भारी बिजली खर्च को छत पर उत्पन्न सौर ऊर्जा से पूरी तरह संतुलित करें।",
      image:
        "https://vibe.filesafe.space/1792820769937918655/assets/71c8965c-3ea5-40b0-84a3-37f48c33ce81.png",
      altEn: "Passenger elevators in a residential apartment building lobby",
      altHi: "अपार्टमेंट बिल्डिंग लॉबी में यात्री लिफ्ट",
    },
    {
      titleEn: "Water Pumps & Submersible Motors",
      titleHi: "बोरवेल पंप एवं वॉटर ट्रीटमेंट प्लांट",
      descEn:
        "Pumping thousands of liters daily to overhead tanks is powered directly during peak sunlight hours.",
      descHi:
        "सुबह और दोपहर में छत की टंकियों तक पानी चढ़ाने वाले सबमर्सिबल पंपों का संचालन सीधे सोलर से होता है।",
      image:
        "https://vibe.filesafe.space/1792820769937918655/assets/73de2359-441d-4c2f-a35b-e49f49573291.png",
      altEn: "Rooftop water tank and water pump system on a residential building",
      altHi: "बिल्डिंग की छत पर वॉटर टैंक एवं पंप सिस्टम",
    },
    {
      titleEn: "Corridor, Garden & Perimeter Lights",
      titleHi: "कॉरिडोर, पार्क एवं बाउंड्री लाइटिंग",
      descEn:
        "Net metering credits earned during sunny daytime hours offset nighttime lighting across parking lots and common lobbies.",
      descHi:
        "दिन में उत्पादित अतिरिक्त बिजली नेट मीटर द्वारा ग्रिड में जाती है, जिससे रात की कॉमन लाइटिंग का बिल शून्य हो जाता है।",
      image:
        "https://vibe.filesafe.space/1792820769937918655/assets/02a146dc-9c5b-4bf2-a9c1-63cd1aef9c00.png",
      altEn: "Garden pathway and corridor lighting in a housing society at dusk",
      altHi: "हाउसिंग सोसाइटी में शाम के समय गार्डन पाथ एवं कॉरिडोर लाइटिंग",
    },
    {
      titleEn: "Clubhouse, Gym & Security Systems",
      titleHi: "क्लबहाउस, जिम एवं सुरक्षा उपकरण",
      descEn:
        "Continuous power for society CCTV cameras, boom barriers, clubhouse HVAC, and intercom networks without grid shocks.",
      descHi:
        "सीसीटीवी कैमरे, बूम बैरियर, क्लबहाउस एसी और सिक्योरिटी नेटवर्क को बिना अतिरिक्त लोड खर्च के चालू रखें।",
      image:
        "https://vibe.filesafe.space/1792820769937918655/assets/32eba8e9-36a1-4970-a302-cdd3727ce770.png",
      altEn: "Residential clubhouse gym interior with a security camera",
      altHi: "सोसाइटी क्लबहाउस जिम और सिक्योरिटी कैमरा",
    },
  ];

  const committeeBenefits = [
    {
      titleEn: "Zero Friction Committee Approvals",
      titleHi: "आरडब्ल्यूए / सोसाइटी कमेटी के लिए विस्तृत रिपोर्ट",
      descEn:
        "Elios prepares complete engineering proposals, ROI projections, and presentation decks to help managing committees get fast AGM/GBM member consensus.",
      descHi:
        "हम जनरल बॉडी मीटिंग (AGM) के लिए विस्तृत वित्तीय प्रस्तुति और 25 साल का बचत चार्ट तैयार करते हैं ताकि सभी फ्लैट-मालिकों की सहमति सरलता से मिले।",
      image:
        "https://vibe.filesafe.space/1792820769937918655/assets/64939c35-85e9-4055-bd0d-91e27e0e0280.png",
      altEn: "Apartment society committee meeting reviewing solar ROI presentation",
      altHi: "सोसाइटी कमेटी मीटिंग में सोलर आरओआई प्रस्तुति की समीक्षा",
    },
    {
      titleEn: "Reduced Monthly Maintenance per Flat",
      titleHi: "प्रत्येक फ्लैट के मासिक मेंटेनेंस चार्ज में कमी",
      descEn:
        "Lower common utility expenses immediately relieve monthly maintenance charges (CAM charges) for every single apartment owner in the society.",
      descHi:
        "कॉमन मीटर के बिल में 70-85% की कमी से हर परिवार पर पड़ने वाला मासिक सोसाइटी मेंटेनेंस भार काफी घट जाता है।",
      image:
        "https://vibe.filesafe.space/1792820769937918655/assets/3696d8fe-98df-4bf9-98dc-fdedc07e9a76.png",
      altEn: "Happy apartment resident family reviewing reduced maintenance bill",
      altHi: "घर पर कम हुए मेंटेनेंस बिल की समीक्षा करता हुआ परिवार",
    },
    {
      titleEn: "Turnkey Net-Metering with NBPDCL / SBPDCL",
      titleHi: "बिहार डिस्कॉम से सम्पूर्ण नेट-मीटरिंग लीगल अप्रूवल",
      descEn:
        "We coordinate structural load testing, fire clearance alignment, transformer sanction load upgrades, and bi-directional meter testing with state utilities.",
      descHi:
        "स्ट्रक्चरल लोड टेस्टिंग, ट्रांसफॉर्मर लोड एनहांसमेंट और सरकारी डिस्कॉम से नेट मीटरिंग की अनुमति का सारा काम एलियोस करता है।",
      image:
        "https://vibe.filesafe.space/1792820769937918655/assets/e34ddf21-533e-4796-94f3-20ed914e3089.png",
      altEn: "Technician installing a bi-directional net meter on a solar rooftop",
      altHi: "सोलर छत पर बाय-डायरेक्शनल नेट मीटर इंस्टॉल करते हुए तकनीशियन",
    },
    {
      titleEn: "Remote Generation Dashboard",
      titleHi: "लाइव जनरेशन मॉनिटरिंग डैशबोर्ड",
      descEn:
        "Society presidents and facility managers get real-time smartphone dashboard visibility of units generated, exported, and money saved.",
      descHi:
        "सोसाइटी प्रबंधक और आरडब्ल्यूए अध्यक्ष अपने मोबाइल पर दैनिक यूनिट उत्पादन और बचत का लाइव डेटा देख सकते हैं।",
      image:
        "https://vibe.filesafe.space/1792820769937918655/assets/910d2018-805a-43d2-a129-55ad46051f5c.png",
      altEn: "Smartphone showing a real-time solar energy monitoring dashboard",
      altHi: "रियल-टाइम सोलर मॉनिटरिंग डैशबोर्ड दिखाता हुआ स्मार्टफोन",
    },
  ];

  return (
    <div className="w-full bg-background py-12 sm:py-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        {/* 1. Header Hero */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center mb-16">
          <div className="lg:col-span-7">
            <span className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-3.5 py-1 text-xs font-semibold text-foreground mb-4">
              <Building2 className="h-3.5 w-3.5 text-primary" />
              <span>
                {isHi ? "अपार्टमेंट एवं हाउसिंग सोसाइटी" : "Apartment Complexes & Societies"}
              </span>
            </span>
            <h1 className="font-display text-3xl sm:text-5xl font-extrabold text-foreground leading-tight">
              {isHi
                ? "हाउसिंग सोसाइटी रूफटॉप सोलर: मेंटेनेंस शुल्क में भारी कटौती"
                : "Housing Society Rooftop Solar in Bihar"}
            </h1>
            <p className="mt-4 text-base sm:text-lg text-muted-foreground leading-relaxed">
              {isHi
                ? "सोसाइटी की छत पर स्थापित सोलर प्लांट से लिफ्ट, बोरवेल पंप, वाटर ट्रीटमेंट और कॉमन एरिया लाइटिंग का भारी बिजली बिल शून्य की ओर ले जाएं। इससे सोसाइटी के प्रत्येक फ्लैट-मालिक का मासिक मेंटेनेंस खर्च घटता है।"
                : "Harness shared terrace space to offset heavy common electrical loads including high-power elevators, submersible water pumps, community hall and garden lighting. Delivers long-term cost reduction for every resident family."}
            </p>

            <div className="mt-6 rounded-2xl bg-card border border-border p-4 text-xs text-muted-foreground leading-relaxed">
              <strong className="text-foreground">
                {isHi ? "सरकारी सब्सिडी स्थिति:" : "Government Subsidy Note:"}
              </strong>{" "}
              {isHi
                ? "वर्तमान पीएम सूर्य घर योजना के तहत हाउसिंग सोसायटियों के कॉमन-एरिया मीटरों के लिए कोई प्रत्यक्ष केंद्रीय सब्सिडी उपलब्ध नहीं है। तथापि, परिचालन बचत से पूरा सिस्टम 3 से 4 वर्षों में अपनी लागत वसूल कर लेता है।"
                : "Under current PM Surya Ghar guidelines, there is currently no direct central subsidy for housing society common meters. However, substantial monthly power reduction ensures rapid payback through operational savings."}
            </div>

            <div className="mt-8 flex flex-wrap gap-4">
              <button
                onClick={() => setQuoteOpen(true)}
                className="inline-flex items-center gap-2 rounded-xl bg-primary px-6 py-3 text-sm font-bold text-primary-foreground shadow-sm hover:bg-primary-hover transition-all"
              >
                <span>{t("getFreeQuotation")}</span>
                <ArrowRight className="h-4 w-4" />
              </button>
              <a
                href="tel:+919153933318"
                className="inline-flex items-center gap-2 rounded-xl border border-border bg-card px-5 py-3 text-sm font-bold text-foreground hover:border-primary transition-colors"
              >
                <PhoneCall className="h-4 w-4 text-primary" />
                <span>{isHi ? "सोसाइटी सर्वे शेड्यूल करें" : "Schedule Society Survey"}</span>
              </a>
            </div>
          </div>

          <div className="lg:col-span-5 rounded-3xl overflow-hidden border border-border shadow-xl">
            <img
              src={ASSETS.housingSocietyHero}
              alt="Housing Society Rooftop Solar in Bihar"
              className="w-full h-80 sm:h-96 object-cover"
            />
          </div>
        </div>

        {/* 2. Interactive Society Savings Estimator */}
        <div className="mb-20 rounded-3xl border border-border bg-card p-6 sm:p-10 shadow-sm">
          <div className="text-center max-w-2xl mx-auto mb-8">
            <span className="text-xs font-bold uppercase tracking-wider text-primary">
              {isHi ? "सोसाइटी बचत कैलकुलेटर" : "Society Cost Estimator"}
            </span>
            <h2 className="mt-2 font-display text-2xl sm:text-3xl font-extrabold text-foreground">
              {isHi
                ? "कॉमन एरिया के बिजली बिल पर अनुमानित बचत"
                : "Estimate Your Society Common-Area Savings"}
            </h2>
            <p className="mt-2 text-xs sm:text-sm text-muted-foreground">
              {isHi
                ? "सोसाइटी के मासिक कॉमन मीटर बिजली बिल के आधार पर उपयुक्त सोलर क्षमता और सालाना बचत देखें।"
                : "Move the slider to match your apartment association's monthly common electricity expenditure."}
            </p>
          </div>

          <div className="max-w-2xl mx-auto">
            <div className="mb-6">
              <div className="flex justify-between items-center mb-2">
                <label className="text-xs font-bold text-foreground uppercase tracking-wider">
                  {isHi ? "मासिक कॉमन बिजली बिल" : "Monthly Common-Area Bill"}
                </label>
                <span className="font-display text-xl font-bold text-primary">
                  ₹{monthlyBill.toLocaleString("en-IN")}
                </span>
              </div>
              <input
                type="range"
                min={10000}
                max={200000}
                step={5000}
                value={monthlyBill}
                onChange={(e) => setMonthlyBill(Number(e.target.value))}
                className="w-full h-2.5 bg-border rounded-lg appearance-none cursor-pointer accent-primary"
              />
              <div className="flex justify-between text-[11px] text-muted-foreground mt-1">
                <span>₹10,000</span>
                <span>₹1,00,000</span>
                <span>₹2,00,000</span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
              <div className="rounded-2xl border border-border/80 bg-background p-4 text-center">
                <span className="text-[11px] text-muted-foreground block mb-1">
                  {isHi ? "सुझाई गई क्षमता" : "Recommended Size"}
                </span>
                <span className="font-display text-2xl font-black text-foreground">
                  ~{estimatedKw} kW
                </span>
              </div>
              <div className="rounded-2xl border border-border/80 bg-background p-4 text-center">
                <span className="text-[11px] text-muted-foreground block mb-1">
                  {isHi ? "मासिक अनुमानित बचत" : "Est. Monthly Savings"}
                </span>
                <span className="font-display text-2xl font-black text-success">
                  ~₹{monthlySavings.toLocaleString("en-IN")}
                </span>
              </div>
              <div className="rounded-2xl border border-border/80 bg-background p-4 text-center">
                <span className="text-[11px] text-muted-foreground block mb-1">
                  {isHi ? "सालाना अनुमानित बचत" : "Est. Annual Savings"}
                </span>
                <span className="font-display text-2xl font-black text-success">
                  ~₹{annualSavings.toLocaleString("en-IN")}
                </span>
              </div>
            </div>

            <div className="text-center">
              <button
                onClick={() => setQuoteOpen(true)}
                className="inline-flex items-center gap-2 rounded-xl bg-primary px-6 py-3 text-xs sm:text-sm font-bold text-primary-foreground shadow-sm hover:bg-primary-hover transition-all"
              >
                <span>
                  {isHi
                    ? `सोसाइटी के लिए ${estimatedKw} kW का प्रस्ताव प्राप्त करें`
                    : `Get ${estimatedKw} kW Proposal for Your Society`}
                </span>
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>

        {/* 3. Common Loads Powered by Solar */}
        <div className="mb-20">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <span className="text-xs font-bold uppercase tracking-wider text-primary">
              {isHi ? "किन सुविधाओं को पावर मिलती है" : "Common Electrical Loads"}
            </span>
            <h2 className="mt-2 font-display text-2xl sm:text-3xl font-extrabold text-foreground">
              {isHi
                ? "सोसाइटी के ये सभी बड़े भार सोलर से संचालित होते हैं"
                : "Heavy Common-Area Utilities Run Seamlessly on Solar"}
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {loadsCovered.map((item, idx) => (
              <div
                key={idx}
                className="rounded-3xl border border-border bg-card overflow-hidden shadow-sm flex flex-col justify-between transition-all hover:border-primary/50 hover:shadow-md"
              >
                <div className="relative aspect-[16/10] w-full overflow-hidden bg-muted">
                  <img
                    src={item.image}
                    alt={isHi ? item.altHi : item.altEn}
                    loading="lazy"
                    className="w-full h-full object-cover object-center"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent" />
                </div>
                <div className="p-6 text-center flex flex-col items-center flex-1">
                  <div className="p-3 rounded-2xl bg-primary/10 text-primary mb-3.5">
                    <Zap className="h-5 w-5" />
                  </div>
                  <h3 className="font-display text-base font-bold text-foreground mb-2">
                    {isHi ? item.titleHi : item.titleEn}
                  </h3>
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    {isHi ? item.descHi : item.descEn}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 4. RWA / Managing Committee Advantages */}
        <div className="mb-20 rounded-3xl border border-border bg-card/60 p-6 sm:p-10">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <span className="text-xs font-bold uppercase tracking-wider text-primary">
              {isHi ? "कमेटी के लिए समाधान" : "RWA & Committee Support"}
            </span>
            <h2 className="mt-2 font-display text-2xl sm:text-3xl font-extrabold text-foreground">
              {isHi
                ? "आरडब्ल्यूए और सोसाइटी कमेटियों के लिए एलियोस का सहयोग"
                : "Complete Turnkey Support for Managing Committees"}
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {committeeBenefits.map((item, idx) => (
              <div
                key={idx}
                className="rounded-2xl border border-border bg-card overflow-hidden shadow-sm flex flex-col transition-all hover:border-primary/50 hover:shadow-md"
              >
                <div className="relative aspect-[16/9] w-full overflow-hidden bg-muted">
                  <img
                    src={item.image}
                    alt={isHi ? item.altHi : item.altEn}
                    loading="lazy"
                    className="w-full h-full object-cover object-center"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent" />
                </div>
                <div className="p-6 text-center flex flex-col items-center flex-1">
                  <div className="p-2.5 rounded-xl bg-primary/10 text-primary mb-3">
                    <CheckSquare2 className="h-5 w-5" />
                  </div>
                  <h3 className="font-display text-base font-bold text-foreground mb-2">
                    {isHi ? item.titleHi : item.titleEn}
                  </h3>
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    {isHi ? item.descHi : item.descEn}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 5. Closing CTA */}
        <div className="rounded-3xl border border-border bg-navy-dark text-white p-8 sm:p-12 text-center relative overflow-hidden">
          <div className="relative z-10 max-w-2xl mx-auto">
            <h3 className="font-display text-2xl sm:text-3xl font-extrabold text-cream-surface mb-3">
              {isHi
                ? "अपनी हाउसिंग सोसाइटी के लिए रूफटॉप फिजिबिलिटी सर्वे बुक करें"
                : "Schedule a Rooftop Assessment for Your Society"}
            </h3>
            <p className="text-xs sm:text-sm text-cream-surface/80 mb-6">
              {isHi
                ? "हमारी टीम आपकी सोसाइटी की छत का मापन कर आरडब्ल्यूए के लिए विस्तृत प्रेजेंटेशन तैयार करेगी।"
                : "Our senior engineers will inspect your terrace area and present a full ROI proposal for your managing committee."}
            </p>
            <button
              onClick={() => setQuoteOpen(true)}
              className="inline-flex items-center gap-2 rounded-xl bg-primary px-7 py-3.5 text-sm font-bold text-primary-foreground shadow-lg hover:bg-primary-hover transition-all"
            >
              <span>{t("getFreeQuotation")}</span>
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      <QuoteModal
        isOpen={quoteOpen}
        onClose={() => setQuoteOpen(false)}
        initialService="Housing Society"
      />
    </div>
  );
}
