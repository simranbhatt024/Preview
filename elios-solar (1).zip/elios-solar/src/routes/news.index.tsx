import { createFileRoute, Link } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { useLocale } from "../lib/locale-context";
import { INITIAL_POSTS, INITIAL_FAQS } from "../lib/mock-data";
import { QuoteModal } from "../components/QuoteModal";
import { Newspaper, ArrowRight, HelpCircle, ChevronDown } from "lucide-react";

export const Route = createFileRoute("/news/")({
  head: () => ({
    meta: [
      { title: "News & Solar Blogs — Elios Solar Energy Bihar" },
      {
        name: "description",
        content:
          "Read guides on PM Surya Ghar Muft Bijli Yojana, solar EPC installation steps, and frequently asked rooftop solar questions in Bihar.",
      },
      {
        property: "og:title",
        content: "News & Solar Blogs — Elios Solar Energy Bihar",
      },
      { property: "og:type", content: "website" },
    ],
    links: [{ rel: "canonical", href: "https://eliossolar.in/news" }],
  }),
  component: NewsPage,
});

function NewsPage() {
  const { isHi } = useLocale();
  const [posts, setPosts] = useState<any[]>(INITIAL_POSTS);
  const [openFaq, setOpenFaq] = useState<string | null>(null);
  const [quoteOpen, setQuoteOpen] = useState(false);

  useEffect(() => {
    try {
      const stored = localStorage.getItem("elios_blog_posts");
      if (stored) {
        setPosts(JSON.parse(stored));
      }
    } catch {
      // fallback
    }
  }, []);

  return (
    <div className="w-full bg-background py-12 sm:py-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-3.5 py-1 text-xs font-semibold text-foreground mb-4">
            <Newspaper className="h-3.5 w-3.5 text-primary" />
            <span>{isHi ? "ज्ञान एवं अंतर्दृष्टि" : "Solar News, Guides & FAQs"}</span>
          </div>
          <h1 className="font-display text-3xl sm:text-5xl font-extrabold text-foreground">
            {isHi ? "समाचार एवं उपयोगी ब्लॉग" : "News and Blogs"}
          </h1>
          <p className="mt-3 text-sm sm:text-base text-muted-foreground">
            {isHi
              ? "रूफटॉप सोलर, पीएम सूर्य घर सब्सिडी और बिजली बिल बचत संबंधी आवश्यक तकनीकी जानकारियां।"
              : "Expert technical articles, government subsidy notifications and rooftop solar engineering guidance."}
          </p>
        </div>

        {/* Blog Posts Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
          {posts.map((post) => (
            <div
              key={post.slug || post.id}
              className="rounded-3xl border border-border bg-card overflow-hidden shadow-sm flex flex-col justify-between hover:border-primary/50 transition-all"
            >
              <Link
                to="/news/$postSlug"
                params={{ postSlug: post.slug || post.id }}
                className="aspect-[16/10] overflow-hidden bg-muted block group"
              >
                <img
                  src={post.coverImage}
                  alt={post.titleEn || post.titleHi}
                  className="w-full h-full object-cover transition-transform group-hover:scale-105 duration-300"
                />
              </Link>

              <div className="p-6 flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex flex-wrap items-center gap-2 text-xs font-semibold text-primary mb-2">
                    <span>{post.category}</span>
                    <span>•</span>
                    <span className="text-muted-foreground">{post.readingTime}</span>
                    {post.factChecker && (
                      <span className="text-[10px] text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded font-medium ml-auto">
                        ✓ Verified
                      </span>
                    )}
                  </div>
                  <h3 className="font-display text-lg font-bold text-foreground mb-3 leading-snug">
                    {isHi ? post.titleHi || post.titleEn : post.titleEn || post.titleHi}
                  </h3>
                  <p className="text-xs text-muted-foreground leading-relaxed mb-6">
                    {isHi ? post.excerptHi || post.excerptEn : post.excerptEn || post.excerptHi}
                  </p>
                </div>

                <Link
                  to="/news/$postSlug"
                  params={{ postSlug: post.slug || post.id }}
                  className="inline-flex items-center gap-1.5 text-xs font-bold text-primary hover:underline"
                >
                  <span>{isHi ? "पूरा लेख पढ़ें" : "Read Full Article"}</span>
                  <ArrowRight className="h-3.5 w-3.5" />
                </Link>
              </div>
            </div>
          ))}
        </div>

        {/* FAQs Section */}
        <div className="rounded-3xl border border-border bg-card p-6 sm:p-12 shadow-sm">
          <div className="text-center max-w-xl mx-auto mb-10">
            <div className="inline-flex items-center gap-2 text-primary text-xs font-bold uppercase tracking-wider mb-2">
              <HelpCircle className="h-4 w-4" />
              <span>FAQ</span>
            </div>
            <h2 className="font-display text-2xl sm:text-3xl font-extrabold text-foreground">
              {isHi ? "अक्सर पूछे जाने वाले प्रश्न" : "Frequently Asked Questions"}
            </h2>
          </div>

          <div className="max-w-3xl mx-auto space-y-4">
            {INITIAL_FAQS.map((faq) => {
              const isOpen = openFaq === faq.slug;
              return (
                <div
                  key={faq.slug}
                  className="rounded-2xl border border-border bg-background overflow-hidden transition-all"
                >
                  <button
                    onClick={() => setOpenFaq(isOpen ? null : faq.slug)}
                    className="w-full flex items-center justify-between p-5 text-left text-sm font-bold text-foreground hover:text-primary transition-colors"
                  >
                    <span>
                      {isHi ? faq.questionHi || faq.questionEn : faq.questionEn || faq.questionHi}
                    </span>
                    <ChevronDown
                      className={`h-4 w-4 shrink-0 transition-transform ${isOpen ? "rotate-180" : ""}`}
                    />
                  </button>
                  {isOpen && (
                    <div className="p-5 pt-0 text-xs sm:text-sm text-muted-foreground leading-relaxed border-t border-border/40">
                      {isHi ? faq.answerHi || faq.answerEn : faq.answerEn || faq.answerHi}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <QuoteModal
        isOpen={quoteOpen}
        onClose={() => setQuoteOpen(false)}
        initialService="Residential Homes"
      />
    </div>
  );
}
