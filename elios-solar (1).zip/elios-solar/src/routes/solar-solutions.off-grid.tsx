import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useLocale } from "../lib/locale-context";
import { ASSETS } from "../lib/constants";
import { QuoteModal } from "../components/QuoteModal";
import {
  BatteryCharging,
  CheckCircle,
  ArrowRight,
  Zap,
  ShieldCheck,
  Fuel,
  Radio,
  Tractor,
  Home,
  CheckSquare2,
  PhoneCall,
  Clock,
} from "lucide-react";

export const Route = createFileRoute("/solar-solutions/off-grid")({
  head: () => ({
    meta: [
      { title: "Off-Grid Solar Power Systems — Elios Solar Energy Bihar" },
      {
        name: "description",
        content:
          "Independent hybrid inverters and lithium battery storage systems for remote farms, fuel stations, and weak-grid sites across Bihar.",
      },
      { property: "og:title", content: "Off-Grid Solar Power Systems — Elios Solar Energy Bihar" },
      { property: "og:image", content: ASSETS.offGridHero },
    ],
    links: [{ rel: "canonical", href: "https://eliossolar.in/solar-solutions/off-grid" }],
  }),
  component: OffGridSolarPage,
});

function OffGridSolarPage() {
  const { isHi, t } = useLocale();
  const [quoteOpen, setQuoteOpen] = useState(false);

  const applications = [
    {
      icon: Tractor,
      titleEn: "Agricultural Farmhouses & Tube Wells",
      titleHi: "कृषि फार्महाउस एवं ट्यूबवेल बोरिंग",
      descEn:
        "Reliable continuous electricity for irrigation submersible pumps, cold rooms, and rural farm stays where DISCOM lines suffer frequent cuts.",
      descHi:
        "सिंचाई पंप, बोरिंग और ग्रामीण फार्महाउस के लिए चौबीसों घंटे बिना लोड शेडिंग के निरंतर सौर बिजली।",
      img: "https://vibe.filesafe.space/1792820769937918655/assets/629801cf-7213-4b73-972b-9efad202886b.png",
      altEn:
        "Agricultural farmhouse in rural Bihar with solar panels powering an irrigation tube well pump",
      altHi: "ग्रामीण बिहार में कृषि फार्महाउस और सिंचाई ट्यूबवेल पंप के लिए सोलर पैनल",
    },
    {
      icon: Fuel,
      titleEn: "Highway Fuel Stations & Dhaba Hubs",
      titleHi: "हाइवे पेट्रोल पंप एवं ढाबा प्रतिष्ठान",
      descEn:
        "High diesel generator operational costs cut by 80% with instantaneous zero-millisecond solar inverter battery switchovers.",
      descHi:
        "डीजल जनरेटर के महंगे ईंधन खर्च में 80% तक कटौती, बिना किसी फ्लिकर या पावर कट के स्वचालित स्विचिंग।",
      img: "https://vibe.filesafe.space/1792820769937918655/assets/222813c1-1c82-476b-b8a8-26cf448277b2.png",
      altEn: "Highway fuel station in India with rooftop solar panels and battery backup system",
      altHi: "भारत में हाइवे पेट्रोल पंप और रूफटॉप सोलर पैनल वाली बैटरी बैकअप सिस्टम",
    },
    {
      icon: Radio,
      titleEn: "Telecom Towers & Remote Clinics",
      titleHi: "टेलीकॉम टावर एवं सुदूर स्वास्थ्य केंद्र",
      descEn:
        "Power life-saving medical refrigerators, diagnostic apparatus, and cellular towers in deep rural Bihar uninterrupted.",
      descHi:
        "टीकाकरण प्रशीतन और आवश्यक चिकित्सा उपकरणों के लिए 24/7 सुरक्षित और स्वतंत्र बिजली बैकअप।",
      img: "https://vibe.filesafe.space/1792820769937918655/assets/72287ece-e66b-4241-b65c-0c51afb2f618.png",
      altEn:
        "Telecom tower and remote rural clinic in Bihar powered by off-grid solar panels and lithium battery storage",
      altHi:
        "बिहार में ऑफ-ग्रिड सोलर पैनल और लिथियम बैटरी से संचालित टेलीकॉम टावर और ग्रामीण स्वास्थ्य केंद्र",
    },
    {
      icon: Home,
      titleEn: "Independent Villas in Frequent Outage Areas",
      titleHi: "ग्रामीण एवं अर्ध-शहरी आवासीय कोठी",
      descEn:
        "Run air conditioners, refrigerators, and water pumps during long nighttime village power blackouts with zero noise.",
      descHi:
        "गांव और कस्बों में लंबे बिजली कट के दौरान भी एसी, फ्रिज और पंखे बिना किसी आवाज और धुएं के आराम से चलाएं।",
      img: "https://vibe.filesafe.space/1792820769937918655/assets/741ab1a3-0eae-4b1b-90ae-f55ab680ae56.png",
      altEn:
        "Independent rural villa in Bihar with rooftop solar panels and lithium battery storage system",
      altHi: "बिहार में रूफटॉप सोलर पैनल और लिथियम बैटरी स्टोरेज वाली स्वतंत्र ग्रामीण कोठी",
    },
  ];

  const offGridComponents = [
    {
      titleEn: "Grade-A LiFePO4 Lithium Battery Storage",
      titleHi: "ग्रेड-ए लिथियम फेरो फॉस्फेट (LiFePO4) बैटरियां",
      descEn:
        "Safe, compact, and fire-resistant chemistry with 4000+ deep discharge cycles lasting 10–12 years without distilled water top-ups.",
      descHi:
        "4000+ साइकिल लाइफ और 10-12 साल चलने वाली आधुनिक लिथियम बैटरियां, जिनमें एसिड या पानी डालने की कोई जरूरत नहीं होती।",
      img: "https://vibe.filesafe.space/1792820769937918655/assets/7c93d29e-10f2-41a4-afe4-398857918272.png",
      altEn:
        "Wall-mounted LiFePO4 lithium battery storage bank with orange status lights in a clean utility room",
      altHi:
        "स्वच्छ उपयोगिता कक्ष में नारंगी स्टेटस लाइट वाली वॉल-माउंटेड LiFePO4 लिथियम बैटरी स्टोरेज बैंक",
    },
    {
      titleEn: "Smart Hybrid Inverter Systems",
      titleHi: "स्मार्ट हाइब्रिड इन्वर्टर सिस्टम",
      descEn:
        "Intelligently blends solar generation, battery backup, and grid/generator power with priority logic to minimize fuel consumption.",
      descHi:
        "सोलर, बैटरी और ग्रिड को समझदारी से प्रबंधित करता है ताकि बैटरी हमेशा चार्ज रहे और सबसे पहले सोलर बिजली खर्च हो।",
      img: "https://vibe.filesafe.space/1792820769937918655/assets/5287cd03-d1e2-4b7c-a289-e919b0a69ca1.png",
      altEn:
        "Smart hybrid solar inverter mounted on a wall with a digital power flow display screen",
      altHi:
        "डिजिटल पावर फ्लो डिस्प्ले स्क्रीन वाला स्मार्ट हाइब्रिड सोलर इन्वर्टर दीवार पर लगा हुआ",
    },
    {
      titleEn: "Bi-facial High-Wattage TopCon Panels",
      titleHi: "द्वि-मुखीय उच्च दक्षता वाले सोलर पैनल्स",
      descEn:
        "Captures direct sunlight from the front and reflected albedo irradiance from the rear to maximize battery bank charging.",
      descHi:
        "आगे और पीछे दोनों तरफ से धूप अवशोषित कर धुंधले या बादलों वाले दिनों में भी बैटरियों को तेजी से चार्ज करते हैं।",
      img: "https://vibe.filesafe.space/1792820769937918655/assets/10cfac89-6d9f-4327-901c-eb94c7e6be15.png",
      altEn:
        "Bifacial solar panels installed on a rooftop showing the glass rear surface capturing reflected sunlight",
      altHi:
        "रूफटॉप पर लगे द्वि-मुखीय सोलर पैनल जो पीछे की कांच सतह से परावर्तित धूप ग्रहण करते हैं",
    },
    {
      titleEn: "Multi-Pole Surge & Lightning Protection",
      titleHi: "मल्टी-पोल तड़ित चालक व अर्थिंग सुरक्षा",
      descEn:
        "Dedicated copper-bonded chemical earthing pits and class-II surge protection devices protecting expensive hybrid electronics.",
      descHi:
        "बिजली गिरने या वोल्टेज के अचानक उतार-चढ़ाव से इन्वर्टर और बैटरी को सुरक्षित रखने के लिए मजबूत अर्थिंग किट।",
      img: "https://vibe.filesafe.space/1792820769937918655/assets/2cf58566-9ec1-47f6-a30c-5109bb84148b.png",
      altEn:
        "Copper earthing rod and lightning arrester surge protection kit installed at the base of a rooftop solar plant",
      altHi:
        "रूफटॉप सोलर प्लांट के आधार पर लगा तांबे का अर्थिंग रॉड और लाइटनिंग एरेस्टर सर्ज प्रोटेक्शन किट",
    },
  ];

  return (
    <div className="w-full bg-background py-12 sm:py-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        {/* 1. Header Hero */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center mb-16">
          <div className="lg:col-span-7">
            <span className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-3.5 py-1 text-xs font-semibold text-foreground mb-4">
              <BatteryCharging className="h-3.5 w-3.5 text-primary" />
              <span>{isHi ? "स्वतंत्र ऊर्जा बैकअप" : "Independent Energy Independence"}</span>
            </span>
            <h1 className="font-display text-3xl sm:text-5xl font-extrabold text-foreground leading-tight">
              {isHi
                ? "ऑफ-ग्रिड सोलर सिस्टम: 24/7 निर्बाध सौर ऊर्जा"
                : "Off-Grid Solar Power Systems in Bihar"}
            </h1>
            <p className="mt-4 text-base sm:text-lg text-muted-foreground leading-relaxed">
              {isHi
                ? "दूरदराज के स्थानों, कृषि फार्महाउस, पेट्रोल पंप और कमजोर ग्रिड वाले क्षेत्रों के लिए आधुनिक लिथियम बैटरी बैंक एवं हाइब्रिड इन्वर्टर आधारित स्वतंत्र सोलर समाधान। ग्रिड कट होने पर भी बिजली कभी बंद नहीं होती।"
                : "Power remote residences, agricultural farmhouses, rural healthcare centers, and fuel stations with high-capacity lithium storage banks and smart hybrid inverters. Continuous power without grid reliance."}
            </p>

            <div className="mt-6 space-y-2.5 text-xs sm:text-sm font-semibold text-foreground">
              <div className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-success shrink-0" />
                <span>
                  {isHi
                    ? "महंगे और धुआं छोड़ने वाले डीजल जनरेटर से 100% मुक्ति"
                    : "Zero Diesel Generator Fuel Costs & Silent Operation"}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-success shrink-0" />
                <span>
                  {isHi
                    ? "10+ वर्ष चलने वाली सुरक्षित LiFePO4 लिथियम बैटरी बैंक"
                    : "10+ Year Lifespan LiFePO4 Lithium Battery Storage"}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-success shrink-0" />
                <span>
                  {isHi
                    ? "कमजोर या बिना ग्रिड वाले क्षेत्रों में भी 24x7 बिजली गारंटी"
                    : "Reliable 24x7 Continuous Power in Weak-Grid & Zero-Grid Areas"}
                </span>
              </div>
            </div>

            <div className="mt-8 flex flex-wrap gap-4">
              <button
                onClick={() => setQuoteOpen(true)}
                className="inline-flex items-center gap-2 rounded-xl bg-primary px-6 py-3 text-sm font-bold text-primary-foreground shadow-sm hover:bg-primary-hover transition-all"
              >
                <span>{t("getFreeQuotation")}</span>
                <ArrowRight className="h-4 w-4" />
              </button>
              <a
                href="tel:+919153933318"
                className="inline-flex items-center gap-2 rounded-xl border border-border bg-card px-5 py-3 text-sm font-bold text-foreground hover:border-primary transition-colors"
              >
                <PhoneCall className="h-4 w-4 text-primary" />
                <span>
                  {isHi ? "ऑफ-ग्रिड विशेषज्ञ से बात करें" : "Talk to Off-Grid Specialist"}
                </span>
              </a>
            </div>
          </div>

          <div className="lg:col-span-5 rounded-3xl overflow-hidden border border-border shadow-xl">
            <img
              src={ASSETS.offGridHero}
              alt="Off-Grid Solar Battery Setup in Bihar"
              className="w-full h-80 sm:h-96 object-cover"
            />
          </div>
        </div>

        {/* 2. Applications / Who Needs It */}
        <div className="mb-20">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <span className="text-xs font-bold uppercase tracking-wider text-primary">
              {isHi ? "उपयोग एवं अनुप्रयोग" : "Ideal Applications"}
            </span>
            <h2 className="mt-2 font-display text-2xl sm:text-3xl font-extrabold text-foreground">
              {isHi
                ? "ऑफ-ग्रिड सोलर सिस्टम किनके लिए सबसे उपयुक्त है?"
                : "Where Off-Grid Solar Delivers the Highest Impact in Bihar"}
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {applications.map((app, idx) => {
              const Icon = app.icon;
              return (
                <div
                  key={idx}
                  className="group rounded-2xl border border-border bg-card overflow-hidden flex flex-col transition-all duration-300 hover:shadow-xl hover:-translate-y-1 hover:border-primary/40"
                >
                  <div className="relative aspect-[4/3] overflow-hidden">
                    <img
                      src={app.img}
                      alt={isHi ? app.altHi : app.altEn}
                      loading="lazy"
                      className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-navy-premium/70 via-navy-premium/10 to-transparent pointer-events-none" />
                    <div className="absolute top-3 left-3 h-10 w-10 rounded-xl bg-primary/90 text-primary-foreground flex items-center justify-center shadow-lg ring-2 ring-white/20">
                      <Icon className="h-5 w-5" />
                    </div>
                  </div>
                  <div className="p-6 flex-1 flex flex-col">
                    <h3 className="font-display text-base font-bold text-foreground mb-2">
                      {isHi ? app.titleHi : app.titleEn}
                    </h3>
                    <p className="text-xs text-muted-foreground leading-relaxed flex-1">
                      {isHi ? app.descHi : app.descEn}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* 3. Engineering Components of Off-Grid System */}
        <div className="mb-20 rounded-3xl border border-border bg-card/60 p-6 sm:p-10">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <span className="text-xs font-bold uppercase tracking-wider text-primary">
              {isHi ? "सिस्टम के प्रमुख घटक" : "Core System Components"}
            </span>
            <h2 className="mt-2 font-display text-2xl sm:text-3xl font-extrabold text-foreground">
              {isHi
                ? "विश्वसनीय स्वतंत्र ऊर्जा के लिए आधुनिक तकनीक"
                : "Engineered with Industrial-Grade Storage & Inverters"}
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {offGridComponents.map((item, idx) => (
              <div
                key={idx}
                className="group rounded-2xl border border-border bg-card overflow-hidden flex flex-col transition-all duration-300 hover:shadow-xl hover:-translate-y-1 hover:border-primary/40"
              >
                <div className="relative aspect-[16/10] overflow-hidden">
                  <img
                    src={item.img}
                    alt={isHi ? item.altHi : item.altEn}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-navy-premium/70 via-navy-premium/10 to-transparent pointer-events-none" />
                  <div className="absolute top-3 left-3 h-10 w-10 rounded-xl bg-primary/90 text-primary-foreground flex items-center justify-center shadow-lg ring-2 ring-white/20">
                    <CheckSquare2 className="h-5 w-5" />
                  </div>
                </div>
                <div className="p-6 flex-1 flex flex-col">
                  <h3 className="font-display text-base font-bold text-foreground mb-2 leading-snug">
                    {isHi ? item.titleHi : item.titleEn}
                  </h3>
                  <p className="text-xs text-muted-foreground leading-relaxed flex-1">
                    {isHi ? item.descHi : item.descEn}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 4. Closing CTA */}
        <div className="rounded-3xl border border-border bg-navy-dark text-white p-8 sm:p-12 text-center relative overflow-hidden">
          <div className="relative z-10 max-w-2xl mx-auto">
            <h3 className="font-display text-2xl sm:text-3xl font-extrabold text-cream-surface mb-3">
              {isHi
                ? "अपने फार्महाउस या प्रोजेक्ट के लिए ऑफ-ग्रिड कोटेशन प्राप्त करें"
                : "Design an Independent Solar Power System for Your Site"}
            </h3>
            <p className="text-xs sm:text-sm text-cream-surface/80 mb-6">
              {isHi
                ? "हमारी टीम आपके लोड और बैकअप की आवश्यकता का सटीक विश्लेषण कर कस्टम हाइब्रिड सिस्टम तैयार करेगी।"
                : "Tell us your load requirements and battery autonomy needs. We engineer a tailor-made off-grid package."}
            </p>
            <button
              onClick={() => setQuoteOpen(true)}
              className="inline-flex items-center gap-2 rounded-xl bg-primary px-7 py-3.5 text-sm font-bold text-primary-foreground shadow-lg hover:bg-primary-hover transition-all"
            >
              <span>{t("getFreeQuotation")}</span>
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      <QuoteModal
        isOpen={quoteOpen}
        onClose={() => setQuoteOpen(false)}
        initialService="Off-Grid Solar"
      />
    </div>
  );
}
