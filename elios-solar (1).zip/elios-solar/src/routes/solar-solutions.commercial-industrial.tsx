import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useLocale } from "../lib/locale-context";
import { ASSETS } from "../lib/constants";
import { QuoteModal } from "../components/QuoteModal";
import {
  Factory,
  CheckCircle,
  ArrowRight,
  TrendingUp,
  Percent,
  Warehouse,
  ShieldAlert,
  Flame,
  Award,
  BarChart3,
  CheckSquare2,
  PhoneCall,
} from "lucide-react";

export const Route = createFileRoute("/solar-solutions/commercial-industrial")({
  head: () => ({
    meta: [
      { title: "Commercial & Industrial Rooftop Solar — Elios Solar Energy Bihar" },
      {
        name: "description",
        content:
          "High-efficiency turnkey rooftop solar EPC plants for factories, cold storages, rice mills and commercial enterprises in Bihar with rapid ROI.",
      },
      {
        property: "og:title",
        content: "Commercial & Industrial Rooftop Solar — Elios Solar Energy Bihar",
      },
      { property: "og:image", content: ASSETS.commercialHero },
    ],
    links: [
      { rel: "canonical", href: "https://eliossolar.in/solar-solutions/commercial-industrial" },
    ],
  }),
  component: CommercialIndustrialPage,
});

function CommercialIndustrialPage() {
  const { isHi, t } = useLocale();
  const [quoteOpen, setQuoteOpen] = useState(false);
  const [monthlyTariffBill, setMonthlyTariffBill] = useState(150000);

  // C&I math estimates
  const estimatedKw = Math.max(15, Math.ceil(monthlyTariffBill / (8.5 * 4 * 30)));
  const monthlySavings = Math.round(monthlyTariffBill * 0.7);
  const annualSavings = monthlySavings * 12;
  const approxPlantCost = estimatedKw * 52000;
  const approxPaybackYears = (approxPlantCost / annualSavings).toFixed(1);

  const targetIndustries = [
    {
      titleEn: "Rice Mills & Flour Processing",
      titleHi: "चावल मिल एवं आटा चक्की इकाइयां",
      descEn:
        "High continuous daytime horsepower motor consumption makes solar the ideal power source to eliminate high-tariff peak grid charges.",
      descHi:
        "दिन भर चलने वाली भारी मोटर और मिल मशीनों के लिए सोलर बिजली ग्रिड के महंगे कमर्शियल टैरिफ को समाप्त करती है।",
      img: "https://vibe.filesafe.space/1792820769937918655/assets/38740c68-2177-4c26-abc3-c716012a4283.png",
      altEn: "Rice mill factory with rooftop solar panels in Bihar",
      altHi: "बिहार में रूफटॉप सोलर पैनल वाली चावल मिल फैक्ट्री",
    },
    {
      titleEn: "Cold Storages & Refrigeration",
      titleHi: "कोल्ड स्टोरेज एवं प्रशीतन संयंत्र",
      descEn:
        "Chilling compressors operate under heavy thermal load in Bihar summers. Solar output peaks precisely when refrigeration demand is highest.",
      descHi:
        "गर्मी के महीनों में जब कंप्रेसर का लोड सबसे अधिक होता है, उसी समय सोलर पैनल सबसे ज्यादा बिजली बनाते हैं।",
      img: "https://vibe.filesafe.space/1792820769937918655/assets/0be24a1d-6d59-4826-b160-34edbc4c2968.png",
      altEn: "Cold storage warehouse with rooftop solar panels",
      altHi: "रूफटॉप सोलर पैनल वाला कोल्ड स्टोरेज वेयरहाउस",
    },
    {
      titleEn: "Warehouses & Logistics Hubs",
      titleHi: "गोदाम, वेयरहाउस एवं लॉजिस्टिक्स पार्क",
      descEn:
        "Expansive tin-shed and RCC roof areas offer prime square footage for multi-hundred kilowatt arrays with zero ground space loss.",
      descHi:
        "वेयरहाउस की विशाल टीन-शेड छतें बिना अतिरिक्त जमीन घेरे सैकड़ों किलोवाट क्षमता के सोलर प्लांट के लिए आदर्श हैं।",
      img: "https://vibe.filesafe.space/1792820769937918655/assets/0c6a4226-d802-429d-b3f7-4ff1bdff6ddc.png",
      altEn: "Logistics warehouse with extensive rooftop solar installation",
      altHi: "विस्तृत रूफटॉप सोलर इंस्टॉलेशन वाला लॉजिस्टिक्स वेयरहाउस",
    },
    {
      titleEn: "Hospitals, Schools & Commercial Hubs",
      titleHi: "अस्पताल, शिक्षण संस्थान व शॉपिंग मॉल",
      descEn:
        "Maintain clean daytime reliability, reduce costly diesel generator run hours, and project a sustainable environmental brand identity.",
      descHi:
        "डीजल जनरेटर के महंगे खर्च को घटाएं और अपने संस्थान को 24/7 स्वच्छ सौर ऊर्जा से संचालित करें।",
      img: "https://vibe.filesafe.space/1792820769937918655/assets/0a4bc814-5226-45bd-b103-73da6b90fe1d.png",
      altEn: "Hospital and school campus with rooftop solar panels",
      altHi: "रूफटॉप सोलर पैनल वाला अस्पताल और स्कूल कैंपस",
    },
  ];

  const engineeringHighlights = [
    {
      titleEn: "Hot-Dip Galvanized Non-Penetrative Mounting",
      titleHi: "बिना छत नुकसान वाले जंग-रोधी स्ट्रक्चर",
      descEn:
        "Designed to withstand 160+ km/h wind speeds with specialised clamping for standing-seam and trapezoidal metal sheets without roof leaks.",
      descHi:
        "160 किमी/घंटा तक की तेज आंधी सहने योग्य और टीन शेड में बिना छेद किए विशेष क्लैंपिंग सिस्टम।",
      img: "https://vibe.filesafe.space/1792820769937918655/assets/3d80e4d4-0dde-4281-ae6c-8f8601f59a94.png",
      altEn: "Hot-dip galvanized non-penetrative solar mounting structure on a metal factory roof",
      altHi: "धातु की फैक्ट्री छत पर जंग-रोधी बिना छेद वाला सोलर माउंटिंग स्ट्रक्चर",
    },
    {
      titleEn: "String Inverters with Multi-MPPT Tracking",
      titleHi: "मल्टी-एमपीपीटी स्ट्रिंग इन्वर्टर",
      descEn:
        "Maximum power point tracking ensures that localized bird drops or partial dust do not pull down the entire string output.",
      descHi:
        "प्रत्येक स्ट्रिंग की स्वतंत्र मॉनिटरिंग ताकि धूल या आंशिक छाया पूरे प्लांट के उत्पादन को प्रभावित न करे।",
      img: "https://vibe.filesafe.space/1792820769937918655/assets/8a115002-3488-4a41-b810-843f6497a492.png",
      altEn:
        "Industrial solar string inverters with multi-MPPT tracking in a commercial power plant",
      altHi:
        "कमर्शियल पावर प्लांट में मल्टी-एमपीपीटी ट्रैकिंग वाले औद्योगिक सोलर स्ट्रिंग इन्वर्टर",
    },
    {
      titleEn: "HT / LT Net Metering Compliance",
      titleHi: "एचटी / एलटी नेट मीटरिंग एवं डिस्कॉम स्वीकृति",
      descEn:
        "Complete synchronization with NBPDCL and SBPDCL 11kV/33kV distribution networks, CEIG electrical safety inspectorate clearances.",
      descHi:
        "चीफ इलेक्ट्रिकल इंस्पेक्टर (CEIG) की सुरक्षा मंजूरी और 11kV/33kV ग्रिड सिंक्रोनाइज़ेशन का पूर्ण प्रबंधन।",
      img: "https://vibe.filesafe.space/1792820769937918655/assets/9f1435e7-fd77-43ba-9a51-1f05ef1c0fb4.png",
      altEn:
        "HT/LT electrical metering panel with bi-directional net meter for a commercial solar plant",
      altHi:
        "कमर्शियल सोलर प्लांट के लिए बाय-डायरेक्शनल नेट मीटर वाला एचटी/एलटी इलेक्ट्रिकल मीटरिंग पैनल",
    },
    {
      titleEn: "Remote SCADA & IoT Cloud Monitoring",
      titleHi: "रिमोट स्काडा (SCADA) एवं आईओटी मॉनिटरिंग",
      descEn:
        "Module-level and inverter-level real-time performance telemetry with proactive fault diagnostics sent directly to your maintenance team.",
      descHi:
        "प्लांट के हर इन्वर्टर का रियल-टाइम टेलीमेट्री डेटा और किसी भी खराबी पर तत्काल अलर्ट की सुविधा।",
      img: "https://vibe.filesafe.space/1792820769937918655/assets/ce7d972d-02b8-4559-a6d6-91b224a0b8e7.png",
      altEn:
        "Solar plant SCADA control room with IoT cloud monitoring dashboards showing real-time generation",
      altHi: "रियल-टाइम जनरेशन दिखाते हुए स्काडा कंट्रोल रूम और आईओटी क्लाउड मॉनिटरिंग डैशबोर्ड",
    },
  ];

  return (
    <div className="w-full bg-background py-12 sm:py-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        {/* 1. Header Hero */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center mb-16">
          <div className="lg:col-span-7">
            <span className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-3.5 py-1 text-xs font-semibold text-foreground mb-4">
              <Factory className="h-3.5 w-3.5 text-primary" />
              <span>
                {isHi ? "फैक्ट्री, गोदाम व चावल मिल" : "Commercial & Industrial Solar EPC"}
              </span>
            </span>
            <h1 className="font-display text-3xl sm:text-5xl font-extrabold text-foreground leading-tight">
              {isHi
                ? "कमर्शियल एवं औद्योगिक रूफटॉप सोलर: सस्ती बिजली, उच्च आरओआई"
                : "Commercial & Industrial Rooftop Solar in Bihar"}
            </h1>
            <p className="mt-4 text-base sm:text-lg text-muted-foreground leading-relaxed">
              {isHi
                ? "चावल मिल, कोल्ड स्टोरेज, आटा चक्की और निर्माण इकाइयों के लिए रूफटॉप सोलर बिजली की प्रति यूनिट लागत को सबसे कम करता है। इसके साथ त्वरित मूल्यह्रास (Accelerated Depreciation) कर लाभ भी प्राप्त होता है।"
                : "Dramatically lower daytime grid tariff expenses for rice mills, cold storages, warehouses, hospitals, and educational campuses. Deliver rapid payback with 25-year tier-1 monocrystalline performance."}
            </p>

            <div className="mt-6 rounded-2xl bg-card border border-border p-4 text-xs text-muted-foreground leading-relaxed">
              <strong className="text-foreground">
                {isHi ? "कर लाभ अस्वीकरण:" : "Tax Benefit Note:"}
              </strong>{" "}
              {t("taxDisclaimer")}
            </div>

            <div className="mt-8 flex flex-wrap gap-4">
              <button
                onClick={() => setQuoteOpen(true)}
                className="inline-flex items-center gap-2 rounded-xl bg-primary px-6 py-3 text-sm font-bold text-primary-foreground shadow-sm hover:bg-primary-hover transition-all"
              >
                <span>{t("getFreeQuotation")}</span>
                <ArrowRight className="h-4 w-4" />
              </button>
              <a
                href="tel:+919153933318"
                className="inline-flex items-center gap-2 rounded-xl border border-border bg-card px-5 py-3 text-sm font-bold text-foreground hover:border-primary transition-colors"
              >
                <PhoneCall className="h-4 w-4 text-primary" />
                <span>{isHi ? "औद्योगिक सर्वे बुक करें" : "Book Industrial Survey"}</span>
              </a>
            </div>
          </div>

          <div className="lg:col-span-5 rounded-3xl overflow-hidden border border-border shadow-xl">
            <img
              src={ASSETS.commercialHero}
              alt="Commercial Rooftop Solar Plant in Bihar"
              className="w-full h-80 sm:h-96 object-cover"
            />
          </div>
        </div>

        {/* 2. Interactive Commercial ROI Calculator */}
        <div className="mb-20 rounded-3xl border border-border bg-card p-6 sm:p-10 shadow-sm">
          <div className="text-center max-w-2xl mx-auto mb-8">
            <span className="text-xs font-bold uppercase tracking-wider text-primary">
              {isHi ? "वाणिज्यिक आरओआई कैलकुलेटर" : "C&I Solar ROI Calculator"}
            </span>
            <h2 className="mt-2 font-display text-2xl sm:text-3xl font-extrabold text-foreground">
              {isHi
                ? "अपनी फैक्ट्री या व्यापार के लिए अनुमानित बचत एवं पेबैक अवधि"
                : "Projected Payback & Financial Return for Your Enterprise"}
            </h2>
            <p className="mt-2 text-xs sm:text-sm text-muted-foreground">
              {isHi
                ? "मासिक बिजली बिल दर्ज करें और अनुमानित आवश्यक क्षमता व सालाना बचत की गणना देखें।"
                : "Slide to your facility's average monthly electricity expenditure to calculate optimal solar plant sizing."}
            </p>
          </div>

          <div className="max-w-3xl mx-auto">
            <div className="mb-8">
              <div className="flex justify-between items-center mb-2">
                <label className="text-xs font-bold text-foreground uppercase tracking-wider">
                  {isHi ? "मासिक बिजली बिल (रुपये)" : "Monthly Grid Bill (INR)"}
                </label>
                <span className="font-display text-2xl font-bold text-primary">
                  ₹{monthlyTariffBill.toLocaleString("en-IN")}
                </span>
              </div>
              <input
                type="range"
                min={50000}
                max={1500000}
                step={25000}
                value={monthlyTariffBill}
                onChange={(e) => setMonthlyTariffBill(Number(e.target.value))}
                className="w-full h-2.5 bg-border rounded-lg appearance-none cursor-pointer accent-primary"
              />
              <div className="flex justify-between text-[11px] text-muted-foreground mt-1">
                <span>₹50,000</span>
                <span>₹7,50,000</span>
                <span>₹15,00,000</span>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
              <div className="rounded-2xl border border-border/80 bg-background p-4 text-center">
                <span className="text-[11px] text-muted-foreground block mb-1">
                  {isHi ? "अनुमानित क्षमता" : "Sizing"}
                </span>
                <span className="font-display text-2xl font-black text-foreground">
                  ~{estimatedKw} kW
                </span>
              </div>
              <div className="rounded-2xl border border-border/80 bg-background p-4 text-center">
                <span className="text-[11px] text-muted-foreground block mb-1">
                  {isHi ? "मासिक बचत" : "Monthly Savings"}
                </span>
                <span className="font-display text-xl sm:text-2xl font-black text-success">
                  ~₹{monthlySavings.toLocaleString("en-IN")}
                </span>
              </div>
              <div className="rounded-2xl border border-border/80 bg-background p-4 text-center">
                <span className="text-[11px] text-muted-foreground block mb-1">
                  {isHi ? "सालाना बचत" : "Annual Savings"}
                </span>
                <span className="font-display text-xl sm:text-2xl font-black text-success">
                  ~₹{(annualSavings / 100000).toFixed(1)} Lakh
                </span>
              </div>
              <div className="rounded-2xl border border-border/80 bg-background p-4 text-center">
                <span className="text-[11px] text-muted-foreground block mb-1">
                  {isHi ? "पेबैक अवधि" : "Est. Payback"}
                </span>
                <span className="font-display text-2xl font-black text-primary">
                  ~{approxPaybackYears} Years
                </span>
              </div>
            </div>

            <div className="text-center">
              <button
                onClick={() => setQuoteOpen(true)}
                className="inline-flex items-center gap-2 rounded-xl bg-primary px-7 py-3 text-sm font-bold text-primary-foreground shadow-sm hover:bg-primary-hover transition-all"
              >
                <span>
                  {isHi
                    ? `अपनी फैक्ट्री के लिए ${estimatedKw} kW का प्रस्ताव प्राप्त करें`
                    : `Request Detailed ${estimatedKw} kW Commercial Feasibility`}
                </span>
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>

        {/* 3. Industries We Serve */}
        <div className="mb-20">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <span className="text-xs font-bold uppercase tracking-wider text-primary">
              {isHi ? "उद्योग क्षेत्र" : "Key Industry Segments"}
            </span>
            <h2 className="mt-2 font-display text-2xl sm:text-3xl font-extrabold text-foreground">
              {isHi
                ? "बिहार के इन प्रमुख उद्योगों के लिए सोलर सबसे लाभदायक है"
                : "Engineered for High-Energy Industries Across Bihar"}
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {targetIndustries.map((item, idx) => (
              <div
                key={idx}
                className="group rounded-2xl border border-border bg-card overflow-hidden flex flex-col transition-all duration-300 hover:shadow-xl hover:-translate-y-1 hover:border-primary/40"
              >
                <div className="relative aspect-[4/3] overflow-hidden">
                  <img
                    src={item.img}
                    alt={isHi ? item.altHi : item.altEn}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-navy-premium/70 via-navy-premium/10 to-transparent pointer-events-none" />
                  <div className="absolute top-3 left-3 h-10 w-10 rounded-xl bg-primary/90 text-primary-foreground flex items-center justify-center shadow-lg ring-2 ring-white/20">
                    <Warehouse className="h-5 w-5" />
                  </div>
                </div>
                <div className="p-6 flex-1 flex flex-col">
                  <h3 className="font-display text-base font-bold text-foreground mb-2">
                    {isHi ? item.titleHi : item.titleEn}
                  </h3>
                  <p className="text-xs text-muted-foreground leading-relaxed flex-1">
                    {isHi ? item.descHi : item.descEn}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 4. Industrial EPC Engineering Standards */}
        <div className="mb-20 rounded-3xl border border-border bg-card/60 p-6 sm:p-10">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <span className="text-xs font-bold uppercase tracking-wider text-primary">
              {isHi ? "इंजीनियरिंग मानक" : "Industrial Standards"}
            </span>
            <h2 className="mt-2 font-display text-2xl sm:text-3xl font-extrabold text-foreground">
              {isHi
                ? "भारी औद्योगिक संयंत्रों के लिए उच्च गुणवत्ता वाले ईपीसी मानक"
                : "Robust Turnkey Engineering for Zero Plant Downtime"}
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {engineeringHighlights.map((item, idx) => (
              <div
                key={idx}
                className="group rounded-2xl border border-border bg-card overflow-hidden flex flex-col transition-all duration-300 hover:shadow-xl hover:-translate-y-1 hover:border-primary/40"
              >
                <div className="relative aspect-[16/10] overflow-hidden">
                  <img
                    src={item.img}
                    alt={isHi ? item.altHi : item.altEn}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-navy-premium/70 via-navy-premium/10 to-transparent pointer-events-none" />
                  <div className="absolute top-3 left-3 h-10 w-10 rounded-xl bg-primary/90 text-primary-foreground flex items-center justify-center shadow-lg ring-2 ring-white/20">
                    <CheckSquare2 className="h-5 w-5" />
                  </div>
                </div>
                <div className="p-6 flex-1 flex flex-col">
                  <h3 className="font-display text-base font-bold text-foreground mb-2 leading-snug">
                    {isHi ? item.titleHi : item.titleEn}
                  </h3>
                  <p className="text-xs text-muted-foreground leading-relaxed flex-1">
                    {isHi ? item.descHi : item.descEn}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 5. Closing CTA */}
        <div className="rounded-3xl border border-border bg-navy-dark text-white p-8 sm:p-12 text-center relative overflow-hidden">
          <div className="relative z-10 max-w-2xl mx-auto">
            <h3 className="font-display text-2xl sm:text-3xl font-extrabold text-cream-surface mb-3">
              {isHi
                ? "अपनी फैक्ट्री के लिए रूफटॉप सोलर ऑडिट शेड्यूल करें"
                : "Book an On-Site Commercial Solar Feasibility Audit"}
            </h3>
            <p className="text-xs sm:text-sm text-cream-surface/80 mb-6">
              {isHi
                ? "हमारी ईपीसी टीम आपकी फैक्ट्री का लोड पैटर्न देखकर सटीक सोलर क्षमता और बचत की फिजिबिलिटी रिपोर्ट देगी।"
                : "Elios engineers will perform a 3D shadow map and electrical load curve inspection for your commercial site."}
            </p>
            <button
              onClick={() => setQuoteOpen(true)}
              className="inline-flex items-center gap-2 rounded-xl bg-primary px-7 py-3.5 text-sm font-bold text-primary-foreground shadow-lg hover:bg-primary-hover transition-all"
            >
              <span>{t("getFreeQuotation")}</span>
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      <QuoteModal
        isOpen={quoteOpen}
        onClose={() => setQuoteOpen(false)}
        initialService="Commercial and Industrial"
      />
    </div>
  );
}
