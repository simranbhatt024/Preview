import { createFileRoute } from "@tanstack/react-router";
import { useLocale } from "../lib/locale-context";
import { CheckCircle, MessageCircle, ArrowRight, Sun, Phone } from "lucide-react";
import { CONTACT_INFO } from "../lib/constants";

export const Route = createFileRoute("/thank-you")({
  head: () => ({
    meta: [
      { title: "Thank You — Elios Solar Energy" },
      {
        name: "description",
        content: "Thank you for reaching out to Elios Solar Energy Bihar.",
      },
    ],
  }),
  component: ThankYouPage,
});

function ThankYouPage() {
  const { isHi } = useLocale();

  return (
    <div className="w-full bg-background py-16 sm:py-24">
      <div className="mx-auto max-w-2xl px-4 text-center">
        <div className="inline-flex items-center justify-center h-20 w-20 rounded-full bg-success/15 text-success mb-6">
          <CheckCircle className="h-10 w-10" />
        </div>

        <h1 className="font-display text-3xl sm:text-4xl font-extrabold text-foreground">
          {isHi ? "आपका अनुरोध सफलतापूर्वक प्राप्त हुआ!" : "Quotation Request Submitted!"}
        </h1>

        <p className="mt-3 text-base text-muted-foreground leading-relaxed">
          {isHi
            ? "हमारे तकनीकी सोलर विशेषज्ञ आपकी छत की रिपोर्ट और बचत विश्लेषण तैयार कर रहे हैं। शीघ्र परामर्श हेतु आप हमारे व्हाट्सएप पर सीधे संदेश भेज सकते हैं।"
            : "Our certified Bihar solar EPC engineering team has received your inquiry. For priority assistance, you can directly connect with us on WhatsApp."}
        </p>

        <div className="mt-8 flex flex-col sm:flex-row justify-center gap-4">
          <a
            href={CONTACT_INFO.whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-2 rounded-xl bg-success px-6 py-3 text-sm font-bold text-white shadow-sm hover:bg-success/90 transition-all"
          >
            <MessageCircle className="h-4 w-4" />
            <span>{isHi ? "व्हाट्सएप पर चैट करें" : "Chat on WhatsApp"}</span>
          </a>

          <a
            href="/"
            className="inline-flex items-center justify-center gap-2 rounded-xl border border-border bg-card px-6 py-3 text-sm font-semibold text-foreground hover:bg-muted transition-all"
          >
            <span>{isHi ? "होमपेज पर लौटें" : "Return to Homepage"}</span>
            <ArrowRight className="h-4 w-4" />
          </a>
        </div>
      </div>
    </div>
  );
}
