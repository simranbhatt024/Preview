import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useLocale } from "../lib/locale-context";
import { CONTACT_INFO } from "../lib/constants";
import { submitLeadToCRM } from "../lib/crm-tracking";
import { redirectToWhatsApp } from "../lib/whatsapp";
import {
  Phone,
  Mail,
  MapPin,
  Send,
  ShieldAlert,
  CheckCircle,
  MessageCircle,
  Clock,
} from "lucide-react";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact Us — Elios Solar Energy Bihar" },
      {
        name: "description",
        content:
          "Get in touch with Elios Solar Energy for rooftop solar inspection, PM Surya Ghar subsidy, and solar loan enquiries in Bihar.",
      },
      { property: "og:title", content: "Contact Us — Elios Solar Energy Bihar" },
    ],
    links: [{ rel: "canonical", href: "https://eliossolar.in/contact" }],
  }),
  component: ContactPage,
});

function ContactPage() {
  const { isHi, t } = useLocale();
  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [city, setCity] = useState("Patna");
  const [serviceNeeded, setServiceNeeded] = useState("Residential Homes");
  const [message, setMessage] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg("");

    const cleanPhone = phone.replace(/\D/g, "");
    if (!/^[6-9]\d{9}$/.test(cleanPhone)) {
      setErrorMsg(
        isHi
          ? "कृपया 10 अंकों का मान्य भारतीय मोबाइल नंबर दर्ज करें।"
          : "Please enter a valid 10-digit Indian mobile number.",
      );
      return;
    }

    // Save lead locally + push to CRM (non-blocking).
    submitLeadToCRM({
      formId: "elios-contact-form",
      formName: "Contact / Enquiry Form",
      fullName,
      phone: cleanPhone,
      email,
      city,
      serviceNeeded,
      source: "contact_form",
      message,
    });

    setSubmitted(true);
    const waText = `Hello Elios Solar Energy,\n\n*Name:* ${fullName}\n*Phone:* ${cleanPhone}\n*City:* ${city}\n*Service:* ${serviceNeeded}${message ? `\n*Message:* ${message}` : ""}`;
    redirectToWhatsApp(waText);
  };

  return (
    <div className="w-full bg-background py-12 sm:py-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs font-bold uppercase tracking-wider text-primary">
            {isHi ? "संपर्क करें" : "Get In Touch"}
          </span>
          <h1 className="mt-2 font-display text-3xl sm:text-5xl font-extrabold text-foreground">
            {isHi ? "सोलर इंजीनियरिंग टीम से सीधे जुड़ें" : "Talk to Our Solar Experts in Bihar"}
          </h1>
          <p className="mt-3 text-sm sm:text-base text-muted-foreground">
            {isHi
              ? "अपनी छत पर सोलर लगवाने, सब्सिडी जांचने या फ्री इंस्पेक्शन बुक करने के लिए फॉर्म भरें।"
              : "Reach out for free site surveys, subsidy assistance, commercial power assessments, or partnership queries."}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Contact Details Card */}
          <div className="lg:col-span-5 rounded-3xl border border-border bg-card p-6 sm:p-8 shadow-sm">
            <h3 className="font-display text-xl font-bold text-foreground mb-6">
              {isHi ? "कार्यालय संपर्क विवरण" : "Contact Information"}
            </h3>

            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="p-3 rounded-2xl bg-primary/10 text-primary shrink-0">
                  <Phone className="h-5 w-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
                    {isHi ? "फोन / व्हाट्सएप" : "Phone & WhatsApp"}
                  </h4>
                  <a
                    href={CONTACT_INFO.phoneTel}
                    className="mt-1 block text-base font-bold text-foreground hover:text-primary transition-colors"
                  >
                    {CONTACT_INFO.phone}
                  </a>
                  <a
                    href={CONTACT_INFO.whatsappUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-1 inline-flex items-center gap-1.5 text-xs font-semibold text-success hover:underline"
                  >
                    <MessageCircle className="h-3.5 w-3.5" />
                    <span>{isHi ? "व्हाट्सएप पर चैट करें" : "Chat on WhatsApp"}</span>
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="p-3 rounded-2xl bg-primary/10 text-primary shrink-0">
                  <Clock className="h-5 w-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
                    {isHi ? "कार्य समय" : "Working Hours"}
                  </h4>
                  <p className="mt-1 text-sm font-semibold text-foreground">
                    {isHi ? "सोमवार - शनिवार: सुबह 9:00 - शाम 7:00 IST" : CONTACT_INFO.hours}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {isHi ? "रविवार: आपातकालीन सहायता उपलब्ध" : "Sunday: Emergency support"}
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="p-3 rounded-2xl bg-primary/10 text-primary shrink-0">
                  <MapPin className="h-5 w-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
                    {isHi ? "सेवा क्षेत्र" : "Service Area"}
                  </h4>
                  <p className="mt-1 text-sm font-semibold text-foreground">
                    {isHi
                      ? "पटना एवं समस्त बिहार जिले"
                      : "Patna, Gaya, Muzaffarpur, Bhagalpur & all Bihar"}
                  </p>
                  <p className="text-xs text-muted-foreground">{CONTACT_INFO.state}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="lg:col-span-7 rounded-3xl border border-border bg-card p-6 sm:p-8 shadow-sm">
            {submitted ? (
              <div className="flex flex-col items-center py-12 text-center">
                <CheckCircle className="h-16 w-16 text-success animate-bounce" />
                <h3 className="mt-4 font-display text-2xl font-bold text-foreground">
                  {isHi ? "अनुरोध प्राप्त हुआ!" : "Request Received!"}
                </h3>
                <p className="mt-2 text-sm text-muted-foreground">
                  {isHi
                    ? "आपको व्हाट्सएप पर रिडायरेक्ट किया जा रहा है..."
                    : "Redirecting you to our official WhatsApp chat now..."}
                </p>
              </div>
            ) : (
              <div>
                <h3 className="font-display text-xl font-bold text-foreground mb-1">
                  {isHi ? "सोलर पूछताछ फॉर्म" : "Send Solar Inquiry"}
                </h3>
                <p className="text-xs text-muted-foreground mb-6">
                  {isHi
                    ? "फॉर्म जमा करने पर विवरण सुरक्षित सहेजा जाएगा एवं आप सीधे हमारे व्हाट्सएप पर जुड़ेंगे।"
                    : "Fill your details to connect directly with our engineering team on WhatsApp."}
                </p>

                {errorMsg && (
                  <div className="mb-4 flex items-center gap-2 rounded-lg bg-destructive/10 p-3 text-xs text-destructive">
                    <ShieldAlert className="h-4 w-4 shrink-0" />
                    <span>{errorMsg}</span>
                  </div>
                )}

                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-foreground mb-1">
                      {isHi ? "पूरा नाम" : "Full Name"} *
                    </label>
                    <input
                      type="text"
                      required
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder={isHi ? "उदा. राहुल कुमार" : "e.g. Rahul Kumar"}
                      className="w-full rounded-xl border border-border bg-background px-4 py-2.5 text-sm text-foreground focus:border-primary focus:outline-none"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-foreground mb-1">
                        {isHi ? "मोबाइल नंबर (10 अंक)" : "Phone Number (10 digits)"} *
                      </label>
                      <input
                        type="tel"
                        required
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="9876543210"
                        className="w-full rounded-xl border border-border bg-background px-4 py-2.5 text-sm text-foreground focus:border-primary focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-foreground mb-1">
                        {isHi ? "शहर (बिहार)" : "City (Bihar)"} *
                      </label>
                      <select
                        value={city}
                        onChange={(e) => setCity(e.target.value)}
                        className="w-full rounded-xl border border-border bg-background px-4 py-2.5 text-sm text-foreground focus:border-primary focus:outline-none"
                      >
                        <option value="Patna">Patna (पटना)</option>
                        <option value="Gaya">Gaya (गया)</option>
                        <option value="Muzaffarpur">Muzaffarpur (मुज़फ़्फ़रपुर)</option>
                        <option value="Bhagalpur">Bhagalpur (भागलपुर)</option>
                        <option value="Darbhanga">Darbhanga (दरभंगा)</option>
                        <option value="Purnia">Purnia (पूर्णिया)</option>
                        <option value="Other Bihar City">Other Bihar City</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-foreground mb-1">
                      {isHi ? "ईमेल पता (वैकल्पिक)" : "Email Address (Optional)"}
                    </label>
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="name@example.com"
                      className="w-full rounded-xl border border-border bg-background px-4 py-2.5 text-sm text-foreground focus:border-primary focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-foreground mb-1">
                      {isHi ? "सेवा की आवश्यकता" : "Service Needed"}
                    </label>
                    <select
                      value={serviceNeeded}
                      onChange={(e) => setServiceNeeded(e.target.value)}
                      className="w-full rounded-xl border border-border bg-background px-4 py-2.5 text-sm text-foreground focus:border-primary focus:outline-none"
                    >
                      <option value="Residential Homes">Residential Homes (आवासीय घर)</option>
                      <option value="Housing Society">Housing Society (हाउसिंग सोसाइटी)</option>
                      <option value="Commercial and Industrial">Commercial & Industrial</option>
                      <option value="Off-Grid Solar">Off-Grid Solar (बैटरी बैकअप)</option>
                      <option value="Products and Packages">Products & Annual Packages</option>
                      <option value="Partnership">Partnership</option>
                      <option value="Other">Other Enquiry</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-foreground mb-1">
                      {isHi ? "संदेश / छत का विवरण" : "Message / Project Details"}
                    </label>
                    <textarea
                      rows={3}
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      placeholder={
                        isHi
                          ? "अपनी छत का आकार, बिजली बिल या कोई प्रश्न लिखें..."
                          : "Mention your average monthly bill or solar requirements..."
                      }
                      className="w-full rounded-xl border border-border bg-background px-4 py-2.5 text-sm text-foreground focus:border-primary focus:outline-none"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full flex items-center justify-center gap-2 rounded-xl bg-primary py-3 text-sm font-bold text-primary-foreground shadow-sm hover:bg-primary-hover transition-all active:scale-95"
                  >
                    <span>{t("getFreeQuotation")}</span>
                    <Send className="h-4 w-4" />
                  </button>
                </form>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
