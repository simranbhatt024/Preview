import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useLocale } from "../lib/locale-context";
import { Award, ShieldAlert, CheckCircle, Gift } from "lucide-react";
import { submitLeadToCRM, CRM_CUSTOM_FIELDS } from "../lib/crm-tracking";
import { redirectToWhatsApp } from "../lib/whatsapp";

export const Route = createFileRoute("/become-a-partner/referral-program")({
  head: () => ({
    meta: [
      { title: "Solar Referral Program — Elios Solar Energy Bihar" },
      {
        name: "description",
        content:
          "Earn rewards and incentives by referring rooftop solar projects to homeowners and commercial buildings in Bihar.",
      },
      { property: "og:title", content: "Solar Referral Program — Elios Solar Energy Bihar" },
    ],
  }),
  component: ReferralProgramPage,
});

const HERO_IMG =
  "https://vibe.filesafe.space/1792820769937918655/assets/5fa4cd54-ff61-4975-8dd7-79f504abb667.png";

const BENEFITS = [
  {
    icon: Gift,
    titleEn: "Earn Per Commissioned Rooftop",
    titleHi: "प्रति सफल इंस्टॉलेशन इंसेंटिव",
    descEn: "Direct incentive credit upon successful site commissioning and net-metering.",
    descHi: "हर सफल रूफटॉप सोलर स्थापना के बाद पारदर्शी भुगतान।",
    img: "https://vibe.filesafe.space/1792820769937918655/assets/f7a4e2fa-a1fb-4643-8cef-5beae03bbdaf.png",
    altEn:
      "Two professionals shaking hands in front of a rooftop solar installation at golden hour, representing a successful referral commissioning",
    altHi:
      "सुनहरी शाम में रूफटॉप सोलर इंस्टॉलेशन के सामने हाथ मिलाते हुए दो पेशेवर, सफल रेफरल कमीशनिंग का प्रतीक",
  },
  {
    icon: Award,
    titleEn: "100% Technical Support by Elios",
    titleHi: "पूर्ण तकनीकी सहायता",
    descEn: "Our in-house engineers manage roof inspection, DISCOM net metering, and installation.",
    descHi: "छत का सर्वे, सब्सिडी आवेदन और इंस्टॉलेशन हमारी टीम संभालती है।",
    img: "https://vibe.filesafe.space/1792820769937918655/assets/e6726a89-24af-4f8e-90a1-3a6e04ffe016.png",
    altEn:
      "A solar engineer technician in a navy uniform inspecting rooftop solar panels while holding a monitoring tablet",
    altHi:
      "नेवी यूनिफॉर्म में सोलर इंजीनियर टेक्नीशियन मॉनिटरिंग टैबलेट पकड़े हुए रूफटॉप सोलर पैनलों की जांच करते हुए",
  },
];

function ReferralProgramPage() {
  const { isHi } = useLocale();
  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");
  const [city, setCity] = useState("Patna");
  const [referralCount, setReferralCount] = useState("1-3 Rooftops");
  const [submitted, setSubmitted] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg("");

    const cleanPhone = phone.replace(/\D/g, "");
    if (!/^[6-9]\d{9}$/.test(cleanPhone)) {
      setErrorMsg(
        isHi
          ? "कृपया 10 अंकों का मान्य भारतीय मोबाइल नंबर दर्ज करें।"
          : "Please enter a valid 10-digit Indian mobile number.",
      );
      return;
    }

    // Save lead locally + push to CRM (non-blocking).
    submitLeadToCRM({
      formId: "elios-referral-program",
      formName: "Referral Program Application",
      fullName,
      phone: cleanPhone,
      city,
      serviceNeeded: "Partnership",
      source: "referral_program",
      message: `Expected referrals: ${referralCount}`,
      custom: {
        [CRM_CUSTOM_FIELDS.estimatedReferrals]: {
          value: referralCount,
          label: "Estimated Referrals",
        },
      },
    });

    setSubmitted(true);
    const waText = `Hello Elios Solar Energy,\n\nI want to register for your *Solar Referral Program*:\n\n*Name:* ${fullName}\n*Phone:* ${cleanPhone}\n*City:* ${city}\n*Referral Network:* ${referralCount}`;
    redirectToWhatsApp(waText);
  };

  return (
    <div className="w-full bg-background py-12 sm:py-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        {/* Hero */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center mb-14">
          <div className="text-center lg:text-left">
            <span className="text-xs font-bold uppercase tracking-wider text-primary">
              {isHi ? "पार्टनर प्रोग्राम" : "Partner Program"}
            </span>
            <h1 className="mt-2 font-display text-3xl sm:text-5xl font-extrabold text-foreground leading-tight">
              {isHi ? "एलियोस सोलर रेफरल प्रोग्राम" : "Elios Solar Referral Program"}
            </h1>
            <p className="mt-4 text-base text-muted-foreground max-w-xl mx-auto lg:mx-0">
              {isHi
                ? "बिहार में अपने मित्रों, पड़ोसियों और व्यावसायिक संपर्कों को सोलर अपनाने में मदद करें और आकर्षक इंसेंटिव प्राप्त करें।"
                : "Help homeowners and businesses switch to clean solar energy and earn rewarding referral bonuses across Bihar."}
            </p>
            <div className="mt-6 flex flex-wrap gap-3 justify-center lg:justify-start">
              <a
                href="#register"
                className="inline-flex items-center rounded-xl bg-primary px-5 py-3 text-sm font-bold text-primary-foreground shadow-sm hover:bg-primary-hover transition-all active:scale-95"
              >
                {isHi ? "रेफरल पार्टनर बनें" : "Join Referral Program"}
              </a>
              <a
                href="#benefits"
                className="inline-flex items-center rounded-xl border border-border bg-card px-5 py-3 text-sm font-semibold text-foreground hover:border-primary/40 transition-all"
              >
                {isHi ? "कार्यक्रम के लाभ देखें" : "See Program Benefits"}
              </a>
            </div>
          </div>
          <div className="relative rounded-3xl overflow-hidden border border-border shadow-xl">
            <img
              src={HERO_IMG}
              alt={
                isHi
                  ? "बिहार में रूफटॉप सोलर पैनलों के साथ एक पड़ोस, रेफरल नेटवर्क सोलर अपनाव का प्रतिनिधित्व"
                  : "A Bihar neighborhood with rooftop solar panels, representing a referral network spreading solar adoption"
              }
              className="w-full h-64 sm:h-80 lg:h-96 object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-navy-premium/60 via-transparent to-transparent pointer-events-none" />
          </div>
        </div>

        <div
          id="benefits"
          className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start max-w-6xl mx-auto"
        >
          {/* Program Highlights with images */}
          <div className="lg:col-span-5 space-y-6">
            <h3 className="font-display text-xl font-bold text-foreground px-1">
              {isHi ? "रेफरल के लाभ" : "Why Join the Program?"}
            </h3>
            {BENEFITS.map((b) => {
              const Icon = b.icon;
              return (
                <div
                  key={b.titleEn}
                  className="group rounded-2xl border border-border bg-card overflow-hidden flex flex-col transition-all duration-300 hover:shadow-xl hover:-translate-y-1 hover:border-primary/40"
                >
                  <div className="relative aspect-[16/10] overflow-hidden">
                    <img
                      src={b.img}
                      alt={isHi ? b.altHi : b.altEn}
                      loading="lazy"
                      className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-navy-premium/70 via-navy-premium/10 to-transparent pointer-events-none" />
                    <div className="absolute top-3 left-3 h-10 w-10 rounded-xl bg-primary/90 text-primary-foreground flex items-center justify-center shadow-lg ring-2 ring-white/20">
                      <Icon className="h-5 w-5" />
                    </div>
                  </div>
                  <div className="p-5 flex-1 flex flex-col">
                    <h4 className="font-display text-base font-bold text-foreground mb-1.5 leading-snug">
                      {isHi ? b.titleHi : b.titleEn}
                    </h4>
                    <p className="text-xs text-muted-foreground leading-relaxed flex-1">
                      {isHi ? b.descHi : b.descEn}
                    </p>
                  </div>
                </div>
              );
            })}

            <p className="text-[11px] text-muted-foreground italic border-t border-border pt-4 px-1">
              {isHi
                ? "ASCI दिशानिर्देश: सोशल मीडिया प्रचारक एवं इन्फ्लुएंसर अपने कंटेंट में उचित विज्ञापन प्रकटीकरण शामिल करें।"
                : "Influencer disclosure: Influencers must include appropriate sponsorship tags per ASCI guidelines."}
            </p>
          </div>

          {/* Registration Form */}
          <div
            id="register"
            className="lg:col-span-7 rounded-3xl border border-border bg-card p-6 sm:p-8 shadow-sm lg:sticky lg:top-24"
          >
            {submitted ? (
              <div className="flex flex-col items-center py-10 text-center">
                <CheckCircle className="h-14 w-14 text-success animate-bounce" />
                <h3 className="mt-3 font-display text-xl font-bold text-foreground">
                  {isHi ? "रेफरल पंजीकरण सफल!" : "Referral Registration Received!"}
                </h3>
                <p className="mt-2 text-xs text-muted-foreground">
                  {isHi
                    ? "आपको व्हाट्सएप पर आधिकारिक बातचीत के लिए भेजा जा रहा है..."
                    : "Redirecting you to our official WhatsApp chat..."}
                </p>
              </div>
            ) : (
              <div>
                <h3 className="font-display text-xl font-bold text-foreground mb-1">
                  {isHi ? "रेफरल पार्टनर के रूप में जुड़ें" : "Register as a Referral Partner"}
                </h3>
                <p className="text-xs text-muted-foreground mb-6">
                  {isHi
                    ? "फॉर्म जमा करने के बाद आप तुरंत हमारे व्हाट्सएप सपोर्ट से जुड़ेंगे।"
                    : "Submit your details to connect directly with our partner onboarding desk on WhatsApp."}
                </p>

                {errorMsg && (
                  <div className="mb-4 flex items-center gap-2 rounded-lg bg-destructive/10 p-3 text-xs text-destructive">
                    <ShieldAlert className="h-4 w-4 shrink-0" />
                    <span>{errorMsg}</span>
                  </div>
                )}

                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-foreground mb-1">
                      {isHi ? "पूरा नाम" : "Full Name"} *
                    </label>
                    <input
                      type="text"
                      required
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder={isHi ? "उदा. विकास कुमार" : "e.g. Vikas Kumar"}
                      className="w-full rounded-xl border border-border bg-background px-4 py-2.5 text-sm text-foreground focus:border-primary focus:outline-none"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-foreground mb-1">
                        {isHi ? "मोबाइल नंबर (10 अंक)" : "Phone Number"} *
                      </label>
                      <input
                        type="tel"
                        required
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="9876543210"
                        className="w-full rounded-xl border border-border bg-background px-4 py-2.5 text-sm text-foreground focus:border-primary focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-foreground mb-1">
                        {isHi ? "आपका शहर (बिहार)" : "City (Bihar)"} *
                      </label>
                      <select
                        value={city}
                        onChange={(e) => setCity(e.target.value)}
                        className="w-full rounded-xl border border-border bg-background px-4 py-2.5 text-sm text-foreground focus:border-primary focus:outline-none"
                      >
                        <option value="Patna">Patna (पटना)</option>
                        <option value="Gaya">Gaya (गया)</option>
                        <option value="Muzaffarpur">Muzaffarpur (मुज़फ़्फ़रपुर)</option>
                        <option value="Bhagalpur">Bhagalpur (भागलपुर)</option>
                        <option value="Darbhanga">Darbhanga (दरभंगा)</option>
                        <option value="Purnia">Purnia (पूर्णिया)</option>
                        <option value="Other Bihar District">Other Bihar District</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-foreground mb-1">
                      {isHi ? "संभावित रेफरल संख्या" : "Estimated Potential Leads / Month"}
                    </label>
                    <select
                      value={referralCount}
                      onChange={(e) => setReferralCount(e.target.value)}
                      className="w-full rounded-xl border border-border bg-background px-4 py-2.5 text-sm text-foreground focus:border-primary focus:outline-none"
                    >
                      <option value="1-3 Rooftops">1-3 Rooftops (1-3 छतें)</option>
                      <option value="4-10 Rooftops">4-10 Rooftops (4-10 छतें)</option>
                      <option value="10+ Commercial/Society">
                        10+ Commercial / Society Projects
                      </option>
                    </select>
                  </div>

                  <button
                    type="submit"
                    className="w-full rounded-xl bg-primary py-3 text-sm font-bold text-primary-foreground shadow-sm hover:bg-primary-hover transition-all active:scale-95"
                  >
                    <span>{isHi ? "रेफरल पार्टनर बनें" : "Join Referral Program"}</span>
                  </button>
                </form>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
