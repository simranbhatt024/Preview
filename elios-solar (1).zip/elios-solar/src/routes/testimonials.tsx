import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/testimonials")({
  head: () => ({
    meta: [
      { title: "Customer Testimonials — Elios Solar Energy" },
      {
        name: "description",
        content: "Read rooftop solar success stories and customer experiences across Bihar.",
      },
    ],
  }),
  component: () => <div className="p-8">Testimonials</div>,
});
