import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useLocale } from "../lib/locale-context";
import { SolarCalculatorWidget } from "../components/SolarCalculatorWidget";
import { QuoteModal } from "../components/QuoteModal";
import { Calculator } from "lucide-react";

export const Route = createFileRoute("/solar-calculator")({
  head: () => ({
    meta: [
      { title: "Solar Savings & Subsidy Calculator — Elios Solar Energy" },
      {
        name: "description",
        content:
          "Calculate your recommended rooftop solar plant capacity, estimated bill reduction, and PM Surya Ghar subsidy in Bihar.",
      },
      { property: "og:title", content: "Solar Calculator — Elios Solar Energy" },
    ],
  }),
  component: SolarCalculatorPage,
});

function SolarCalculatorPage() {
  const { isHi, t } = useLocale();
  const [quoteOpen, setQuoteOpen] = useState(false);
  const [leadDetail, setLeadDetail] = useState("Calculator");

  return (
    <div className="w-full bg-background py-12 sm:py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-3.5 py-1 text-xs font-semibold text-foreground mb-4">
            <Calculator className="h-3.5 w-3.5 text-primary" />
            <span>{isHi ? "तुरंत आकलन" : "Interactive ROI Estimator"}</span>
          </div>
          <h1 className="font-display text-3xl sm:text-5xl font-extrabold text-foreground">
            {isHi ? "सोलर रूफटॉप बचत कैलकुलेटर" : "Rooftop Solar Savings Calculator"}
          </h1>
          <p className="mt-3 text-sm sm:text-base text-muted-foreground">
            {isHi
              ? "अपने मासिक बिजली बिल के आधार पर आवश्यक किलोवाट आकार, वार्षिक बचत और पीएम सूर्य घर सब्सिडी की जानकारी प्राप्त करें।"
              : "Discover your optimal solar plant capacity, anticipated payback timeline, and eligible subsidy benefits in Bihar."}
          </p>
        </div>

        <SolarCalculatorWidget
          onGetExactQuote={(data) => {
            setLeadDetail(`Calculator (${data.recommendedKw} kW)`);
            setQuoteOpen(true);
          }}
        />
      </div>

      <QuoteModal
        isOpen={quoteOpen}
        onClose={() => setQuoteOpen(false)}
        initialService="Residential Homes"
        initialMessage={leadDetail}
      />
    </div>
  );
}
