import { createFileRoute, Link } from "@tanstack/react-router";
import { Shield, Lock, FileText, CheckCircle2, Mail, Phone, MapPin } from "lucide-react";
import { CONTACT_INFO } from "../lib/constants";

export const Route = createFileRoute("/privacy")({
  head: () => ({
    meta: [
      { title: "Privacy Policy — Elios Solar Energy" },
      {
        name: "description",
        content:
          "Elios Solar Energy Privacy Policy. Read how we collect, process, protect, and safeguard your personal data under Indian laws.",
      },
      { property: "og:title", content: "Privacy Policy — Elios Solar Energy" },
      {
        property: "og:description",
        content:
          "How Elios Solar Energy protects customer data, handles inquiries, and complies with data protection standards.",
      },
    ],
  }),
  component: PrivacyPage,
});

function PrivacyPage() {
  return (
    <div className="bg-background text-foreground min-h-screen py-12 px-4 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-4xl">
        {/* Header Banner */}
        <div className="rounded-3xl bg-secondary text-secondary-foreground p-8 sm:p-12 mb-10 border border-border/20 shadow-xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-96 h-96 bg-primary/10 rounded-full blur-3xl pointer-events-none" />
          <div className="relative z-10">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/20 text-primary-foreground text-xs font-semibold mb-4">
              <Shield className="h-4 w-4" />
              <span>Legal & Compliance</span>
            </div>
            <h1 className="font-display text-3xl sm:text-5xl font-extrabold text-white tracking-tight mb-4">
              Privacy Policy
            </h1>
            <p className="text-secondary-foreground/80 text-sm sm:text-base max-w-2xl leading-relaxed">
              This Privacy Policy governs your use of the website and services provided by Elios
              Solar Energy. We are committed to protecting your personal information and ensuring
              full transparency.
            </p>
            <div className="mt-6 flex flex-wrap gap-4 text-xs text-secondary-foreground/70">
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="h-4 w-4 text-primary" /> Last updated: October 2026
              </span>
              <span className="flex items-center gap-1.5">
                <Lock className="h-4 w-4 text-primary" /> Governed by Indian Data Protection Laws
              </span>
            </div>
          </div>
        </div>

        {/* Table of Contents Quick Nav */}
        <div className="rounded-2xl bg-card border border-border p-6 mb-10 shadow-sm">
          <h2 className="font-display text-lg font-bold text-foreground mb-3 flex items-center gap-2">
            <FileText className="h-5 w-5 text-primary" />
            <span>Table of Contents</span>
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm text-muted-foreground">
            <a href="#scope" className="hover:text-primary transition-colors">
              1. Scope
            </a>
            <a href="#information-collected" className="hover:text-primary transition-colors">
              2. Information We May Collect From You
            </a>
            <a href="#use-of-information" className="hover:text-primary transition-colors">
              3. Use of Your Information
            </a>
            <a href="#retention-deletion" className="hover:text-primary transition-colors">
              4. Retention, Deletion or Blocking of Data
            </a>
            <a href="#cookies" className="hover:text-primary transition-colors">
              5. Cookies
            </a>
            <a href="#security" className="hover:text-primary transition-colors">
              6. Information Security
            </a>
            <a href="#revision" className="hover:text-primary transition-colors">
              7. Revision of Privacy Policy
            </a>
            <a href="#third-party-links" className="hover:text-primary transition-colors">
              8. Links to Third-Party Websites
            </a>
            <a href="#advertisements" className="hover:text-primary transition-colors">
              9. Advertisements on Website
            </a>
            <a href="#consent" className="hover:text-primary transition-colors">
              10. Consent
            </a>
            <a href="#governing-laws" className="hover:text-primary transition-colors">
              11. Governing Laws & Jurisdiction
            </a>
            <a href="#grievances" className="hover:text-primary transition-colors">
              12. Grievances
            </a>
          </div>
        </div>

        {/* Policy Body */}
        <div className="prose prose-slate max-w-none space-y-10 text-foreground/90 text-sm sm:text-base leading-relaxed">
          <p className="text-base font-medium leading-relaxed bg-muted/40 p-5 rounded-xl border border-border/50">
            This Privacy Policy (“Policy”) is a legally binding electronic agreement between you
            (“You,” “Your,” or “User”) and Elios Solar Energy (“Company,” “We,” “Us,” or “Our”).
            This Policy governs your use of the website(s) and any services provided by the Company
            (collectively, the “Website”).
          </p>

          <p>
            This Policy is governed by and shall be interpreted in accordance with applicable laws
            of India. It does not require any physical, electronic, or digital signature and shall
            be deemed to be accepted by You upon use of the Website or by submitting an enquiry or
            clicking “I Accept” where such an option is provided.
          </p>

          <p>
            We value and respect your privacy and are committed to protecting your personal
            information. This Privacy Policy sets out the principles and practices that govern the
            collection, use, processing, and disclosure of personal information by the Company in
            connection with your access to and use of the Website and/or our rooftop solar EPC and
            annual service packages.
          </p>

          {/* Section 1 */}
          <section id="scope" className="scroll-mt-24 border-t border-border/60 pt-8">
            <h2 className="font-display text-xl font-bold text-foreground mb-3">1. SCOPE</h2>
            <p>
              The Company values the privacy of individuals and is committed to handling personal
              information responsibly and in compliance with applicable legal and regulatory
              requirements. This Privacy Policy outlines the Company’s approach to the collection,
              use, processing, storage, and disclosure of personal information in connection with
              your access to and use of the Website and/or our Services. All personal information
              shall be processed in accordance with this Policy and applicable laws. Nothing in this
              Policy shall be construed to create obligations on the Company beyond those imposed
              under applicable law.
            </p>
          </section>

          {/* Section 2 */}
          <section
            id="information-collected"
            className="scroll-mt-24 border-t border-border/60 pt-8"
          >
            <h2 className="font-display text-xl font-bold text-foreground mb-3">
              2. INFORMATION WE MAY COLLECT FROM YOU
            </h2>
            <p>
              When you access or use our Website, we may collect and process certain personal
              information that you voluntarily provide (e.g., when requesting a free rooftop
              quotation, solar calculator estimate, rooftop inspection, partnership enquiry, or
              career application). The primary purpose of collecting this information is to
              facilitate a secure, efficient, and personalized user experience. It enables us to
              offer relevant solar solutions, site inspection engineering, subsidy guidance, and
              customer support.
            </p>
            <p className="mt-3">
              You may generally browse the Website without disclosing personal information. However,
              once you voluntarily submit details such as your name, phone number, email, city,
              rooftop area, or electricity bill consumption, you are no longer anonymous to us.
            </p>
            <p className="mt-3">
              We may also automatically collect technical data relating to your interaction with the
              Website, such as referring URLs, browser type, IP address, general geolocation, device
              identifiers, and standard web log information for internal analytics and site
              optimization.
            </p>
          </section>

          {/* Section 3 */}
          <section id="use-of-information" className="scroll-mt-24 border-t border-border/60 pt-8">
            <h2 className="font-display text-xl font-bold text-foreground mb-3">
              3. USE OF YOUR INFORMATION
            </h2>
            <p>
              We may use this information to fulfill our obligations under any agreements entered
              into between you and the Company, and to provide you with the solar products,
              feasibility reports, DISCOM net metering updates, subsidy processing, and annual
              service plans you requested.
            </p>

            <ul className="list-disc pl-5 space-y-2 mt-3">
              <li>To schedule rooftop solar site surveys and engineering assessments in Bihar.</li>
              <li>
                To estimate system sizing, subsidy eligibility under PM Surya Ghar Muft Bijli
                Yojana, and loan EMI options.
              </li>
              <li>
                To communicate project status, DISCOM approvals, and after-sales maintenance visits.
              </li>
              <li>
                To respond to user queries submitted via live chat, contact forms, or WhatsApp
                requests.
              </li>
              <li>
                To comply with regulatory obligations and legal requests under Indian statutory
                authorities.
              </li>
            </ul>
          </section>

          {/* Section 4 */}
          <section id="retention-deletion" className="scroll-mt-24 border-t border-border/60 pt-8">
            <h2 className="font-display text-xl font-bold text-foreground mb-3">
              4. RETENTION, DELETION OR BLOCKING OF DATA
            </h2>
            <p>
              We adhere to the principles of purpose limitation and data minimization. Accordingly,
              we retain your personal data only for as long as is reasonably necessary to fulfill
              the purposes for which it was collected, unless you withdraw your consent earlier or a
              longer retention period is required or permitted under applicable law.
            </p>
            <p className="mt-3">
              Upon completion or discontinuation of the relevant service, or the expiry of any
              legally mandated retention period, we will take reasonable steps to securely delete or
              anonymize the corresponding data. You have the right to request access to your
              personal data or request deletion by contacting our grievance team.
            </p>
          </section>

          {/* Section 5 */}
          <section id="cookies" className="scroll-mt-24 border-t border-border/60 pt-8">
            <h2 className="font-display text-xl font-bold text-foreground mb-3">5. COOKIES</h2>
            <p>
              To enhance user experience and Website responsiveness, we may use cookies or similar
              technologies to assign each visitor a unique, random User Identification (User ID)
              that helps us understand user preferences based on device activity.
            </p>
            <p className="mt-3">
              Cookies cannot access data from your device’s hard drive. Most cookies are
              session-based and expire upon closure of the browser. You may disable cookies via
              browser settings, though certain website functionalities or saved calculator inputs
              may be affected.
            </p>
          </section>

          {/* Section 6 */}
          <section id="security" className="scroll-mt-24 border-t border-border/60 pt-8">
            <h2 className="font-display text-xl font-bold text-foreground mb-3">
              6. INFORMATION SECURITY
            </h2>
            <p>
              We recognize that the information provided by our users is a valuable asset. We do not
              sell personal information to third parties. All personal information collected through
              the Website is stored in a secure, access-controlled environment protected by
              encryption and firewalls.
            </p>
            <p className="mt-3">
              While we maintain appropriate security safeguards, no method of electronic
              transmission or storage is entirely secure, and we cannot guarantee absolute
              protection.
            </p>
          </section>

          {/* Section 7 */}
          <section id="revision" className="scroll-mt-24 border-t border-border/60 pt-8">
            <h2 className="font-display text-xl font-bold text-foreground mb-3">
              7. REVISION OF THE PRIVACY POLICY
            </h2>
            <p>
              This Privacy Policy may be amended, modified, or updated at any time at the sole
              discretion of Elios Solar Energy, without prior individual notice. Any revisions will
              become effective upon being published on the Website. Your continued access or use of
              the Website following any such changes shall be deemed to constitute your acceptance
              of the revised Privacy Policy.
            </p>
          </section>

          {/* Section 8 */}
          <section id="third-party-links" className="scroll-mt-24 border-t border-border/60 pt-8">
            <h2 className="font-display text-xl font-bold text-foreground mb-3">
              8. LINKS TO THIRD-PARTY WEBSITES
            </h2>
            <p>
              This Website may include links to third-party websites or online portals (such as
              official PM Surya Ghar government portals, DISCOM portals, or partner lending bank
              links). We do not endorse and are not responsible for the privacy practices, content,
              or security of such external platforms.
            </p>
          </section>

          {/* Section 9 */}
          <section id="advertisements" className="scroll-mt-24 border-t border-border/60 pt-8">
            <h2 className="font-display text-xl font-bold text-foreground mb-3">
              9. ADVERTISEMENTS ON WEBSITE
            </h2>
            <p>
              We may engage third-party analytics or communication service providers to measure
              website usage and manage user inquiries. These entities may collect non-personally
              identifiable technical usage metrics in compliance with applicable law.
            </p>
          </section>

          {/* Section 10 */}
          <section id="consent" className="scroll-mt-24 border-t border-border/60 pt-8">
            <h2 className="font-display text-xl font-bold text-foreground mb-3">10. CONSENT</h2>
            <p>
              By accessing or using this Website and/or voluntarily providing personal information,
              you expressly consent to the collection, processing, use, storage, and disclosure of
              such information in accordance with this Privacy Policy.
            </p>
          </section>

          {/* Section 11 */}
          <section id="governing-laws" className="scroll-mt-24 border-t border-border/60 pt-8">
            <h2 className="font-display text-xl font-bold text-foreground mb-3">
              11. GOVERNING LAWS & JURISDICTION
            </h2>
            <p>
              This Website is operated by Elios Solar Energy from Bihar, India. These Terms and
              Privacy Policy shall be governed by and interpreted in accordance with the laws of
              India. Any dispute arising out of or relating to this Privacy Policy shall be subject
              to the exclusive jurisdiction of the competent courts in Patna, Bihar, India.
            </p>
          </section>

          {/* Section 12 */}
          <section id="grievances" className="scroll-mt-24 border-t border-border/60 pt-8">
            <h2 className="font-display text-xl font-bold text-foreground mb-3">
              12. GRIEVANCES & CONTACT
            </h2>
            <p>
              If you have any questions, concerns, or requests regarding this Privacy Policy or our
              data handling practices, please contact our team:
            </p>

            <div className="mt-4 rounded-2xl bg-card border border-border p-6 space-y-3">
              <div className="flex items-center gap-3 text-foreground font-semibold">
                <Shield className="h-5 w-5 text-primary" />
                <span>Elios Solar Energy — Compliance Officer</span>
              </div>
              <div className="flex items-center gap-3 text-muted-foreground text-sm">
                <Phone className="h-4 w-4 text-primary" />
                <a href={CONTACT_INFO.phoneTel} className="hover:text-primary transition-colors">
                  {CONTACT_INFO.phone}
                </a>
              </div>
              <div className="flex items-center gap-3 text-muted-foreground text-sm">
                <MapPin className="h-4 w-4 text-primary" />
                <span>{CONTACT_INFO.state}</span>
              </div>
            </div>
          </section>
        </div>

        {/* Bottom Callout */}
        <div className="mt-12 text-center border-t border-border pt-8 text-xs text-muted-foreground">
          Need legal clarification?{" "}
          <Link to="/contact" className="text-primary hover:underline font-semibold">
            Contact our customer team
          </Link>{" "}
          or view our{" "}
          <Link to="/terms" className="text-primary hover:underline font-semibold">
            Terms & Conditions
          </Link>
          .
        </div>
      </div>
    </div>
  );
}
