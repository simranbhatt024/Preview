import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useLocale } from "../lib/locale-context";
import { ASSETS } from "../lib/constants";
import { HeroSection } from "../components/home/HeroSection";
import { ServicesShowcase } from "../components/home/ServicesShowcase";
import { SolarLoanSection } from "../components/home/SolarLoanSection";
import { EpcSection } from "../components/home/EpcSection";
import { OfferingsSection } from "../components/home/OfferingsSection";
import { SolarJourneySection } from "../components/home/SolarJourneySection";
import { LeafDecor } from "../components/home/LeafDecor";
import { InteractiveRooftop } from "../components/InteractiveRooftop";
import { SolarCalculatorWidget } from "../components/SolarCalculatorWidget";
import { PackagesComparison } from "../components/PackagesComparison";
import { BiharMapSection } from "../components/BiharMapSection";
import { QuoteModal } from "../components/QuoteModal";
import { ArrowRight } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Elios Solar Energy — Rooftop Solar EPC in Bihar" },
      {
        name: "description",
        content:
          "Cut your electricity bill. Free rooftop inspection, PM Surya Ghar subsidy up to ₹78,000, and easy EMI loans across Bihar.",
      },
      { property: "og:title", content: "Elios Solar Energy — Rooftop Solar EPC in Bihar" },
      {
        property: "og:description",
        content:
          "End-to-end solar engineering, procurement and installation for homes, housing societies and businesses across Bihar.",
      },
      { property: "og:type", content: "website" },
      { property: "og:image", content: ASSETS.residentialHero },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://eliossolar.in/" }],
  }),
  component: IndexPage,
});

function IndexPage() {
  const { t, isHi } = useLocale();
  const [quoteModalOpen, setQuoteModalOpen] = useState(false);
  const [selectedService, setSelectedService] = useState("Residential Homes");

  const openQuote = (service = "Residential Homes") => {
    setSelectedService(service);
    setQuoteModalOpen(true);
  };

  const localBusinessSchema = {
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    name: "Elios Solar Energy",
    description:
      "Rooftop Solar EPC Company in Bihar, India providing PM Surya Ghar subsidy and solar installation services.",
    url: "https://eliossolar.in",
    telephone: "+919153933318",
    priceRange: "₹₹",
    areaServed: {
      "@type": "State",
      name: "Bihar",
    },
    address: {
      "@type": "PostalAddress",
      addressRegion: "Bihar",
      addressCountry: "IN",
    },
  };

  return (
    <div className="w-full bg-background text-foreground overflow-hidden">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(localBusinessSchema) }}
      />
      {/* 1. Hero */}
      <HeroSection onOpenQuote={openQuote} />

      {/* 1b. Solar Journey Timeline */}
      <SolarJourneySection onOpenQuote={openQuote} />

      {/* 2. Interactive Rooftop */}
      <section className="relative py-16 sm:py-20 border-b border-border/40 bg-cream-premium overflow-hidden">
        <LeafDecor variant="light" density="medium" />
        <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <span className="inline-flex items-center gap-2 rounded-full bg-white/70 backdrop-blur-sm border border-primary/30 px-4 py-1 text-xs font-bold uppercase tracking-wider text-primary shadow-sm">
              {isHi ? "रूफटॉप तकनीक" : "Interactive Rooftop"}
            </span>
            <h2 className="mt-3 font-display text-3xl sm:text-4xl font-extrabold text-foreground drop-shadow-sm">
              {isHi
                ? "आपकी छत पर सोलर कैसे काम करता है"
                : "How Solar Generates Clean Power on Your Roof"}
            </h2>
          </div>

          <InteractiveRooftop />

          <div className="mt-8 text-center">
            <a
              href="/solar-solutions/residential-homes"
              className="inline-flex items-center gap-2 text-sm font-bold text-primary hover:underline"
            >
              <span>{t("seeSolutions")}</span>
              <ArrowRight className="h-4 w-4" />
            </a>
          </div>
        </div>
      </section>

      {/* 3. Services Showcase (4 Cards) */}
      <ServicesShowcase onOpenQuote={openQuote} />

      {/* 4. Solar Calculator */}
      <section className="py-16 sm:py-24 border-b border-border/40 bg-navy-premium">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <span className="text-xs font-bold uppercase tracking-wider text-primary-light">
              {isHi ? "सटीक बचत कैलकुलेटर" : "Instant Solar ROI"}
            </span>
            <h2 className="mt-2 font-display text-3xl sm:text-4xl font-extrabold text-cream-surface">
              {isHi
                ? "अपने बिजली बिल के अनुसार सोलर बचत जानें"
                : "Calculate Your Rooftop Solar Savings"}
            </h2>
          </div>

          <SolarCalculatorWidget
            onGetExactQuote={(data) => openQuote(`Calculator: ${data.recommendedKw} kW`)}
          />
        </div>
      </section>

      {/* 5. Solar Loan */}
      <SolarLoanSection onOpenQuote={openQuote} />

      {/* 6. What is EPC */}
      <EpcSection onOpenQuote={openQuote} />

      {/* 7. Comprehensive Offerings */}
      <OfferingsSection onOpenQuote={openQuote} />

      {/* 8. Annual Care Packages */}
      <section className="py-16 sm:py-24 border-b border-border/40 bg-cream-premium">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="text-center max-w-2xl mx-auto mb-14">
            <span className="text-xs font-bold uppercase tracking-wider text-primary">
              {isHi ? "रख-रखाव एवं सुरक्षा" : "Annual Solar Care"}
            </span>
            <h2 className="mt-2 font-display text-3xl sm:text-4xl font-extrabold text-foreground">
              {isHi ? "एलियोस वार्षिक सोलर केयर पैकेज" : "Elios Annual Solar Maintenance Packages"}
            </h2>
          </div>

          <PackagesComparison onSelectPackage={(pkgName) => openQuote(`Package: ${pkgName}`)} />
        </div>
      </section>

      {/* 9. Bihar Map Network */}
      <section className="py-16 sm:py-24 bg-navy-premium border-b border-border/40">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <span className="text-xs font-bold uppercase tracking-wider text-primary-light">
              {isHi ? "सेवा क्षेत्र" : "Service Network"}
            </span>
            <h2 className="mt-2 font-display text-3xl sm:text-4xl font-extrabold text-cream-surface">
              {isHi
                ? "पूरे बिहार में रूफटॉप सोलर सेवा नेटवर्क"
                : "Rooftop Solar EPC Coverage Across Bihar"}
            </h2>
          </div>

          <BiharMapSection onBookInspection={(city) => openQuote(`Rooftop Inspection (${city})`)} />
        </div>
      </section>

      {/* Quote modal */}
      <QuoteModal
        isOpen={quoteModalOpen}
        onClose={() => setQuoteModalOpen(false)}
        initialService={selectedService}
      />
    </div>
  );
}
