import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useLocale } from "../lib/locale-context";
import {
  BookOpen,
  Award,
  ShieldAlert,
  CheckCircle,
  GraduationCap,
  Wrench,
  TrendingUp,
} from "lucide-react";
import { submitLeadToCRM, CRM_CUSTOM_FIELDS } from "../lib/crm-tracking";
import { redirectToWhatsApp } from "../lib/whatsapp";

export const Route = createFileRoute("/become-a-partner/learn-and-earn")({
  head: () => ({
    meta: [
      { title: "Learn & Earn Student Internship — Elios Solar Energy Bihar" },
      {
        name: "description",
        content:
          "Practical clean tech solar EPC experience, sales training, and performance incentives for students in Bihar.",
      },
      { property: "og:title", content: "Learn & Earn Internship — Elios Solar Energy Bihar" },
    ],
  }),
  component: LearnAndEarnPage,
});

const HERO_IMG =
  "https://vibe.filesafe.space/1792820769937918655/assets/2205f96b-4abb-4e38-9ae7-e9b91172d92a.png";

const BENEFITS = [
  {
    icon: BookOpen,
    titleEn: "Hands-On Solar EPC Training",
    titleHi: "सोलर इंजीनियरिंग प्रशिक्षण",
    descEn:
      "Learn real-world rooftop surveying, kilowatt sizing, shadow analysis, and DISCOM net-metering feasibility.",
    descHi: "छत सर्वेक्षण, किलोवाट साइजिंग, शैडो विश्लेषण एवं नेट मीटरिंग की व्यावहारिक समझ।",
    img: "https://vibe.filesafe.space/1792820769937918655/assets/ee1d243c-29ad-49f3-9698-34b2d5edd436.png",
    altEn:
      "A young engineering student surveying a rooftop solar installation with a digital tablet and measuring tools at golden hour",
    altHi:
      "सुनहरी शाम में एक युवा इंजीनियरिंग छात्र डिजिटल टैबलेट और मापन उपकरणों के साथ रूफटॉप सोलर इंस्टॉलेशन का सर्वे करते हुए",
  },
  {
    icon: Award,
    titleEn: "Experience Certificate & Stipend",
    titleHi: "अनुभव प्रमाण पत्र एवं इंसेंटिव",
    descEn:
      "Official Elios internship certificate and performance-linked incentives upon successful completion.",
    descHi: "सफल कार्य पर अधिकृत एलियोस इंटर्नशिप प्रमाण पत्र एवं प्रदर्शन-आधारित इंसेंटिव।",
    img: "https://vibe.filesafe.space/1792820769937918655/assets/b3dbe465-82b9-4c96-bfdd-eb50e232cd8f.png",
    altEn:
      "A young Indian graduate proudly holding a solar engineering internship completion certificate with a rooftop solar array in the background at golden hour",
    altHi:
      "एक युवा भारतीय स्नातक सुनहरी शाम में रूफटॉप सोलर सरणी की पृष्ठभूमि के साथ सोलर इंजीनियरिंग इंटर्नशिप पूर्णता प्रमाण पत्र गर्व से पकड़े हुए",
  },
];

function LearnAndEarnPage() {
  const { isHi } = useLocale();
  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");
  const [college, setCollege] = useState("");
  const [city, setCity] = useState("Patna");
  const [submitted, setSubmitted] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg("");

    const cleanPhone = phone.replace(/\D/g, "");
    if (!/^[6-9]\d{9}$/.test(cleanPhone)) {
      setErrorMsg(
        isHi
          ? "कृपया 10 अंकों का मान्य भारतीय मोबाइल नंबर दर्ज करें।"
          : "Please enter a valid 10-digit Indian mobile number.",
      );
      return;
    }

    // Save lead locally + push to CRM (non-blocking).
    submitLeadToCRM({
      formId: "elios-learn-and-earn",
      formName: "Learn & Earn Internship Application",
      fullName,
      phone: cleanPhone,
      city,
      serviceNeeded: "Partnership",
      source: "learn_and_earn",
      message: `College / Institute: ${college}`,
      custom: {
        [CRM_CUSTOM_FIELDS.college]: {
          value: college,
          label: "College/Institution",
        },
      },
    });

    setSubmitted(true);
    const waText = `Hello Elios Solar Energy,\n\nI want to apply for the *Learn & Earn Internship Program*:\n\n*Name:* ${fullName}\n*Phone:* ${cleanPhone}\n*City:* ${city}\n*College/Course:* ${college}`;
    redirectToWhatsApp(waText);
  };

  return (
    <div className="w-full bg-background py-12 sm:py-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        {/* Hero */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center mb-14">
          <div className="text-center lg:text-left">
            <span className="text-xs font-bold uppercase tracking-wider text-primary">
              {isHi ? "विद्यार्थी इंटर्नशिप" : "Student Internship & Training"}
            </span>
            <h1 className="mt-2 font-display text-3xl sm:text-5xl font-extrabold text-foreground leading-tight">
              {isHi ? "लर्न एंड अर्न सोलर इंटर्नशिप" : "Learn & Earn Solar Program"}
            </h1>
            <p className="mt-4 text-base text-muted-foreground max-w-xl mx-auto lg:mx-0">
              {isHi
                ? "कॉलेज विद्यार्थियों के लिए सोलर ईपीसी तकनीकी ज्ञान, व्यावहारिक अनुभव और प्रदर्शन-आधारित इंसेंटिव।"
                : "Practical rooftop solar EPC engineering & clean energy consulting experience for colleges across Bihar."}
            </p>
            <div className="mt-6 flex flex-wrap gap-3 justify-center lg:justify-start">
              <a
                href="#register"
                className="inline-flex items-center rounded-xl bg-primary px-5 py-3 text-sm font-bold text-primary-foreground shadow-sm hover:bg-primary-hover transition-all active:scale-95"
              >
                {isHi ? "इंटर्नशिप आवेदन करें" : "Apply for Internship"}
              </a>
              <a
                href="#benefits"
                className="inline-flex items-center rounded-xl border border-border bg-card px-5 py-3 text-sm font-semibold text-foreground hover:border-primary/40 transition-all"
              >
                {isHi ? "कार्यक्रम के लाभ देखें" : "See Program Benefits"}
              </a>
            </div>
          </div>
          <div className="relative rounded-3xl overflow-hidden border border-border shadow-xl">
            <img
              src={HERO_IMG}
              alt={
                isHi
                  ? "सुनहरी शाम में रूफटॉप सोलर पैनलों के सामने एक युवा इंजीनियर मेंटर नेवी यूनिफॉर्म में कॉलेज छात्रों को सोलर ईपीसी प्रशिक्षण देते हुए"
                  : "A young engineer mentor in a navy uniform training college students on rooftop solar EPC at golden hour"
              }
              className="w-full h-64 sm:h-80 lg:h-96 object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-navy-premium/60 via-transparent to-transparent pointer-events-none" />
          </div>
        </div>

        <div
          id="benefits"
          className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start max-w-6xl mx-auto"
        >
          {/* Program Highlights with images */}
          <div className="lg:col-span-5 space-y-6">
            <h3 className="font-display text-xl font-bold text-foreground px-1">
              {isHi ? "इंटर्नशिप के लाभ" : "Why Join the Program?"}
            </h3>
            {BENEFITS.map((b) => {
              const Icon = b.icon;
              return (
                <div
                  key={b.titleEn}
                  className="group rounded-2xl border border-border bg-card overflow-hidden flex flex-col transition-all duration-300 hover:shadow-xl hover:-translate-y-1 hover:border-primary/40"
                >
                  <div className="relative aspect-[16/10] overflow-hidden">
                    <img
                      src={b.img}
                      alt={isHi ? b.altHi : b.altEn}
                      loading="lazy"
                      className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-navy-premium/70 via-navy-premium/10 to-transparent pointer-events-none" />
                    <div className="absolute top-3 left-3 h-10 w-10 rounded-xl bg-primary/90 text-primary-foreground flex items-center justify-center shadow-lg ring-2 ring-white/20">
                      <Icon className="h-5 w-5" />
                    </div>
                  </div>
                  <div className="p-5 flex-1 flex flex-col">
                    <h4 className="font-display text-base font-bold text-foreground mb-1.5 leading-snug">
                      {isHi ? b.titleHi : b.titleEn}
                    </h4>
                    <p className="text-xs text-muted-foreground leading-relaxed flex-1">
                      {isHi ? b.descHi : b.descEn}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Registration Form */}
          <div
            id="register"
            className="lg:col-span-7 rounded-3xl border border-border bg-card p-6 sm:p-8 shadow-sm lg:sticky lg:top-24"
          >
            {submitted ? (
              <div className="flex flex-col items-center py-10 text-center">
                <CheckCircle className="h-14 w-14 text-success animate-bounce" />
                <h3 className="mt-3 font-display text-xl font-bold text-foreground">
                  {isHi ? "आवेदन प्राप्त हुआ!" : "Application Submitted!"}
                </h3>
                <p className="mt-2 text-xs text-muted-foreground">
                  {isHi ? "आपको व्हाट्सएप पर भेजा जा रहा है..." : "Redirecting you to WhatsApp..."}
                </p>
              </div>
            ) : (
              <div>
                <h3 className="font-display text-xl font-bold text-foreground mb-1">
                  {isHi ? "इंटर्नशिप आवेदन पत्र" : "Apply for Learn & Earn"}
                </h3>
                <p className="text-xs text-muted-foreground mb-6">
                  {isHi
                    ? "आवेदन जमा करते ही विवरण सुरक्षित सहेजा जाएगा एवं व्हाट्सएप खुलेगा।"
                    : "Fill your details to directly connect with our mentor team on WhatsApp."}
                </p>

                {errorMsg && (
                  <div className="mb-4 flex items-center gap-2 rounded-lg bg-destructive/10 p-3 text-xs text-destructive">
                    <ShieldAlert className="h-4 w-4 shrink-0" />
                    <span>{errorMsg}</span>
                  </div>
                )}

                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-foreground mb-1">
                      {isHi ? "पूरा नाम" : "Full Name"} *
                    </label>
                    <input
                      type="text"
                      required
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder={isHi ? "उदा. प्रियांशु राज" : "e.g. Priyanshu Raj"}
                      className="w-full rounded-xl border border-border bg-background px-4 py-2.5 text-sm text-foreground focus:border-primary focus:outline-none"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-foreground mb-1">
                        {isHi ? "मोबाइल नंबर" : "Phone Number"} *
                      </label>
                      <input
                        type="tel"
                        required
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="9876543210"
                        className="w-full rounded-xl border border-border bg-background px-4 py-2.5 text-sm text-foreground focus:border-primary focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-foreground mb-1">
                        {isHi ? "शहर" : "City"} *
                      </label>
                      <input
                        type="text"
                        required
                        value={city}
                        onChange={(e) => setCity(e.target.value)}
                        placeholder={isHi ? "उदा. पटना / गया" : "e.g. Patna / Gaya"}
                        className="w-full rounded-xl border border-border bg-background px-4 py-2.5 text-sm text-foreground focus:border-primary focus:outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-foreground mb-1">
                      {isHi ? "कॉलेज / संस्थान का नाम" : "College / Educational Institution"} *
                    </label>
                    <input
                      type="text"
                      required
                      value={college}
                      onChange={(e) => setCollege(e.target.value)}
                      placeholder={
                        isHi
                          ? "उदा. एनआईटी पटना / आर्यभट्ट नॉलेज यूनिवर्सिटी"
                          : "e.g. NIT Patna / Aryabhatta Knowledge University"
                      }
                      className="w-full rounded-xl border border-border bg-background px-4 py-2.5 text-sm text-foreground focus:border-primary focus:outline-none"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full rounded-xl bg-primary py-3 text-sm font-bold text-primary-foreground shadow-sm hover:bg-primary-hover transition-all active:scale-95"
                  >
                    <span>{isHi ? "आवेदन जमा करें" : "Submit Internship Application"}</span>
                  </button>
                </form>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
